"""
Agent control routes.

POST /agents/{agent_type}/execute  — trigger an agent
GET  /agents/status                — current agent statuses
GET  /agents                       — list all agents and descriptions
"""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from agents import AGENT_REGISTRY
from core.redis_client import get_agent_statuses
from execution.orchestrator import Orchestrator

router = APIRouter(prefix="/agents", tags=["agents"])

_orchestrator = Orchestrator()


class ExecuteRequest(BaseModel):
    task_type: str
    instruction: str
    product_id: Optional[str] = None
    extra: dict[str, Any] = {}


class ExecuteResponse(BaseModel):
    success: bool
    agent: str
    task_type: str
    output: dict[str, Any]
    error: Optional[str]
    duration_ms: int
    actions_taken: list[str]


# ── Endpoints ─────────────────────────────────────────────────────────────────
@router.get("/")
async def list_agents() -> list[dict[str, str]]:
    """Return metadata for all registered agents."""
    descriptions = {
        "meta": "Task decomposition, product ideation, and orchestration",
        "builder": "Code generation and cloud deployment",
        "growth": "Lead generation and email outreach campaigns",
        "content": "Landing pages, blog posts, and social content",
        "monetization": "Pricing design and Stripe integration",
        "data": "Analytics, KPI tracking, and insights",
        "operator": "System health checks and failure recovery",
    }
    return [
        {"name": name, "description": descriptions.get(name, "")}
        for name in AGENT_REGISTRY
    ]


@router.get("/status")
async def agent_status() -> dict[str, str]:
    """Return the current operational status of each agent from Redis."""
    statuses = await get_agent_statuses()
    # Fill in 'idle' for agents with no recorded status
    for name in AGENT_REGISTRY:
        if name not in statuses:
            statuses[name] = "idle"
    return statuses


@router.post("/{agent_type}/execute", response_model=ExecuteResponse)
async def execute_agent(
    agent_type: str,
    request: ExecuteRequest,
) -> ExecuteResponse:
    """
    Trigger an agent directly via the REST API.
    The task runs synchronously within the request (no queue).
    """
    if agent_type not in AGENT_REGISTRY:
        raise HTTPException(
            status_code=404,
            detail=f"Agent '{agent_type}' not found. "
            f"Available: {list(AGENT_REGISTRY.keys())}",
        )

    task_payload = {
        "agent_type": agent_type,
        "task_type": request.task_type,
        "instruction": request.instruction,
        "product_id": request.product_id,
        **request.extra,
    }

    result = await _orchestrator.run_task(task_payload)

    return ExecuteResponse(
        success=result.success,
        agent=result.agent,
        task_type=result.task_type,
        output=result.output,
        error=result.error,
        duration_ms=result.duration_ms,
        actions_taken=result.actions_taken,
    )
