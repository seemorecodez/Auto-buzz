"""
Metrics routes.

GET /metrics/system         — system-wide analytics
GET /metrics/{product_id}   — product KPIs
GET /metrics/{product_id}/funnel — conversion funnel
GET /metrics/{product_id}/history/{metric_type} — time series
"""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query

from memory.structured_memory import StructuredMemory
from models.metric import MetricType
from tools.analytics import AnalyticsTool

router = APIRouter(prefix="/metrics", tags=["metrics"])
_memory = StructuredMemory()
_analytics = AnalyticsTool()


@router.get("/system")
async def system_analytics(
    days: int = Query(default=7, ge=1, le=90),
) -> dict[str, Any]:
    """Return system-wide analytics for the past N days."""
    return await _analytics.get_system_analytics(days=days)


@router.get("/{product_id}")
async def product_kpis(
    product_id: str,
    days: int = Query(default=30, ge=1, le=365),
) -> dict[str, Any]:
    """Return KPIs for a specific product."""
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return await _analytics.get_product_kpis(product_id, days=days)


@router.get("/{product_id}/funnel")
async def product_funnel(product_id: str) -> dict[str, Any]:
    """Return the visitor → signup → paid conversion funnel."""
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return await _analytics.compute_funnel(product_id)


@router.get("/{product_id}/history/{metric_type}")
async def metric_history(
    product_id: str,
    metric_type: str,
    days: int = Query(default=30, ge=1, le=365),
) -> list[dict[str, Any]]:
    """Return time-series data for a specific metric."""
    try:
        mt = MetricType(metric_type)
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid metric_type. Options: {[m.value for m in MetricType]}",
        )

    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    return await _memory.get_metric_history(mt, product_id=product_id, days=days)


@router.get("/{product_id}/insights")
async def product_insights(
    product_id: str,
    days: int = Query(default=14, ge=1, le=90),
) -> dict[str, Any]:
    """Use AI to generate actionable insights from product metrics."""
    kpis = await _analytics.get_product_kpis(product_id, days=days)
    insights = await _analytics.generate_insights(kpis)
    return {"product_id": product_id, "insights": insights, "kpis": kpis}
