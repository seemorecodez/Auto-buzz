"""
Product management routes.

GET    /products            — list all products
POST   /products            — create a new product manually
GET    /products/{id}       — get product details
PATCH  /products/{id}       — update product fields
DELETE /products/{id}       — archive a product
POST   /products/{id}/launch — trigger full product launch pipeline
"""

from __future__ import annotations

import uuid
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from core.database import get_db_session
from core.logger import get_logger
from execution.orchestrator import Orchestrator
from memory.structured_memory import StructuredMemory
from models.product import Product, ProductStatus
from models.task import AgentType, Task, TaskStatus

router = APIRouter(prefix="/products", tags=["products"])
log = get_logger(__name__)
_memory = StructuredMemory()
_orchestrator = Orchestrator()


# ── Pydantic schemas ──────────────────────────────────────────────────────────
class ProductCreate(BaseModel):
    name: str
    niche: str
    description: Optional[str] = None
    tagline: Optional[str] = None
    target_audience: Optional[str] = None
    value_proposition: Optional[str] = None
    tech_stack: str = "FastAPI + SQLite + Tailwind CSS"
    price_monthly: Optional[float] = 29.0
    price_annual: Optional[float] = 249.0


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    status: Optional[str] = None
    description: Optional[str] = None
    tagline: Optional[str] = None
    target_audience: Optional[str] = None
    value_proposition: Optional[str] = None
    landing_page_url: Optional[str] = None
    deploy_url: Optional[str] = None
    price_monthly: Optional[float] = None
    price_annual: Optional[float] = None
    mrr: Optional[float] = None


class LaunchRequest(BaseModel):
    skip_build: bool = False
    skip_landing_page: bool = False
    skip_pricing: bool = False
    skip_outreach: bool = False


# ── Endpoints ─────────────────────────────────────────────────────────────────
@router.get("/")
async def list_products() -> list[dict[str, Any]]:
    """Return all products with summary info."""
    return await _memory.get_active_products()


@router.post("/", status_code=201)
async def create_product(body: ProductCreate) -> dict[str, Any]:
    """Manually create a new product record."""
    from slugify import slugify

    slug = slugify(body.name)
    async with get_db_session() as session:
        # Check for slug collision
        existing = await session.scalar(
            select(Product).where(Product.slug == slug)
        )
        if existing:
            slug = f"{slug}-{str(uuid.uuid4())[:4]}"

        product = Product(
            id=str(uuid.uuid4()),
            name=body.name,
            slug=slug,
            niche=body.niche,
            description=body.description,
            tagline=body.tagline,
            target_audience=body.target_audience,
            value_proposition=body.value_proposition,
            tech_stack=body.tech_stack,
            price_monthly=body.price_monthly,
            price_annual=body.price_annual,
            status=ProductStatus.IDEATING,
        )
        session.add(product)
        await session.flush()
        product_id = product.id

    return await _memory.get_product_by_id(product_id)


@router.get("/{product_id}")
async def get_product(product_id: str) -> dict[str, Any]:
    """Get full product details by ID."""
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.patch("/{product_id}")
async def update_product(
    product_id: str, body: ProductUpdate
) -> dict[str, Any]:
    """Update specific product fields."""
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}

    if "status" in updates:
        try:
            updates["status"] = ProductStatus(updates["status"])
        except ValueError:
            raise HTTPException(
                status_code=422,
                detail=f"Invalid status. Options: {[s.value for s in ProductStatus]}",
            )

    if updates:
        await _memory.update_product_field(product_id, **updates)

    return await _memory.get_product_by_id(product_id)


@router.delete("/{product_id}")
async def archive_product(product_id: str) -> dict[str, str]:
    """Archive a product (soft delete)."""
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    await _memory.update_product_field(
        product_id, status=ProductStatus.ARCHIVED
    )
    return {"message": f"Product {product_id} archived"}


@router.post("/{product_id}/launch")
async def launch_product(
    product_id: str,
    request: LaunchRequest,
    background_tasks: BackgroundTasks,
) -> dict[str, Any]:
    """
    Trigger the full product launch pipeline asynchronously.
    Enqueues tasks for: build → landing page → pricing → outreach
    """
    product = await _memory.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    tasks_to_create: list[dict] = []

    if not request.skip_build:
        tasks_to_create.append({
            "agent_type": AgentType.BUILDER,
            "task_type": "build_mvp",
            "instruction": f"Build and deploy the MVP for {product['name']}",
            "priority": 10,
        })
    if not request.skip_landing_page:
        tasks_to_create.append({
            "agent_type": AgentType.CONTENT,
            "task_type": "generate_landing_page",
            "instruction": f"Generate landing page for {product['name']}",
            "priority": 9,
        })
    if not request.skip_pricing:
        tasks_to_create.append({
            "agent_type": AgentType.MONETIZATION,
            "task_type": "setup_pricing",
            "instruction": f"Design pricing and set up Stripe for {product['name']}",
            "priority": 8,
        })
    if not request.skip_outreach:
        tasks_to_create.append({
            "agent_type": AgentType.GROWTH,
            "task_type": "run_outreach",
            "instruction": f"Find leads and run email outreach for {product['name']}",
            "priority": 7,
        })

    # Write tasks to DB
    task_ids: list[str] = []
    async with get_db_session() as session:
        for t in tasks_to_create:
            task = Task(
                id=str(uuid.uuid4()),
                product_id=product_id,
                agent_type=t["agent_type"],
                task_type=t["task_type"],
                instruction=t["instruction"],
                priority=t.get("priority", 5),
                status=TaskStatus.PENDING,
            )
            session.add(task)
            task_ids.append(task.id)

    log.info(
        "api.launch_pipeline_queued",
        product_id=product_id,
        tasks=len(task_ids),
    )

    return {
        "message": f"Launch pipeline queued for '{product['name']}'",
        "product_id": product_id,
        "tasks_queued": len(task_ids),
        "task_ids": task_ids,
    }
