"""
System control routes.

GET  /system/health            — health check
GET  /system/loop/status       — execution loop status
POST /system/loop/start        — start execution loop
POST /system/loop/stop         — stop execution loop
POST /system/loop/run-once     — run a single loop iteration
GET  /system/queue             — task queue stats
POST /system/queue/drain       — execute all pending tasks now
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from core.database import get_db_session
from core.logger import get_logger
from core.redis_client import get_agent_statuses, get_redis
from execution.loop import ExecutionLoop, get_loop
from execution.orchestrator import Orchestrator
from memory.structured_memory import StructuredMemory
from models.task import Task, TaskStatus
from sqlalchemy import select, func

router = APIRouter(prefix="/system", tags=["system"])
log = get_logger(__name__)
_memory = StructuredMemory()
_orchestrator = Orchestrator()

# Module-level loop instance (set by main.py on startup)
_loop: ExecutionLoop | None = None


def set_loop(loop: ExecutionLoop) -> None:
    global _loop
    _loop = loop


# ── Health ────────────────────────────────────────────────────────────────────
@router.get("/health")
async def health() -> dict[str, Any]:
    """Basic health probe — checks DB and Redis."""
    db_ok = False
    redis_ok = False

    try:
        summary = await _memory.get_system_summary()
        db_ok = True
    except Exception as e:
        summary = {"error": str(e)}

    try:
        r = await get_redis()
        await r.ping()
        redis_ok = True
    except Exception:
        pass

    status = "ok" if (db_ok and redis_ok) else "degraded"
    return {
        "status": status,
        "database": "ok" if db_ok else "error",
        "redis": "ok" if redis_ok else "error",
        "system_summary": summary,
    }


# ── Loop control ──────────────────────────────────────────────────────────────
@router.get("/loop/status")
async def loop_status() -> dict[str, Any]:
    """Return execution loop status."""
    loop = get_loop()
    if loop is None:
        return {"running": False, "iteration": 0, "message": "Loop not initialised"}
    return {
        "running": loop.is_running,
        "iteration": loop.iteration,
        "interval_seconds": loop.interval,
    }


@router.post("/loop/start")
async def start_loop() -> dict[str, str]:
    """Start the execution loop in a background asyncio task."""
    import asyncio

    loop = get_loop()
    if loop is None:
        new_loop = ExecutionLoop()
        asyncio.create_task(new_loop.start())
        return {"message": "Execution loop started"}

    if loop.is_running:
        return {"message": "Execution loop is already running"}

    asyncio.create_task(loop.start())
    return {"message": "Execution loop started"}


@router.post("/loop/stop")
async def stop_loop() -> dict[str, str]:
    """Signal the execution loop to stop after the current tick."""
    loop = get_loop()
    if loop is None or not loop.is_running:
        return {"message": "Execution loop is not running"}
    await loop.stop()
    return {"message": "Execution loop stop signal sent"}


@router.post("/loop/run-once")
async def loop_run_once() -> dict[str, Any]:
    """Manually trigger a single loop iteration synchronously."""
    loop = get_loop()
    if loop is None:
        loop = ExecutionLoop()
    return await loop.run_once()


# ── Queue ─────────────────────────────────────────────────────────────────────
@router.get("/queue")
async def queue_stats() -> dict[str, Any]:
    """Return task queue statistics from the database."""
    async with get_db_session() as session:
        stats: dict[str, int] = {}
        for status in TaskStatus:
            count = await session.scalar(
                select(func.count(Task.id)).where(Task.status == status)
            )
            stats[status.value] = int(count or 0)

    r_queue_len = 0
    try:
        r = await get_redis()
        r_queue_len = await r.llen("acai:task_queue")
    except Exception:
        pass

    return {
        "db_task_counts": stats,
        "redis_queue_depth": r_queue_len,
        "agent_statuses": await get_agent_statuses(),
    }


@router.post("/queue/drain")
async def drain_queue(limit: int = 20) -> dict[str, Any]:
    """
    Execute all pending tasks immediately (up to *limit*).
    Useful for manual runs and testing.
    """
    results = await _orchestrator.execute_pending_tasks(limit=limit)
    succeeded = sum(1 for r in results if r.get("success"))
    failed = len(results) - succeeded

    return {
        "executed": len(results),
        "succeeded": succeeded,
        "failed": failed,
        "results": results,
    }
