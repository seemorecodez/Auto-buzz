"""
FastAPI application entry point.

Registers all routers, startup/shutdown events, middleware, and docs.
"""

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from api.routes import agents, metrics, products, system
from core.config import settings
from core.database import close_db, init_db
from core.logger import get_logger
from core.redis_client import close_redis, get_redis
from execution.loop import ExecutionLoop

log = get_logger(__name__)

# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Handle startup and graceful shutdown."""
    log.info("api.startup_begin")

    # Initialise database tables
    await init_db()

    # Warm up Redis
    try:
        await get_redis()
        log.info("api.redis_ready")
    except Exception as e:
        log.warning("api.redis_unavailable", error=str(e))

    # Start the execution loop in a background task
    loop = ExecutionLoop(interval=settings.LOOP_INTERVAL_SECONDS)
    system.set_loop(loop)
    loop_task = asyncio.create_task(loop.start())
    log.info("api.execution_loop_started")

    log.info("api.startup_complete", version="1.0.0")
    yield

    # ── Shutdown ──────────────────────────────────────────────────────
    log.info("api.shutdown_begin")
    await loop.stop()
    loop_task.cancel()
    try:
        await loop_task
    except asyncio.CancelledError:
        pass

    await close_redis()
    await close_db()
    log.info("api.shutdown_complete")


# ── App factory ───────────────────────────────────────────────────────────────
def create_app() -> FastAPI:
    app = FastAPI(
        title="Autonomous Company AI",
        description=(
            "Production-grade multi-agent system for autonomously building, "
            "launching, and scaling revenue-generating digital products."
        ),
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # ── Middleware ────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Request timing middleware
    @app.middleware("http")
    async def add_timing_header(request: Request, call_next):
        start = time.monotonic()
        response = await call_next(request)
        elapsed = round((time.monotonic() - start) * 1000, 2)
        response.headers["X-Response-Time-ms"] = str(elapsed)
        return response

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        log.error(
            "api.unhandled_exception",
            path=request.url.path,
            error=str(exc),
            exc_info=True,
        )
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error", "error": str(exc)},
        )

    # ── Routers ───────────────────────────────────────────────────────
    app.include_router(agents.router)
    app.include_router(products.router)
    app.include_router(metrics.router)
    app.include_router(system.router)

    # Root
    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "name": "Autonomous Company AI",
            "version": "1.0.0",
            "docs": "/docs",
            "status": "running",
        }

    return app


app = create_app()


# ── Dev entrypoint ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "api.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=False,
        log_level="info",
    )
