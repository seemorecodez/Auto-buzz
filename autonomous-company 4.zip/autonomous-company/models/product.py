"""
Product model — each row represents an autonomous digital product
that the system has generated and is actively growing.
"""

from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import Enum, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDMixin


class ProductStatus(str, enum.Enum):
    IDEATING = "ideating"
    BUILDING = "building"
    DEPLOYED = "deployed"
    GROWING = "growing"
    MONETIZING = "monetizing"
    OPTIMIZING = "optimizing"
    PAUSED = "paused"
    ARCHIVED = "archived"


class Product(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "products"

    # ── Identity ─────────────────────────────────────────────────────
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    slug: Mapped[str] = mapped_column(String(256), nullable=False, unique=True)
    niche: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tagline: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # ── Status ───────────────────────────────────────────────────────
    status: Mapped[ProductStatus] = mapped_column(
        Enum(ProductStatus, native_enum=False, values_callable=lambda x: [e.value for e in x]),
        default=ProductStatus.IDEATING,
        nullable=False,
    )

    # ── URLs ─────────────────────────────────────────────────────────
    landing_page_url: Mapped[Optional[str]] = mapped_column(String(512))
    repo_url: Mapped[Optional[str]] = mapped_column(String(512))
    deploy_url: Mapped[Optional[str]] = mapped_column(String(512))
    stripe_product_id: Mapped[Optional[str]] = mapped_column(String(256))
    stripe_price_id: Mapped[Optional[str]] = mapped_column(String(256))

    # ── Financials ───────────────────────────────────────────────────
    mrr: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    arr: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    total_revenue: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    price_monthly: Mapped[Optional[float]] = mapped_column(Float)
    price_annual: Mapped[Optional[float]] = mapped_column(Float)

    # ── Growth ───────────────────────────────────────────────────────
    visitors: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    signups: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    paid_customers: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    churn_rate: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)

    # ── Strategy ─────────────────────────────────────────────────────
    target_audience: Mapped[Optional[str]] = mapped_column(Text)
    value_proposition: Mapped[Optional[str]] = mapped_column(Text)
    go_to_market_strategy: Mapped[Optional[str]] = mapped_column(Text)
    tech_stack: Mapped[Optional[str]] = mapped_column(String(512))

    # ── Relationships ─────────────────────────────────────────────────
    tasks: Mapped[list] = relationship(
        "Task", back_populates="product", cascade="all, delete-orphan"
    )
    metrics: Mapped[list] = relationship(
        "Metric", back_populates="product", cascade="all, delete-orphan"
    )
    actions: Mapped[list] = relationship(
        "Action", back_populates="product", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Product {self.slug} status={self.status}>"
