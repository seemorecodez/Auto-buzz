"""
Action model — atomic actions taken by agents, with full audit trail.
"""

from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import Enum, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDMixin


class ActionStatus(str, enum.Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"


class Action(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "actions"

    # ── FK to Product and Task ───────────────────────────────────────
    product_id: Mapped[Optional[str]] = mapped_column(
        String(36), ForeignKey("products.id", ondelete="CASCADE"), nullable=True
    )
    task_id: Mapped[Optional[str]] = mapped_column(
        String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=True
    )
    product: Mapped[Optional[object]] = relationship(
        "Product", back_populates="actions"
    )
    task: Mapped[Optional[object]] = relationship("Task", back_populates="actions")

    # ── Classification ───────────────────────────────────────────────
    agent_type: Mapped[str] = mapped_column(String(64), nullable=False)
    action_type: Mapped[str] = mapped_column(String(128), nullable=False)
    # e.g. "generate_code", "send_email", "deploy", "create_stripe_product"

    # ── Payload / Result ─────────────────────────────────────────────
    payload: Mapped[Optional[str]] = mapped_column(Text)   # JSON input to the action
    result: Mapped[Optional[str]] = mapped_column(Text)    # JSON output
    error_detail: Mapped[Optional[str]] = mapped_column(Text)

    # ── Status ───────────────────────────────────────────────────────
    status: Mapped[ActionStatus] = mapped_column(
        Enum(ActionStatus, native_enum=False, values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=ActionStatus.SUCCESS,
    )

    # ── External references ──────────────────────────────────────────
    external_id: Mapped[Optional[str]] = mapped_column(String(256))
    # e.g. Stripe charge ID, deployment ID, email campaign ID

    def __repr__(self) -> str:
        return (
            f"<Action {self.action_type} agent={self.agent_type} "
            f"status={self.status}>"
        )
