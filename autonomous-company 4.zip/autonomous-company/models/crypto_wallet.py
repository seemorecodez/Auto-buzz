"""
CryptoWallet model — one wallet per product for receiving payments.

Stores the public address (safe to display) and the encrypted private key.
Private key is AES-256 encrypted with the app SECRET_KEY before storage.
"""

from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDMixin


class CryptoNetwork(str, enum.Enum):
    ETH_MAINNET = "eth_mainnet"
    ETH_SEPOLIA = "eth_sepolia"      # Testnet
    BTC_MAINNET = "btc_mainnet"


class CryptoWallet(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "crypto_wallets"

    # ── Product link ──────────────────────────────────────────────────
    product_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("products.id", ondelete="CASCADE"),
        nullable=True,
        unique=True,  # One wallet per product
    )

    # ── Wallet identity ───────────────────────────────────────────────
    network: Mapped[CryptoNetwork] = mapped_column(
        SAEnum(CryptoNetwork, native_enum=False, length=32),
        nullable=False,
        default=CryptoNetwork.ETH_MAINNET,
    )
    address: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    encrypted_private_key: Mapped[str] = mapped_column(Text, nullable=False)
    derivation_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # ── Balances (cached from chain) ──────────────────────────────────
    eth_balance: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    usdc_balance: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    total_received_eth: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    total_received_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    last_tx_hash: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)

    # ── Payment links ─────────────────────────────────────────────────
    price_eth: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    price_usdc: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    qr_code_path: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    def __repr__(self) -> str:
        return f"<CryptoWallet {self.address[:10]}... network={self.network}>"
