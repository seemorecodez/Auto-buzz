"""
Task model — unit of work dispatched to an agent.
"""

from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDMixin


class AgentType(str, enum.Enum):
    META = "meta"
    BUILDER = "builder"
    GROWTH = "growth"
    CONTENT = "content"
    MONETIZATION = "monetization"
    DATA = "data"
    OPERATOR = "operator"


class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    CANCELLED = "cancelled"


class Task(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "tasks"

    # ── Relationships ─────────────────────────────────────────────────
    product_id: Mapped[Optional[str]] = mapped_column(
        String(36), ForeignKey("products.id", ondelete="CASCADE"), nullable=True
    )
    product: Mapped[Optional[object]] = relationship("Product", back_populates="tasks")

    # ── Identity ─────────────────────────────────────────────────────
    agent_type: Mapped[AgentType] = mapped_column(
        Enum(AgentType, native_enum=False, values_callable=lambda x: [e.value for e in x]), nullable=False
    )
    task_type: Mapped[str] = mapped_column(String(128), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=5, nullable=False)

    # ── Content ──────────────────────────────────────────────────────
    instruction: Mapped[str] = mapped_column(Text, nullable=False)
    context: Mapped[Optional[str]] = mapped_column(Text)  # JSON-encoded extra context
    result: Mapped[Optional[str]] = mapped_column(Text)   # JSON-encoded result
    error: Mapped[Optional[str]] = mapped_column(Text)

    # ── Execution ────────────────────────────────────────────────────
    status: Mapped[TaskStatus] = mapped_column(
        Enum(TaskStatus, native_enum=False, values_callable=lambda x: [e.value for e in x]),
        default=TaskStatus.PENDING,
        nullable=False,
    )
    retry_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    celery_task_id: Mapped[Optional[str]] = mapped_column(String(256))
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer)

    # ── Relationships to actions spawned by this task ─────────────────
    actions: Mapped[list] = relationship(
        "Action", back_populates="task", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Task {self.id[:8]} agent={self.agent_type} status={self.status}>"
