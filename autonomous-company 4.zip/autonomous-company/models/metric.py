"""
Metric model — time-series performance data per product.
"""

from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import Enum, Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDMixin


class MetricType(str, enum.Enum):
    # Traffic
    VISITORS = "visitors"
    PAGE_VIEWS = "page_views"
    BOUNCE_RATE = "bounce_rate"
    SESSION_DURATION = "session_duration"

    # Conversion
    SIGNUPS = "signups"
    CONVERSION_RATE = "conversion_rate"
    ACTIVATION_RATE = "activation_rate"

    # Revenue
    MRR = "mrr"
    ARR = "arr"
    REVENUE = "revenue"
    ARPU = "arpu"
    LTV = "ltv"

    # Retention
    CHURN_RATE = "churn_rate"
    DAU = "dau"
    MAU = "mau"
    RETENTION_D7 = "retention_d7"
    RETENTION_D30 = "retention_d30"

    # Outreach
    EMAILS_SENT = "emails_sent"
    EMAIL_OPEN_RATE = "email_open_rate"
    EMAIL_REPLY_RATE = "email_reply_rate"
    LEADS_GENERATED = "leads_generated"

    # System
    UPTIME_PERCENT = "uptime_percent"
    ERROR_RATE = "error_rate"
    TASK_SUCCESS_RATE = "task_success_rate"


class Metric(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "metrics"

    product_id: Mapped[Optional[str]] = mapped_column(
        String(36), ForeignKey("products.id", ondelete="CASCADE"), nullable=True
    )
    product: Mapped[Optional[object]] = relationship(
        "Product", back_populates="metrics"
    )

    metric_type: Mapped[MetricType] = mapped_column(
        Enum(MetricType, native_enum=False, values_callable=lambda x: [e.value for e in x]),
        nullable=False,
    )
    value: Mapped[float] = mapped_column(Float, nullable=False)
    unit: Mapped[Optional[str]] = mapped_column(String(64))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    source: Mapped[Optional[str]] = mapped_column(String(128))  # e.g. "stripe", "ga4"

    def __repr__(self) -> str:
        return f"<Metric {self.metric_type}={self.value} product={self.product_id}>"
