"""
Patch meta_agent.py to:
1. Replace GROWTH_TASKS_PER_PRODUCT with BUILD_TASKS + expanded GROWTH_TASKS
2. Update TASK_DECOMPOSITION_SYSTEM to include new task types
3. Update _growth_mode_orchestrate to handle building vs monetizing phases
   and cycle through ALL 5 products
"""
import re
import sys

path = "/home/user/workspace/autonomous-company/agents/meta_agent.py"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

# ── 1. Replace GROWTH_TASKS_PER_PRODUCT section ──────────────────────────────
old_growth_tasks = '''# Growth-mode task templates: once all 5 products are live, every loop runs these
GROWTH_TASKS_PER_PRODUCT: list[dict] = [
    # \u2500\u2500 Revenue \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "run_outreach",            "agent_type": "growth",       "priority": 9},
    {"task_type": "send_drip_sequence",      "agent_type": "growth",       "priority": 9},
    {"task_type": "multi_touch_outreach",    "agent_type": "growth",       "priority": 8},
    {"task_type": "generate_leads",          "agent_type": "growth",       "priority": 8},
    {"task_type": "create_checkout_page",    "agent_type": "monetization", "priority": 9},
    {"task_type": "add_ltd_tier",            "agent_type": "monetization", "priority": 7},
    # \u2500\u2500 Traffic \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "write_seo_blog_post",     "agent_type": "content",      "priority": 7},
    {"task_type": "write_comparison_page",   "agent_type": "content",      "priority": 7},
    {"task_type": "write_ph_kit",            "agent_type": "content",      "priority": 6},
    {"task_type": "generate_sitemap",        "agent_type": "builder",      "priority": 6},
    # \u2500\u2500 Conversion \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "add_exit_intent",         "agent_type": "builder",      "priority": 8},
    {"task_type": "add_social_proof",        "agent_type": "builder",      "priority": 8},
    {"task_type": "write_ab_variant",        "agent_type": "content",      "priority": 7},
    {"task_type": "expand_features",         "agent_type": "builder",      "priority": 6},
    {"task_type": "score_leads",             "agent_type": "data",         "priority": 7},
    # \u2500\u2500 Scale & Retention \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "write_changelog",         "agent_type": "content",      "priority": 6},
    {"task_type": "cross_sell",              "agent_type": "growth",       "priority": 7},
    {"task_type": "launch_affiliate_program","agent_type": "growth",       "priority": 6},
    {"task_type": "collect_metrics",         "agent_type": "data",         "priority": 5},
    {"task_type": "write_testimonials",      "agent_type": "content",      "priority": 5},
]'''

new_growth_tasks = '''# Build-phase task templates: for products in BUILDING status
# Queue these to generate landing pages, build MVPs, and set up payments
BUILD_TASKS_PER_PRODUCT: list[dict] = [
    # \u2500\u2500 Core Build \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "generate_landing_page",  "agent_type": "content",      "priority": 10},
    {"task_type": "build_mvp",              "agent_type": "builder",      "priority": 9},
    # \u2500\u2500 Payments & Monetization \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "setup_wallet",           "agent_type": "monetization", "priority": 9},
    {"task_type": "create_checkout_page",   "agent_type": "monetization", "priority": 8},
    {"task_type": "setup_free_trial",       "agent_type": "monetization", "priority": 7},
]

# Growth-mode task templates: for products in MONETIZING / DEPLOYED / GROWING status
# Every loop: queue GROWTH_TASKS_PER_PRODUCT for each product with fewer than 3 pending tasks
GROWTH_TASKS_PER_PRODUCT: list[dict] = [
    # \u2500\u2500 Revenue \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "generate_leads",           "agent_type": "growth",       "priority": 9},
    {"task_type": "run_outreach",             "agent_type": "growth",       "priority": 9},
    {"task_type": "send_drip_sequence",       "agent_type": "growth",       "priority": 9},
    {"task_type": "multi_touch_outreach",     "agent_type": "growth",       "priority": 8},
    {"task_type": "create_checkout_page",     "agent_type": "monetization", "priority": 9},
    {"task_type": "add_ltd_tier",             "agent_type": "monetization", "priority": 7},
    # \u2500\u2500 SEO & Content Traffic \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "write_seo_blog_post",      "agent_type": "content",      "priority": 8},
    {"task_type": "write_comparison_page",    "agent_type": "content",      "priority": 7},
    {"task_type": "write_niche_page",         "agent_type": "content",      "priority": 7},
    {"task_type": "write_ph_kit",             "agent_type": "content",      "priority": 6},
    {"task_type": "generate_sitemap",         "agent_type": "builder",      "priority": 6},
    {"task_type": "generate_social_content",  "agent_type": "content",      "priority": 7},
    # \u2500\u2500 Conversion \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "add_exit_intent",          "agent_type": "builder",      "priority": 8},
    {"task_type": "add_social_proof",         "agent_type": "builder",      "priority": 8},
    {"task_type": "run_ab_test",              "agent_type": "content",      "priority": 7},
    {"task_type": "expand_features",          "agent_type": "builder",      "priority": 6},
    {"task_type": "score_leads",              "agent_type": "data",         "priority": 7},
    # \u2500\u2500 Scale & Retention \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    {"task_type": "update_changelog",         "agent_type": "content",      "priority": 6},
    {"task_type": "cross_sell",               "agent_type": "growth",       "priority": 7},
    {"task_type": "setup_affiliate",          "agent_type": "growth",       "priority": 6},
    {"task_type": "collect_metrics",          "agent_type": "data",         "priority": 5},
    {"task_type": "generate_revenue_dashboard","agent_type": "data",        "priority": 6},
    {"task_type": "write_testimonials",       "agent_type": "content",      "priority": 5},
]'''

if old_growth_tasks in content:
    content = content.replace(old_growth_tasks, new_growth_tasks)
    print("Replaced GROWTH_TASKS_PER_PRODUCT section successfully")
else:
    print("ERROR: Could not find old GROWTH_TASKS_PER_PRODUCT section")
    sys.exit(1)

# ── 2. Update TASK_DECOMPOSITION_SYSTEM to include new task types ─────────────
old_decomp = """TASK_DECOMPOSITION_SYSTEM = \"\"\"
You are a product operations manager.
Given a product spec and its current status, return 2-4 tasks to execute next.

You MUST only use the following agent_type + task_type combinations (no others):

builder:
  - build_mvp               (generate full codebase and deploy)
  - add_feature / add_exit_intent / add_social_proof / expand_features / generate_sitemap

content:
  - generate_landing_page / write_blog_post / write_social_content
  - write_seo_blog_post / write_comparison_page / write_testimonials
  - write_ph_kit / write_ab_variant / write_changelog / write_newsletter

growth:
  - generate_leads / run_outreach / send_broadcast / analyse_growth
  - send_drip_sequence / multi_touch_outreach / score_leads
  - cross_sell / launch_affiliate_program

monetization:
  - design_pricing / setup_payments / check_payments
  - create_checkout_page / add_ltd_tier

data:
  - collect_metrics / generate_insights / system_report
  - score_leads / generate_revenue_dashboard / check_price_trigger

operator:
  - health_check / retry_failed_tasks

Return ONLY a JSON object with a \"tasks\" key:
{
  \"tasks\": [
    {
      \"agent_type\": \"builder\",
      \"task_type\": \"build_mvp\",
      \"instruction\": \"Build the full MVP for ...\",
      \"priority\": 9
    }
  ]
}

Priority scale: 10=critical, 7-9=high, 4-6=medium, 1-3=low.
For a new product in IDEATING status, always start with build_mvp (builder) first.
NEVER return a bare array. Always wrap in {\"tasks\": [...]}.
\"\"\""""

new_decomp = """TASK_DECOMPOSITION_SYSTEM = \"\"\"
You are a product operations manager.
Given a product spec and its current status, return 2-4 tasks to execute next.

You MUST only use the following agent_type + task_type combinations (no others):

builder:
  - build_mvp               (generate full codebase and deploy)
  - add_feature / add_exit_intent / add_social_proof / expand_features / generate_sitemap
  - deploy_niche_page       (deploy a programmatic niche landing page to Vercel)

content:
  - generate_landing_page / write_blog_post / write_social_content / generate_social_content
  - write_seo_blog_post / write_comparison_page / write_niche_page / write_testimonials
  - write_ph_kit / run_ab_test / update_changelog / write_newsletter

growth:
  - generate_leads / run_outreach / send_broadcast / analyse_growth
  - send_drip_sequence / multi_touch_outreach / score_leads
  - cross_sell / setup_affiliate / launch_affiliate_program

monetization:
  - design_pricing / setup_payments / check_payments / setup_wallet / setup_free_trial
  - create_checkout_page / add_ltd_tier

data:
  - collect_metrics / generate_insights / system_report
  - score_leads / generate_revenue_dashboard / check_price_trigger

operator:
  - health_check / retry_failed_tasks

Return ONLY a JSON object with a \"tasks\" key:
{
  \"tasks\": [
    {
      \"agent_type\": \"builder\",
      \"task_type\": \"build_mvp\",
      \"instruction\": \"Build the full MVP for ...\",
      \"priority\": 9
    }
  ]
}

Priority scale: 10=critical, 7-9=high, 4-6=medium, 1-3=low.
For a new product in IDEATING or BUILDING status, prioritise: generate_landing_page → build_mvp → setup_wallet → create_checkout_page.
For MONETIZING products, prioritise: write_seo_blog_post, generate_leads, run_outreach, write_niche_page.
NEVER return a bare array. Always wrap in {\"tasks\": [...]}.
\"\"\""""

if old_decomp in content:
    content = content.replace(old_decomp, new_decomp)
    print("Replaced TASK_DECOMPOSITION_SYSTEM successfully")
else:
    print("ERROR: Could not find old TASK_DECOMPOSITION_SYSTEM section")
    sys.exit(1)

# ── 3. Update _growth_mode_orchestrate to handle building vs monetizing ────────
# Replace the loop body that enqueues growth tasks to also handle building products
old_growth_loop = '''        for product in products:
            pid = product["id"]
            slug = product["slug"]
            spec = portfolio_map.get(slug, {})
            user_target = spec.get("user_target", 10000)
            current_signups = product.get("signups", 0)
            pct = round(current_signups / user_target * 100, 1) if user_target else 0
            channels = ", ".join(spec.get("growth_channels", []))

            progress.append(
                {
                    "product": product["name"],
                    "slug": slug,
                    "signups": current_signups,
                    "target": user_target,
                    "pct_to_goal": pct,
                    "price_monthly": spec.get("price_monthly", 0),
                }
            )
            log.info(
                "meta_agent.growth_progress",
                product=slug,
                signups=current_signups,
                target=user_target,
                pct=pct,
            )

            # Queue growth tasks if this product has < 3 pending tasks
            if pending_by_product.get(pid, 0) < 3:
                async with get_db_session() as session:
                    for template in GROWTH_TASKS_PER_PRODUCT:
                        # Every 8th loop: upgrade collect_metrics → generate_insights
                        if (
                            loop_count % 8 == 0
                            and template["task_type"] == "collect_metrics"
                        ):
                            t_type = "generate_insights"
                            a_type = "data"
                            instruction = (
                                f"Analyse {product[\'name\']} growth performance and "
                                f"recommend the top 3 acquisition actions to accelerate "
                                f"toward {user_target:,} users. "
                                f"Current signups: {current_signups:,} ({pct}% of goal). "
                                f"Market: {spec.get(\'market_size\', \'\')}."
                            )
                            priority = 8
                        else:
                            t_type = template["task_type"]
                            a_type = template["agent_type"]
                            instruction = (
                                f"[GROWTH MODE] {product[\'name\']} — "
                                f"{t_type.replace(\'_\', \' \')}. "
                                f"Goal: {user_target:,} users | "
                                f"Progress: {current_signups:,} signups ({pct}%). "
                                f"Channels: {channels}. "
                                f"Market: {spec.get(\'market_size\', \'\')}."
                            )
                            priority = template["priority"]

                        new_task = Task(
                            id=str(uuid.uuid4()),
                            product_id=pid,
                            agent_type=AgentType(a_type),
                            task_type=t_type,
                            instruction=instruction,
                            priority=priority,
                            status=TaskStatus.PENDING,
                        )
                        session.add(new_task)

                actions_taken.append(f"queued_growth_tasks:{slug}")'''

new_growth_loop = '''        # Determine task templates per product status:
        # BUILDING products → BUILD_TASKS_PER_PRODUCT
        # MONETIZING / DEPLOYED / GROWING products → GROWTH_TASKS_PER_PRODUCT
        BUILD_STATUSES = {"building", "ideating"}
        MONETIZE_STATUSES = {"monetizing", "deployed", "growing", "optimizing"}

        for product in products:
            pid = product["id"]
            slug = product["slug"]
            product_status = product.get("status", "building")
            spec = portfolio_map.get(slug, {})
            user_target = spec.get("user_target", 10000)
            current_signups = product.get("signups", 0)
            pct = round(current_signups / user_target * 100, 1) if user_target else 0
            channels = ", ".join(spec.get("growth_channels", []))

            progress.append(
                {
                    "product": product["name"],
                    "slug": slug,
                    "status": product_status,
                    "signups": current_signups,
                    "target": user_target,
                    "pct_to_goal": pct,
                    "price_monthly": spec.get("price_monthly", 0),
                }
            )
            log.info(
                "meta_agent.growth_progress",
                product=slug,
                status=product_status,
                signups=current_signups,
                target=user_target,
                pct=pct,
            )

            # Select task template list based on product status
            if product_status in BUILD_STATUSES:
                task_templates = BUILD_TASKS_PER_PRODUCT
                phase_label = "BUILD"
            else:
                task_templates = GROWTH_TASKS_PER_PRODUCT
                phase_label = "GROWTH"

            # Queue tasks if this product has < 3 pending tasks
            if pending_by_product.get(pid, 0) < 3:
                async with get_db_session() as session:
                    for template in task_templates:
                        # Every 8th loop: upgrade collect_metrics → generate_insights
                        if (
                            loop_count % 8 == 0
                            and template["task_type"] == "collect_metrics"
                        ):
                            t_type = "generate_insights"
                            a_type = "data"
                            instruction = (
                                f"Analyse {product[\'name\']} growth performance and "
                                f"recommend the top 3 acquisition actions to accelerate "
                                f"toward {user_target:,} users. "
                                f"Current signups: {current_signups:,} ({pct}% of goal). "
                                f"Market: {spec.get(\'market_size\', \'\')}."
                            )
                            priority = 8
                        else:
                            t_type = template["task_type"]
                            a_type = template["agent_type"]
                            instruction = (
                                f"[{phase_label} MODE] {product[\'name\']} — "
                                f"{t_type.replace(\'_\', \' \')}. "
                                f"Status: {product_status}. "
                                f"Goal: {user_target:,} users | "
                                f"Progress: {current_signups:,} signups ({pct}%). "
                                f"Channels: {channels}. "
                                f"Market: {spec.get(\'market_size\', \'\')}."
                            )
                            priority = template["priority"]

                        new_task = Task(
                            id=str(uuid.uuid4()),
                            product_id=pid,
                            agent_type=AgentType(a_type),
                            task_type=t_type,
                            instruction=instruction,
                            priority=priority,
                            status=TaskStatus.PENDING,
                        )
                        session.add(new_task)

                actions_taken.append(f"queued_{phase_label.lower()}_tasks:{slug}")'''

if old_growth_loop in content:
    content = content.replace(old_growth_loop, new_growth_loop)
    print("Replaced growth loop body successfully")
else:
    print("ERROR: Could not find old growth loop body")
    # Let's check what the actual content looks like
    # Find the approximate region
    idx = content.find("# Queue growth tasks if this product has < 3 pending tasks")
    if idx >= 0:
        print(f"Found queue comment at index {idx}")
        print("Nearby content:")
        print(repr(content[idx-200:idx+200]))
    sys.exit(1)

# ── 4. Update docstring for _growth_mode_orchestrate ──────────────────────────
old_docstring = '''        GROWTH MODE \u2014 all 5 portfolio products are live.

        Every loop: queue GROWTH_TASKS_PER_PRODUCT for each product with
                    fewer than 3 pending tasks.
        Every 8th loop: substitute a generate_insights task so the AI
                        reviews strategy and recommends growth adjustments.
        Logs real-time progress toward the 10,000-user target per product.'''

new_docstring = '''        COMPREHENSIVE LOOP \u2014 all 5 portfolio products are active.

        Every loop: queue BUILD_TASKS for products in BUILDING status,
                    queue GROWTH_TASKS for products in MONETIZING/DEPLOYED/GROWING.
                    Round-robins across ALL 5 products \u2014 no product left idle.
        Every 8th loop: substitute a generate_insights task so the AI
                        reviews strategy and recommends growth adjustments.
        Logs real-time progress toward the 10,000-user target per product.'''

if old_docstring in content:
    content = content.replace(old_docstring, new_docstring)
    print("Replaced _growth_mode_orchestrate docstring successfully")
else:
    print("WARNING: Could not find old docstring (skipping)")

# Write back
with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("Done! meta_agent.py patched successfully.")
