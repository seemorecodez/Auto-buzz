"""
Build working signup section injected into landing pages +
full checkout pages with ETH/USDC payment widget for all 3 products.
"""
import asyncio, httpx, json, os
from pathlib import Path

VERCEL_TOKEN = "vcp_1payYjuNvmliXyrHQnpUIh3ZsHMNFHuJqOOEgokPs4qTLpUOFV4Jvqov"
KIT_API_KEY  = "gXr2KJjBhZYPT9rSgvmrIw"

PRODUCTS = [
    {
        "name": "ContractCraft",
        "slug": "contractcraft",
        "tagline": "AI-powered contract drafting for freelancers & SMBs",
        "price_monthly": 29,
        "price_annual": 290,
        "price_eth": "0.0132",
        "price_usdc": "29",
        "wallet": "0x237656B0AC4e066f57A0D6B99938c202C01F396d",
        "color": "#6366f1",
        "color2": "#8b5cf6",
        "features": ["Unlimited AI contract drafts", "e-Signature ready", "Template library (200+)", "Legal clause suggestions", "Team collaboration"],
        "trial_days": 14,
    },
    {
        "name": "HireFlow",
        "slug": "hireflow",
        "tagline": "Hire 3x faster with AI-powered candidate screening",
        "price_monthly": 29,
        "price_annual": 290,
        "price_eth": "0.0133",
        "price_usdc": "29",
        "wallet": "0x0199C71Cd697D22b35125684dcC99C2275912dbE",
        "color": "#0ea5e9",
        "color2": "#6366f1",
        "features": ["AI resume screening", "Auto-schedule interviews", "Culture fit scoring", "ATS integration", "Offer letter generator"],
        "trial_days": 14,
    },
    {
        "name": "SupportSage",
        "slug": "supportsage",
        "tagline": "Auto-resolve 80% of support tickets with AI",
        "price_monthly": 39,
        "price_annual": 390,
        "price_eth": "0.0178",
        "price_usdc": "39",
        "wallet": "0x0305aBf9f803866AB4A00A90268dc2EDc0FF97fd",
        "color": "#10b981",
        "color2": "#0ea5e9",
        "features": ["AI ticket auto-resolution", "Sentiment-based routing", "Knowledge base builder", "Multi-channel (email, chat, Slack)", "Real-time CSAT dashboard"],
        "trial_days": 14,
    },
]


# ── Signup section HTML (injected before </body>) ────────────────────────────
def signup_section(p):
    features_html = "".join(
        f'<li class="flex items-center gap-2 text-sm text-gray-300"><span class="text-green-400">✓</span>{f}</li>'
        for f in p["features"]
    )
    return f"""
<!-- ── SIGNUP SECTION ──────────────────────────────────────── -->
<section id="signup" style="background:linear-gradient(135deg,{p['color']}22,{p['color2']}22);border-top:1px solid {p['color']}44" class="py-20 px-6">
  <div class="max-w-4xl mx-auto text-center">
    <span style="background:{p['color']}33;color:{p['color']}" class="inline-block text-sm font-semibold px-4 py-1 rounded-full mb-4">
      Start your {p['trial_days']}-day free trial
    </span>
    <h2 class="text-4xl font-black text-white mb-3">Start for Free Today</h2>
    <p class="text-gray-400 mb-10 max-w-xl mx-auto">No credit card required. Cancel anytime. Full access during trial.</p>

    <div class="max-w-md mx-auto bg-gray-900 border border-gray-800 rounded-2xl p-8 text-left shadow-2xl">
      <form id="signup-form" onsubmit="handleSignup(event)">
        <div class="mb-4">
          <label class="block text-xs font-semibold text-gray-400 mb-1 uppercase tracking-wide">First Name</label>
          <input id="sf-name" type="text" placeholder="Your name" required
            class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500"/>
        </div>
        <div class="mb-4">
          <label class="block text-xs font-semibold text-gray-400 mb-1 uppercase tracking-wide">Work Email</label>
          <input id="sf-email" type="email" placeholder="you@company.com" required
            class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500"/>
        </div>
        <div class="mb-6">
          <label class="block text-xs font-semibold text-gray-400 mb-1 uppercase tracking-wide">Plan</label>
          <select id="sf-plan"
            class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500">
            <option value="trial">Free Trial — {p['trial_days']} days full access</option>
            <option value="monthly">Monthly — ${p['price_monthly']}/mo</option>
            <option value="annual">Annual — ${p['price_annual']}/yr (save 17%)</option>
          </select>
        </div>
        <button type="submit" id="sf-btn"
          style="background:linear-gradient(135deg,{p['color']},{p['color2']})"
          class="w-full text-white font-bold py-3 rounded-xl text-sm hover:opacity-90 transition">
          Start Free Trial →
        </button>
        <div id="sf-msg" class="mt-4 text-center text-sm hidden"></div>
      </form>
      <ul class="mt-6 space-y-2">{features_html}</ul>
    </div>
  </div>
</section>

<script>
async function handleSignup(e) {{
  e.preventDefault();
  const btn = document.getElementById('sf-btn');
  const msg = document.getElementById('sf-msg');
  const name = document.getElementById('sf-name').value.trim();
  const email = document.getElementById('sf-email').value.trim();
  const plan = document.getElementById('sf-plan').value;

  btn.textContent = 'Processing…';
  btn.disabled = true;

  try {{
    // Add subscriber to Kit via our serverless endpoint
    const res = await fetch('https://api.convertkit.com/v3/forms/subscribe', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{
        api_key: '{KIT_API_KEY}',
        email,
        first_name: name,
        fields: {{ product: '{p['name']}', plan }}
      }})
    }});

    if (plan === 'trial') {{
      msg.innerHTML = '🎉 <strong class="text-green-400">Welcome!</strong> Check your email to activate your free trial.';
    }} else {{
      // Redirect to checkout
      window.location.href = '/checkout.html?plan=' + plan + '&email=' + encodeURIComponent(email) + '&name=' + encodeURIComponent(name);
      return;
    }}
    msg.classList.remove('hidden');
    msg.classList.add('text-green-400');
    btn.textContent = '✓ Check your inbox';
  }} catch(err) {{
    msg.innerHTML = '<span class="text-red-400">Something went wrong. Please try again.</span>';
    msg.classList.remove('hidden');
    btn.textContent = 'Start Free Trial →';
    btn.disabled = false;
  }}
}}
</script>
"""

# ── Checkout page ─────────────────────────────────────────────────────────────
def checkout_page(p):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>Checkout — {p['name']}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {{ font-family: 'Inter', sans-serif; }}
    .gradient-border {{ background: linear-gradient(135deg, {p['color']}, {p['color2']}); padding: 1px; border-radius: 16px; }}
  </style>
</head>
<body class="bg-gray-950 text-white min-h-screen">

  <!-- Header -->
  <header class="border-b border-gray-800 py-5 px-6 flex items-center gap-3">
    <a href="/" class="text-gray-400 hover:text-white text-sm">← Back</a>
    <span class="text-gray-700">|</span>
    <span class="font-bold text-lg" style="color:{p['color']}">{p['name']}</span>
    <span class="ml-auto text-xs text-gray-500 flex items-center gap-1">🔒 Secure checkout</span>
  </header>

  <main class="max-w-5xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-10">

    <!-- Left: Plan selector + user info -->
    <div>
      <h1 class="text-3xl font-black mb-2">Complete Your Order</h1>
      <p class="text-gray-400 text-sm mb-8">{p['tagline']}</p>

      <!-- Plan Toggle -->
      <div class="mb-6">
        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Select Plan</p>
        <div class="grid grid-cols-2 gap-3">
          <label id="plan-monthly" class="plan-card cursor-pointer bg-gray-900 border-2 border-indigo-500 rounded-xl p-4 flex flex-col">
            <input type="radio" name="plan" value="monthly" checked class="hidden"/>
            <span class="font-bold text-white text-lg">${p['price_monthly']}<span class="text-sm text-gray-400">/mo</span></span>
            <span class="text-xs text-gray-400 mt-1">Monthly</span>
            <span class="text-xs text-green-400 mt-2">Billed monthly</span>
          </label>
          <label id="plan-annual" class="plan-card cursor-pointer bg-gray-900 border-2 border-gray-700 rounded-xl p-4 flex flex-col">
            <input type="radio" name="plan" value="annual" class="hidden"/>
            <span class="font-bold text-white text-lg">${p['price_annual']}<span class="text-sm text-gray-400">/yr</span></span>
            <span class="text-xs text-gray-400 mt-1">Annual</span>
            <span class="text-xs text-green-400 mt-2">Save 17%</span>
          </label>
        </div>
      </div>

      <!-- User info -->
      <div class="space-y-3 mb-6">
        <input id="co-name" type="text" placeholder="First name" value=""
          class="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500"/>
        <input id="co-email" type="email" placeholder="Email address" value=""
          class="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500"/>
      </div>

      <!-- What's included -->
      <div class="bg-gray-900 border border-gray-800 rounded-xl p-4 mb-6">
        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">What's included</p>
        <ul class="space-y-2">
          {''.join(f'<li class="flex items-center gap-2 text-sm text-gray-300"><span class="text-green-400">✓</span>{f}</li>' for f in p['features'])}
          <li class="flex items-center gap-2 text-sm text-gray-300"><span class="text-green-400">✓</span>{p['trial_days']}-day money-back guarantee</li>
          <li class="flex items-center gap-2 text-sm text-gray-300"><span class="text-green-400">✓</span>Cancel anytime</li>
        </ul>
      </div>
    </div>

    <!-- Right: Payment -->
    <div>
      <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
        <h2 class="font-bold text-lg mb-1">Pay with Crypto</h2>
        <p class="text-xs text-gray-400 mb-6">Send exactly the amount shown to the wallet address below. Your account activates within 1–3 confirmations.</p>

        <!-- Currency tabs -->
        <div class="flex gap-2 mb-5">
          <button onclick="showCurrency('eth')" id="tab-eth"
            class="currency-tab flex-1 py-2 rounded-lg text-sm font-bold bg-indigo-600 text-white transition">ETH</button>
          <button onclick="showCurrency('usdc')" id="tab-usdc"
            class="currency-tab flex-1 py-2 rounded-lg text-sm font-bold bg-gray-800 text-gray-400 transition">USDC</button>
        </div>

        <!-- ETH panel -->
        <div id="panel-eth">
          <div class="bg-gray-800 rounded-xl p-4 mb-4 flex items-center justify-between">
            <div>
              <p class="text-xs text-gray-400 mb-1">Amount to send</p>
              <p id="amt-eth" class="text-2xl font-black text-white">{p['price_eth']} ETH</p>
              <p class="text-xs text-gray-500 mt-1">≈ ${p['price_monthly']} USD/month</p>
            </div>
            <button onclick="copyToClipboard('{p['price_eth']}')" class="text-xs text-indigo-400 hover:text-indigo-300 bg-gray-700 px-3 py-1 rounded-lg">Copy</button>
          </div>
          <div class="bg-gray-800 rounded-xl p-4 mb-4">
            <p class="text-xs text-gray-400 mb-2">Send ETH to this address</p>
            <div class="flex items-center gap-2">
              <code id="addr-eth" class="text-xs text-green-400 break-all flex-1">{p['wallet']}</code>
              <button onclick="copyToClipboard('{p['wallet']}')" class="text-xs text-indigo-400 hover:text-indigo-300 bg-gray-700 px-3 py-1 rounded-lg flex-shrink-0">Copy</button>
            </div>
          </div>
          <div class="bg-gray-800 rounded-xl p-3 text-center mb-4">
            <p class="text-xs text-gray-400 mb-2">Or scan QR code</p>
            <div class="w-32 h-32 bg-white rounded-lg mx-auto flex items-center justify-center p-2">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=ethereum:{p['wallet']}%3Fvalue={p['price_eth']}" 
                   alt="QR Code" class="w-full h-full"/>
            </div>
          </div>
        </div>

        <!-- USDC panel -->
        <div id="panel-usdc" class="hidden">
          <div class="bg-gray-800 rounded-xl p-4 mb-4 flex items-center justify-between">
            <div>
              <p class="text-xs text-gray-400 mb-1">Amount to send</p>
              <p class="text-2xl font-black text-white">{p['price_usdc']} USDC</p>
              <p class="text-xs text-gray-500 mt-1">ERC-20 on Ethereum mainnet</p>
            </div>
            <button onclick="copyToClipboard('{p['price_usdc']}')" class="text-xs text-indigo-400 hover:text-indigo-300 bg-gray-700 px-3 py-1 rounded-lg">Copy</button>
          </div>
          <div class="bg-gray-800 rounded-xl p-4 mb-4">
            <p class="text-xs text-gray-400 mb-2">Send USDC (ERC-20) to this address</p>
            <div class="flex items-center gap-2">
              <code class="text-xs text-green-400 break-all flex-1">{p['wallet']}</code>
              <button onclick="copyToClipboard('{p['wallet']}')" class="text-xs text-indigo-400 hover:text-indigo-300 bg-gray-700 px-3 py-1 rounded-lg flex-shrink-0">Copy</button>
            </div>
          </div>
          <div class="bg-gray-800 rounded-xl p-3 text-center mb-4">
            <p class="text-xs text-gray-400 mb-2">Or scan QR code</p>
            <div class="w-32 h-32 bg-white rounded-lg mx-auto flex items-center justify-center p-2">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=ethereum:{p['wallet']}" 
                   alt="QR Code" class="w-full h-full"/>
            </div>
          </div>
        </div>

        <!-- Confirm payment button -->
        <button onclick="confirmPayment()"
          style="background:linear-gradient(135deg,{p['color']},{p['color2']})"
          class="w-full text-white font-bold py-3 rounded-xl text-sm hover:opacity-90 transition mb-3">
          I've Sent Payment — Activate My Account
        </button>
        <div id="pay-msg" class="text-center text-sm hidden"></div>

        <p class="text-xs text-gray-500 text-center mt-4">
          Having trouble? Email <a href="mailto:support@{p['slug']}.app" class="text-indigo-400">support@{p['slug']}.app</a>
        </p>
      </div>

      <!-- Trust badges -->
      <div class="flex items-center justify-center gap-6 mt-6 text-xs text-gray-500">
        <span>🔒 Encrypted</span>
        <span>✓ Instant activation</span>
        <span>↩ 14-day refund</span>
      </div>
    </div>
  </main>

  <script>
    // Pre-fill from URL params
    const params = new URLSearchParams(window.location.search);
    if (params.get('email')) document.getElementById('co-email').value = params.get('email');
    if (params.get('name'))  document.getElementById('co-name').value  = params.get('name');
    if (params.get('plan') === 'annual') {{
      document.getElementById('plan-annual').querySelector('input').checked = true;
      document.getElementById('plan-annual').style.borderColor = '#6366f1';
      document.getElementById('plan-monthly').style.borderColor = '#374151';
      document.getElementById('amt-eth').textContent = '{float(p["price_eth"])*10:.4f} ETH';
    }}

    // Plan selection
    document.querySelectorAll('.plan-card').forEach(card => {{
      card.addEventListener('click', () => {{
        document.querySelectorAll('.plan-card').forEach(c => c.style.borderColor = '#374151');
        card.style.borderColor = '#6366f1';
        const isAnnual = card.id === 'plan-annual';
        document.getElementById('amt-eth').textContent = (isAnnual ? '{float(p["price_eth"])*10:.4f}' : '{p["price_eth"]}') + ' ETH';
      }});
    }});

    function showCurrency(cur) {{
      document.getElementById('panel-eth').classList.toggle('hidden', cur !== 'eth');
      document.getElementById('panel-usdc').classList.toggle('hidden', cur !== 'usdc');
      document.getElementById('tab-eth').className = 'currency-tab flex-1 py-2 rounded-lg text-sm font-bold transition ' + (cur==='eth' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-400');
      document.getElementById('tab-usdc').className = 'currency-tab flex-1 py-2 rounded-lg text-sm font-bold transition ' + (cur==='usdc' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-400');
    }}

    function copyToClipboard(text) {{
      navigator.clipboard.writeText(text).then(() => {{
        const btn = event.target;
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy', 1500);
      }});
    }}

    async function confirmPayment() {{
      const email = document.getElementById('co-email').value.trim();
      const name  = document.getElementById('co-name').value.trim();
      const msg   = document.getElementById('pay-msg');

      if (!email) {{ alert('Please enter your email address.'); return; }}

      // Tag them in Kit as paid
      try {{
        await fetch('https://api.convertkit.com/v3/forms/subscribe', {{
          method: 'POST',
          headers: {{'Content-Type': 'application/json'}},
          body: JSON.stringify({{
            api_key: '{KIT_API_KEY}',
            email,
            first_name: name,
            fields: {{ product: '{p['name']}', status: 'paid_pending_confirm' }}
          }})
        }});
      }} catch(e) {{}}

      msg.innerHTML = '✅ <strong class="text-green-400">Payment received!</strong> We\'ll verify on-chain and email you within 15 minutes to activate your account.';
      msg.classList.remove('hidden');
    }}
  </script>
</body>
</html>"""


async def deploy_product(p: dict):
    slug = p["slug"]
    pages_dir = Path(f"/tmp/acai_pages/{slug}")
    pages_dir.mkdir(parents=True, exist_ok=True)

    # 1. Read existing index.html and inject signup section
    idx = pages_dir / "index.html"
    if idx.exists():
        html = idx.read_text(encoding="utf-8")
        # Remove any old signup section
        if '<section id="signup"' in html:
            import re
            html = re.sub(r'<!-- ── SIGNUP SECTION.*?</script>', '', html, flags=re.DOTALL)
        # Inject before </body>
        html = html.replace("</body>", signup_section(p) + "\n</body>")
        idx.write_text(html, encoding="utf-8")
        print(f"  {p['name']}: injected signup into index.html ({len(html)} bytes)")
    else:
        print(f"  {p['name']}: WARNING — no index.html, writing standalone")
        idx.write_text(signup_section(p), encoding="utf-8")

    # 2. Write checkout.html
    co = pages_dir / "checkout.html"
    co.write_text(checkout_page(p), encoding="utf-8")
    print(f"  {p['name']}: wrote checkout.html ({len(checkout_page(p))} bytes)")

    # 3. Collect all files
    files = []
    for fpath in pages_dir.rglob("*"):
        if fpath.is_file() and fpath.suffix not in (".png",):
            rel = str(fpath.relative_to(pages_dir))
            files.append({"file": rel, "data": fpath.read_text(encoding="utf-8", errors="replace")})
        elif fpath.is_file() and fpath.suffix == ".png":
            import base64
            rel = str(fpath.relative_to(pages_dir))
            files.append({"file": rel, "data": base64.b64encode(fpath.read_bytes()).decode(), "encoding": "base64"})

    # 4. Deploy to Vercel
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            "https://api.vercel.com/v13/deployments",
            headers={"Authorization": f"Bearer {VERCEL_TOKEN}", "Content-Type": "application/json"},
            json={"name": slug, "files": files, "projectSettings": {"framework": None}},
        )
        data = resp.json()
    url = f"https://{data.get('url', 'ERROR')}"
    print(f"  {p['name']}: deployed → {url}")
    return url


async def main():
    print("Building and deploying signup flows for all products...\n")
    urls = {}
    for p in PRODUCTS:
        print(f"=== {p['name']} ===")
        url = await deploy_product(p)
        urls[p["slug"]] = url
        print()

    print("=== Final URLs ===")
    for slug, url in urls.items():
        print(f"  {slug}: {url}")

    # Update DB
    import subprocess
    for slug, url in urls.items():
        subprocess.run([
            "psql", "-U", "acai", "-d", "autonomous_company", "-h", "localhost",
            "-c", f"UPDATE products SET deploy_url = '{url}' WHERE slug = '{slug}';"
        ], env={**os.environ, "PGPASSWORD": "acai_dev"}, capture_output=True)
    print("DB updated.")

asyncio.run(main())
