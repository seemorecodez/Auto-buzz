#!/usr/bin/env bash
# =============================================================================
# Autonomous Company AI — Setup Script
# =============================================================================
set -euo pipefail

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}"
cat << 'EOF'
  ___         _                                              
 / _ \       | |                                             
/ /_\ \_   _ | |_  ___  _ __    ___   _ __ ___    ___   _   _ ___ 
|  _  || | | || __|/ _ \| '_ \  / _ \ | '_ ` _ \  / _ \ | | | / __|
| | | || |_| || |_| (_) | | | || (_) || | | | | || (_) || |_| \__ \
\_| |_/ \__,_| \__|\___/|_| |_| \___/ |_| |_| |_| \___/  \__,_|___/

           Autonomous Company AI — Setup
EOF
echo -e "${NC}"

# ── Check prerequisites ───────────────────────────────────────────────────────
echo -e "${YELLOW}[1/5] Checking prerequisites...${NC}"

for cmd in docker docker-compose python3 pip; do
    if ! command -v $cmd &> /dev/null; then
        echo -e "${RED}ERROR: $cmd not found. Please install it first.${NC}"
        exit 1
    fi
done

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "  ✓ Docker found"
echo "  ✓ Python $PYTHON_VERSION found"

# ── .env file ─────────────────────────────────────────────────────────────────
echo -e "\n${YELLOW}[2/5] Setting up environment...${NC}"

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "  ${GREEN}✓ .env created from .env.example${NC}"
    echo -e "  ${RED}ACTION REQUIRED: Edit .env and set your OPENAI_API_KEY${NC}"
else
    echo "  ✓ .env already exists"
fi

# Check OPENAI_API_KEY
if grep -q "sk-placeholder\|sk-\.\.\." .env 2>/dev/null; then
    echo -e "  ${YELLOW}WARNING: OPENAI_API_KEY appears to be a placeholder.${NC}"
    echo "  The system requires a real OpenAI API key to function."
fi

# ── Python virtual environment ────────────────────────────────────────────────
echo -e "\n${YELLOW}[3/5] Setting up Python virtual environment...${NC}"

if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "  ✓ Virtual environment created"
fi

source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo "  ✓ Python dependencies installed"

# ── Build Docker images ───────────────────────────────────────────────────────
echo -e "\n${YELLOW}[4/5] Building Docker images...${NC}"
docker-compose build --parallel
echo "  ✓ Docker images built"

# ── Create build directories ──────────────────────────────────────────────────
echo -e "\n${YELLOW}[5/5] Creating runtime directories...${NC}"
mkdir -p /tmp/acai_builds /tmp/acai_pages
echo "  ✓ Runtime directories created"

# ── Done ──────────────────────────────────────────────────────────────────────
echo -e "\n${GREEN}============================================${NC}"
echo -e "${GREEN}  Setup complete!${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""
echo "Next steps:"
echo ""
echo "  1. Edit .env and set OPENAI_API_KEY"
echo "  2. Start the stack:  docker-compose up -d"
echo "  3. Watch logs:       docker-compose logs -f api"
echo "  4. Open API docs:    http://localhost:8000/docs"
echo "  5. Monitor tasks:    http://localhost:5555"
echo ""
echo "  Or run the example launch:"
echo "    python scripts/run_example.py"
echo ""
