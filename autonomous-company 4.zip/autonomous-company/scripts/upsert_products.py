"""
Upsert all 5 products into the database.
"""
import asyncio
import asyncpg
import os
import uuid

os.environ.setdefault("DATABASE_URL", "postgresql://acai:acai_dev@localhost/autonomous_company")

PRODUCTS = [
    {
        "name": "ContractCraft",
        "slug": "contractcraft",
        "description": "AI-powered contract drafting for freelancers and SMBs",
        "niche": "Legal Tech",
        "target_audience": "Freelancers, consultants, small businesses",
        "value_proposition": "Generate professional contracts in seconds with AI",
        "price_monthly": 29.0,
        "price_annual": 290.0,
        "tech_stack": "Static HTML + Mistral AI",
        "status": "monetizing",
        "deploy_url": "https://contractcraft-g3t1l5ft4-f88t4ztvbg-8187s-projects.vercel.app",
    },
    {
        "name": "BuildFlow",
        "slug": "buildflow",
        "description": "AI project management and estimating for contractors",
        "niche": "Construction SaaS",
        "target_audience": "Independent contractors, small construction companies",
        "value_proposition": "Run your entire contracting business from one AI-powered app",
        "price_monthly": 39.0,
        "price_annual": 390.0,
        "tech_stack": "Static HTML + Mistral AI",
        "status": "building",
        "deploy_url": "",
    },
    {
        "name": "CreatorLedger",
        "slug": "creatorledger",
        "description": "Revenue dashboard that unifies all creator income streams",
        "niche": "Creator Economy",
        "target_audience": "YouTubers, Substack writers, podcasters, course creators",
        "value_proposition": "See all your creator income in one place",
        "price_monthly": 19.0,
        "price_annual": 190.0,
        "tech_stack": "Static HTML + Mistral AI",
        "status": "building",
        "deploy_url": "",
    },
    {
        "name": "PitchForge",
        "slug": "pitchforge",
        "description": "AI pitch deck and investor materials generator for startups",
        "niche": "Startup Productivity",
        "target_audience": "Pre-seed and seed-stage startup founders",
        "value_proposition": "Generate investor-ready pitch decks in minutes",
        "price_monthly": 24.0,
        "price_annual": 240.0,
        "tech_stack": "Static HTML + Mistral AI",
        "status": "building",
        "deploy_url": "",
    },
    {
        "name": "AuditMind",
        "slug": "auditmind",
        "description": "AI bookkeeping and financial audit assistant for small businesses",
        "niche": "SMB FinTech",
        "target_audience": "Small business owners, solo operators, side hustlers",
        "value_proposition": "Your AI bookkeeper without the bookkeeper price tag",
        "price_monthly": 15.0,
        "price_annual": 150.0,
        "tech_stack": "Static HTML + Mistral AI",
        "status": "building",
        "deploy_url": "",
    },
]


async def main():
    conn = await asyncpg.connect("postgresql://acai:acai_dev@localhost/autonomous_company")
    for p in PRODUCTS:
        # Upsert — insert if not exists, update if exists
        existing = await conn.fetchrow("SELECT id FROM products WHERE slug = $1", p["slug"])
        if existing:
            await conn.execute("""
                UPDATE products SET name=$1, description=$2, niche=$3, target_audience=$4,
                value_proposition=$5, price_monthly=$6, price_annual=$7, tech_stack=$8,
                status=$9, deploy_url=$10 WHERE slug=$11
            """, p["name"], p["description"], p["niche"], p["target_audience"],
                p["value_proposition"], p["price_monthly"], p["price_annual"],
                p["tech_stack"], p["status"], p["deploy_url"], p["slug"])
            print(f"Updated: {p['name']}")
        else:
            await conn.execute("""
                INSERT INTO products (id, name, slug, description, niche, target_audience,
                value_proposition, price_monthly, price_annual, tech_stack, status, deploy_url,
                mrr, arr, total_revenue, visitors, signups, paid_customers, churn_rate)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
            """, str(uuid.uuid4()), p["name"], p["slug"], p["description"], p["niche"],
                p["target_audience"], p["value_proposition"], p["price_monthly"],
                p["price_annual"], p["tech_stack"], p["status"], p["deploy_url"],
                0.0, 0.0, 0.0, 0, 0, 0, 0.0)
            print(f"Inserted: {p['name']}")

    rows = await conn.fetch("SELECT name, slug, status, price_monthly FROM products ORDER BY created_at")
    for r in rows:
        print(f"  {r['name']} ({r['slug']}) — {r['status']} — ${r['price_monthly']}/mo")
    await conn.close()


asyncio.run(main())
