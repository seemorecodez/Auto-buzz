#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# ACAI Watchdog — auto-restarts the server if it ever crashes
# ─────────────────────────────────────────────────────────────
set -euo pipefail

LOGFILE="/tmp/acai.log"
RESTART_LOG="/tmp/acai_watchdog.log"
RESTART_DELAY=5   # seconds to wait before restarting
MAX_RESTARTS=999  # effectively unlimited

export POSTGRES_HOST=localhost
export POSTGRES_PASSWORD=acai_dev

restarts=0

log() {
  echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] [watchdog] $*" | tee -a "$RESTART_LOG"
}

log "Watchdog started. Server will auto-restart on crash."

while [ "$restarts" -lt "$MAX_RESTARTS" ]; do
  log "Starting server (attempt $((restarts + 1)))..."

  # Run uvicorn; tee output to log file
  python3 -m uvicorn api.main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --log-level info \
    2>&1 | tee -a "$LOGFILE" || true

  restarts=$((restarts + 1))
  log "Server exited (restart #$restarts). Waiting ${RESTART_DELAY}s before restart..."
  sleep "$RESTART_DELAY"
done

log "Max restarts ($MAX_RESTARTS) reached. Watchdog stopping."
