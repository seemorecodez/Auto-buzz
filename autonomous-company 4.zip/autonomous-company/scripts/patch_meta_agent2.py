"""
Patch meta_agent.py using line-based replacement.
"""
import sys

path = "/home/user/workspace/autonomous-company/agents/meta_agent.py"
with open(path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# ── 1. Replace lines 158-184 (0-indexed: 157-183) with new task lists ─────────
# Line 158 = "# Growth-mode task templates..."
# Line 184 = "]"

new_task_lists = '''\
# Build-phase task templates: for products in BUILDING / IDEATING status
# Queue these to generate landing pages, build MVPs, and set up payments
BUILD_TASKS_PER_PRODUCT: list[dict] = [
    # -- Core Build ----------------------------------------------------------------
    {"task_type": "generate_landing_page",  "agent_type": "content",      "priority": 10},
    {"task_type": "build_mvp",              "agent_type": "builder",      "priority": 9},
    # -- Payments & Monetization ---------------------------------------------------
    {"task_type": "setup_wallet",           "agent_type": "monetization", "priority": 9},
    {"task_type": "create_checkout_page",   "agent_type": "monetization", "priority": 8},
    {"task_type": "setup_free_trial",       "agent_type": "monetization", "priority": 7},
]

# Growth-mode task templates: for products in MONETIZING / DEPLOYED / GROWING status
# Every loop: queue GROWTH_TASKS_PER_PRODUCT for each product with fewer than 3 pending tasks
GROWTH_TASKS_PER_PRODUCT: list[dict] = [
    # -- Revenue -------------------------------------------------------------------
    {"task_type": "generate_leads",           "agent_type": "growth",       "priority": 9},
    {"task_type": "run_outreach",             "agent_type": "growth",       "priority": 9},
    {"task_type": "send_drip_sequence",       "agent_type": "growth",       "priority": 9},
    {"task_type": "multi_touch_outreach",     "agent_type": "growth",       "priority": 8},
    {"task_type": "create_checkout_page",     "agent_type": "monetization", "priority": 9},
    {"task_type": "add_ltd_tier",             "agent_type": "monetization", "priority": 7},
    # -- SEO & Content Traffic -----------------------------------------------------
    {"task_type": "write_seo_blog_post",      "agent_type": "content",      "priority": 8},
    {"task_type": "write_comparison_page",    "agent_type": "content",      "priority": 7},
    {"task_type": "write_niche_page",         "agent_type": "content",      "priority": 7},
    {"task_type": "write_ph_kit",             "agent_type": "content",      "priority": 6},
    {"task_type": "generate_sitemap",         "agent_type": "builder",      "priority": 6},
    {"task_type": "generate_social_content",  "agent_type": "content",      "priority": 7},
    # -- Conversion ----------------------------------------------------------------
    {"task_type": "add_exit_intent",          "agent_type": "builder",      "priority": 8},
    {"task_type": "add_social_proof",         "agent_type": "builder",      "priority": 8},
    {"task_type": "run_ab_test",              "agent_type": "content",      "priority": 7},
    {"task_type": "expand_features",          "agent_type": "builder",      "priority": 6},
    {"task_type": "score_leads",              "agent_type": "data",         "priority": 7},
    # -- Scale & Retention ---------------------------------------------------------
    {"task_type": "update_changelog",         "agent_type": "content",      "priority": 6},
    {"task_type": "cross_sell",               "agent_type": "growth",       "priority": 7},
    {"task_type": "setup_affiliate",          "agent_type": "growth",       "priority": 6},
    {"task_type": "collect_metrics",          "agent_type": "data",         "priority": 5},
    {"task_type": "generate_revenue_dashboard","agent_type": "data",        "priority": 6},
    {"task_type": "write_testimonials",       "agent_type": "content",      "priority": 5},
]
'''

# Lines 157-184 are 0-indexed 157 to 183 (inclusive) = indices [157:184]
assert "Growth-mode task templates" in lines[157], f"Unexpected line 158: {lines[157]!r}"
assert lines[183].strip() == "]", f"Unexpected line 184: {lines[183]!r}"

lines[157:184] = [new_task_lists]
print("Replaced GROWTH_TASKS_PER_PRODUCT section")

# Write intermediate result
with open(path, "w", encoding="utf-8") as f:
    f.writelines(lines)

# Reload
with open(path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# ── 2. Find and replace TASK_DECOMPOSITION_SYSTEM content (lines after the new ones) ──
# Find it now
tds_start = None
tds_end = None
for i, line in enumerate(lines):
    if 'TASK_DECOMPOSITION_SYSTEM = """' in line and tds_start is None:
        tds_start = i
    if tds_start is not None and i > tds_start and '"""' in line:
        tds_end = i
        break

print(f"TASK_DECOMPOSITION_SYSTEM: lines {tds_start+1} to {tds_end+1}")

new_tds = '''\
TASK_DECOMPOSITION_SYSTEM = """
You are a product operations manager.
Given a product spec and its current status, return 2-4 tasks to execute next.

You MUST only use the following agent_type + task_type combinations (no others):

builder:
  - build_mvp               (generate full codebase and deploy)
  - add_feature / add_exit_intent / add_social_proof / expand_features / generate_sitemap
  - deploy_niche_page       (deploy a programmatic niche landing page to Vercel)

content:
  - generate_landing_page / write_blog_post / write_social_content / generate_social_content
  - write_seo_blog_post / write_comparison_page / write_niche_page / write_testimonials
  - write_ph_kit / run_ab_test / update_changelog / write_newsletter

growth:
  - generate_leads / run_outreach / send_broadcast / analyse_growth
  - send_drip_sequence / multi_touch_outreach / score_leads
  - cross_sell / setup_affiliate / launch_affiliate_program

monetization:
  - design_pricing / setup_payments / check_payments / setup_wallet / setup_free_trial
  - create_checkout_page / add_ltd_tier

data:
  - collect_metrics / generate_insights / system_report
  - score_leads / generate_revenue_dashboard / check_price_trigger

operator:
  - health_check / retry_failed_tasks

Return ONLY a JSON object with a "tasks" key:
{
  "tasks": [
    {
      "agent_type": "builder",
      "task_type": "build_mvp",
      "instruction": "Build the full MVP for ...",
      "priority": 9
    }
  ]
}

Priority scale: 10=critical, 7-9=high, 4-6=medium, 1-3=low.
For a product in IDEATING or BUILDING status, prioritise: generate_landing_page -> build_mvp -> setup_wallet -> create_checkout_page.
For MONETIZING products, prioritise: write_seo_blog_post, generate_leads, run_outreach, write_niche_page.
NEVER return a bare array. Always wrap in {"tasks": [...]}.
"""
'''

lines[tds_start:tds_end+1] = [new_tds]
print("Replaced TASK_DECOMPOSITION_SYSTEM")

# Write intermediate result
with open(path, "w", encoding="utf-8") as f:
    f.writelines(lines)

# Reload
with open(path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# ── 3. Update the growth loop to dispatch BUILD vs GROWTH tasks ────────────────
# Find the docstring and main loop section
# Look for "# Queue growth tasks if this product has < 3 pending tasks"
queue_line = None
for i, line in enumerate(lines):
    if "Queue growth tasks if this product has < 3 pending tasks" in line:
        queue_line = i
        break

if queue_line is None:
    print("ERROR: Could not find queue comment")
    sys.exit(1)

print(f"Found queue comment at line {queue_line+1}")

# Find the start of the for product in products loop
for_loop_start = None
for i in range(queue_line - 50, queue_line):
    if lines[i].strip().startswith("for product in products:"):
        for_loop_start = i
        break

if for_loop_start is None:
    print("ERROR: Could not find for product loop")
    sys.exit(1)

print(f"for_loop_start at line {for_loop_start+1}")

# Find the end of the for loop (next line at same or lesser indentation level)
# The for loop ends when we hit "actions_taken.append(f"queued_growth_tasks:{slug}")"
loop_end = None
for i in range(queue_line, len(lines)):
    if 'actions_taken.append(f"queued_growth_tasks:' in lines[i]:
        loop_end = i
        break

if loop_end is None:
    print("ERROR: Could not find loop end marker")
    sys.exit(1)

print(f"loop_end at line {loop_end+1}")
print(f"Replacing lines {for_loop_start+1} to {loop_end+1}")

new_loop = '''\
        # Determine task templates per product status:
        # BUILDING / IDEATING products     -> BUILD_TASKS_PER_PRODUCT
        # MONETIZING / DEPLOYED / GROWING  -> GROWTH_TASKS_PER_PRODUCT
        BUILD_STATUSES = {"building", "ideating"}

        for product in products:
            pid = product["id"]
            slug = product["slug"]
            product_status = product.get("status", "building")
            spec = portfolio_map.get(slug, {})
            user_target = spec.get("user_target", 10000)
            current_signups = product.get("signups", 0)
            pct = round(current_signups / user_target * 100, 1) if user_target else 0
            channels = ", ".join(spec.get("growth_channels", []))

            progress.append(
                {
                    "product": product["name"],
                    "slug": slug,
                    "status": product_status,
                    "signups": current_signups,
                    "target": user_target,
                    "pct_to_goal": pct,
                    "price_monthly": spec.get("price_monthly", 0),
                }
            )
            log.info(
                "meta_agent.growth_progress",
                product=slug,
                status=product_status,
                signups=current_signups,
                target=user_target,
                pct=pct,
            )

            # Select task template list based on product status
            if product_status in BUILD_STATUSES:
                task_templates = BUILD_TASKS_PER_PRODUCT
                phase_label = "BUILD"
            else:
                task_templates = GROWTH_TASKS_PER_PRODUCT
                phase_label = "GROWTH"

            # Queue tasks if this product has < 3 pending tasks
            if pending_by_product.get(pid, 0) < 3:
                async with get_db_session() as session:
                    for template in task_templates:
                        # Every 8th loop: upgrade collect_metrics -> generate_insights
                        if (
                            loop_count % 8 == 0
                            and template["task_type"] == "collect_metrics"
                        ):
                            t_type = "generate_insights"
                            a_type = "data"
                            instruction = (
                                f"Analyse {product['name']} growth performance and "
                                f"recommend the top 3 acquisition actions to accelerate "
                                f"toward {user_target:,} users. "
                                f"Current signups: {current_signups:,} ({pct}% of goal). "
                                f"Market: {spec.get('market_size', '')}."
                            )
                            priority = 8
                        else:
                            t_type = template["task_type"]
                            a_type = template["agent_type"]
                            instruction = (
                                f"[{phase_label} MODE] {product['name']} — "
                                f"{t_type.replace('_', ' ')}. "
                                f"Status: {product_status}. "
                                f"Goal: {user_target:,} users | "
                                f"Progress: {current_signups:,} signups ({pct}%). "
                                f"Channels: {channels}. "
                                f"Market: {spec.get('market_size', '')}."
                            )
                            priority = template["priority"]

                        new_task = Task(
                            id=str(uuid.uuid4()),
                            product_id=pid,
                            agent_type=AgentType(a_type),
                            task_type=t_type,
                            instruction=instruction,
                            priority=priority,
                            status=TaskStatus.PENDING,
                        )
                        session.add(new_task)

                actions_taken.append(f"queued_{phase_label.lower()}_tasks:{slug}")
'''

lines[for_loop_start:loop_end+1] = [new_loop]
print("Replaced growth loop body")

# Write final result
with open(path, "w", encoding="utf-8") as f:
    f.writelines(lines)

print("Done! meta_agent.py patched successfully.")
