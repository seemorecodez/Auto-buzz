#!/usr/bin/env python3
"""
Autonomous Company AI — Example Product Launch

Demonstrates a complete product lifecycle:
  1. MetaAgent ideates a new SaaS product
  2. BuilderAgent generates and deploys the MVP
  3. ContentAgent creates the landing page
  4. MonetizationAgent designs pricing and sets up Stripe
  5. GrowthAgent runs the first outreach campaign
  6. DataAgent reports on initial metrics

Run with:
    python scripts/run_example.py

Requirements:
    - .env configured with OPENAI_API_KEY
    - PostgreSQL and Redis running (via docker-compose or locally)
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import datetime

# Ensure the project root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

console = Console()


async def main() -> None:
    console.print(
        Panel.fit(
            "[bold blue]Autonomous Company AI[/bold blue]\n"
            "[dim]Launching a product from zero...[/dim]",
            border_style="blue",
        )
    )

    # ── Init DB ───────────────────────────────────────────────────────
    console.print("\n[yellow]Initialising database...[/yellow]")
    from core.database import init_db
    await init_db()
    console.print("[green]✓ Database ready[/green]")

    # ── Step 1: Ideate product ────────────────────────────────────────
    console.print("\n[bold]Step 1:[/bold] MetaAgent — Ideating a product...")
    from agents.meta_agent import MetaAgent
    meta = MetaAgent()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Analysing market gaps...", total=None)
        result = await meta.run(
            {"task_type": "ideate_product", "instruction": "Find a profitable SaaS niche"}
        )

    if not result.success:
        console.print(f"[red]Ideation failed: {result.error}[/red]")
        return

    product_id = result.output["product_id"]
    product_name = result.output.get("product_name", "")
    niche = result.output.get("niche", "")

    console.print(
        Panel(
            f"[bold green]{product_name}[/bold green]\n"
            f"Niche: [cyan]{niche}[/cyan]\n"
            f"ID: [dim]{product_id}[/dim]\n"
            f"Value prop: {result.output.get('value_proposition', '')[:120]}...",
            title="Product Ideated",
            border_style="green",
        )
    )

    # ── Step 2: Build MVP ─────────────────────────────────────────────
    console.print("\n[bold]Step 2:[/bold] BuilderAgent — Generating MVP...")
    from agents.builder_agent import BuilderAgent
    builder = BuilderAgent()

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        t = p.add_task("Generating full-stack codebase...", total=None)
        build_result = await builder.run(
            {"task_type": "build_mvp", "product_id": product_id,
             "instruction": f"Build and deploy the {product_name} MVP"}
        )

    if build_result.success:
        console.print(
            f"[green]✓ MVP built: {build_result.output.get('files_generated', 0)} files "
            f"→ {build_result.output.get('deploy_url', 'local')}[/green]"
        )
    else:
        console.print(f"[yellow]Build partial: {build_result.error}[/yellow]")

    # ── Step 3: Landing page ──────────────────────────────────────────
    console.print("\n[bold]Step 3:[/bold] ContentAgent — Generating landing page...")
    from agents.content_agent import ContentAgent
    content = ContentAgent()

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        t = p.add_task("Writing landing page copy...", total=None)
        lp_result = await content.run(
            {"task_type": "generate_landing_page", "product_id": product_id,
             "instruction": "Generate a high-converting landing page"}
        )

    if lp_result.success:
        console.print(
            f"[green]✓ Landing page: {lp_result.output.get('output_path', 'generated')}[/green]"
        )
        console.print(f"  Headline: [italic]{lp_result.output.get('headline', '')}[/italic]")

    # ── Step 4: Pricing + Stripe ──────────────────────────────────────
    console.print("\n[bold]Step 4:[/bold] MonetizationAgent — Designing pricing...")
    from agents.monetization_agent import MonetizationAgent
    monetization = MonetizationAgent()

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        t = p.add_task("Designing pricing model...", total=None)
        pricing_result = await monetization.run(
            {"task_type": "design_pricing", "product_id": product_id,
             "instruction": "Design a 3-tier pricing model"}
        )

    if pricing_result.success:
        tiers = pricing_result.output.get("tiers", [])
        if tiers:
            table = Table(title="Pricing Tiers", show_header=True)
            table.add_column("Tier", style="cyan")
            table.add_column("Monthly Price", style="green")
            table.add_column("Annual Price", style="yellow")
            for tier in tiers:
                table.add_row(
                    tier.get("name", ""),
                    f"${tier.get('price_monthly', 0)}/mo",
                    f"${tier.get('price_annual', tier.get('price_monthly', 0) * 10)}/yr",
                )
            console.print(table)

    # ── Step 5: Growth outreach ───────────────────────────────────────
    console.print("\n[bold]Step 5:[/bold] GrowthAgent — Running outreach campaign...")
    from agents.growth_agent import GrowthAgent
    growth = GrowthAgent()

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        t = p.add_task("Finding leads and generating campaign...", total=None)
        growth_result = await growth.run(
            {"task_type": "generate_leads", "product_id": product_id,
             "limit": 5, "instruction": "Find qualified leads for outreach"}
        )

    if growth_result.success:
        leads = growth_result.output.get("leads", [])
        console.print(f"[green]✓ {len(leads)} leads generated[/green]")
        for lead in leads[:3]:
            console.print(
                f"  • {lead.get('name', '')} @ {lead.get('company', '')} "
                f"({lead.get('email', '')})"
            )

    # ── Step 6: Data report ───────────────────────────────────────────
    console.print("\n[bold]Step 6:[/bold] DataAgent — Generating initial report...")
    from agents.data_agent import DataAgent
    data = DataAgent()

    report_result = await data.run(
        {"task_type": "generate_report", "product_id": product_id,
         "instruction": "Generate initial product report"}
    )

    if report_result.success:
        insights = report_result.output.get("insights", [])
        if insights:
            console.print("\n[bold]AI Insights:[/bold]")
            for i, insight in enumerate(insights[:3], 1):
                console.print(f"  {i}. {insight}")

    # ── Summary ───────────────────────────────────────────────────────
    console.print(
        Panel(
            f"[bold green]Product Launch Complete![/bold green]\n\n"
            f"Product: [bold]{product_name}[/bold]\n"
            f"Product ID: [dim]{product_id}[/dim]\n"
            f"Deploy URL: {build_result.output.get('deploy_url', 'pending')}\n"
            f"Landing Page: {lp_result.output.get('output_path', 'generated')}\n"
            f"Leads Found: {len(growth_result.output.get('leads', []))}\n\n"
            "[dim]The autonomous loop will continue growing this product "
            "every 5 minutes.[/dim]",
            title="[bold]Launch Summary[/bold]",
            border_style="green",
        )
    )

    console.print(
        "\n[blue]Next: Start the full system with [bold]docker-compose up[/bold] "
        "to enable continuous autonomous operation.[/blue]\n"
    )


if __name__ == "__main__":
    asyncio.run(main())
