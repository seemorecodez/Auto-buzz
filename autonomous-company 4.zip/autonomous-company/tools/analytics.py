"""
AnalyticsTool — reads metrics from the database and computes KPIs.

Used by DataAgent to surface actionable insights and generate reports.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import func, select

from core.database import get_db_session
from core.logger import get_logger
from models.action import Action, ActionStatus
from models.metric import Metric, MetricType
from models.product import Product
from models.task import Task, TaskStatus
from core.llm import get_llm_client, get_primary_model
from core.config import settings

log = get_logger(__name__)


class AnalyticsTool:
    """Computes performance analytics from structured data."""

    def __init__(self) -> None:
        self._llm = get_llm_client()
        self._model = get_primary_model()
    # ── Product KPIs ──────────────────────────────────────────────────
    async def get_product_kpis(
        self, product_id: str, days: int = 30
    ) -> dict[str, Any]:
        """
        Return a comprehensive KPI dict for a single product.
        """
        since = datetime.now(timezone.utc) - timedelta(days=days)
        async with get_db_session() as session:
            # Latest metrics grouped by type
            subq = (
                select(
                    Metric.metric_type,
                    func.max(Metric.created_at).label("latest"),
                )
                .where(Metric.product_id == product_id)
                .group_by(Metric.metric_type)
                .subquery()
            )
            result = await session.execute(
                select(Metric).join(
                    subq,
                    (Metric.metric_type == subq.c.metric_type)
                    & (Metric.created_at == subq.c.latest),
                )
            )
            latest_metrics = {m.metric_type.value: m.value for m in result.scalars()}

            # Task stats for this product
            total_tasks = await session.scalar(
                select(func.count(Task.id)).where(
                    Task.product_id == product_id,
                    Task.created_at >= since,
                )
            )
            completed_tasks = await session.scalar(
                select(func.count(Task.id)).where(
                    Task.product_id == product_id,
                    Task.status == TaskStatus.COMPLETED,
                    Task.created_at >= since,
                )
            )
            failed_tasks = await session.scalar(
                select(func.count(Task.id)).where(
                    Task.product_id == product_id,
                    Task.status == TaskStatus.FAILED,
                    Task.created_at >= since,
                )
            )

            # Revenue trend
            revenue_series = await session.execute(
                select(Metric.value, Metric.created_at)
                .where(
                    Metric.product_id == product_id,
                    Metric.metric_type == MetricType.REVENUE,
                    Metric.created_at >= since,
                )
                .order_by(Metric.created_at.asc())
            )
            revenue_points = [
                {"value": row.value, "date": row.created_at.isoformat()}
                for row in revenue_series
            ]

        task_success_rate = (
            round((completed_tasks or 0) / max(total_tasks, 1), 4)
            if total_tasks
            else 0.0
        )

        return {
            "product_id": product_id,
            "period_days": days,
            "latest_metrics": latest_metrics,
            "task_stats": {
                "total": int(total_tasks or 0),
                "completed": int(completed_tasks or 0),
                "failed": int(failed_tasks or 0),
                "success_rate": task_success_rate,
            },
            "revenue_trend": revenue_points,
            "computed_at": datetime.now(timezone.utc).isoformat(),
        }

    # ── System-wide analytics ─────────────────────────────────────────
    async def get_system_analytics(self, days: int = 7) -> dict[str, Any]:
        """Return system-wide performance metrics."""
        since = datetime.now(timezone.utc) - timedelta(days=days)
        async with get_db_session() as session:
            total_products = await session.scalar(select(func.count(Product.id)))
            total_actions = await session.scalar(
                select(func.count(Action.id)).where(Action.created_at >= since)
            )
            successful_actions = await session.scalar(
                select(func.count(Action.id)).where(
                    Action.status == ActionStatus.SUCCESS,
                    Action.created_at >= since,
                )
            )
            total_revenue = await session.scalar(
                select(func.sum(Product.total_revenue))
            )
            total_mrr = await session.scalar(select(func.sum(Product.mrr)))
            total_customers = await session.scalar(
                select(func.sum(Product.paid_customers))
            )

            # Actions by agent
            agent_breakdown_result = await session.execute(
                select(Action.agent_type, func.count(Action.id))
                .where(Action.created_at >= since)
                .group_by(Action.agent_type)
            )
            agent_breakdown = {
                row[0]: row[1] for row in agent_breakdown_result
            }

        action_success_rate = (
            round((successful_actions or 0) / max(total_actions, 1), 4)
            if total_actions
            else 0.0
        )

        return {
            "period_days": days,
            "products": {
                "total": int(total_products or 0),
            },
            "revenue": {
                "total_usd": float(total_revenue or 0),
                "mrr_usd": float(total_mrr or 0),
                "arr_usd": float((total_mrr or 0) * 12),
            },
            "customers": {"total_paid": int(total_customers or 0)},
            "actions": {
                "total": int(total_actions or 0),
                "successful": int(successful_actions or 0),
                "success_rate": action_success_rate,
                "by_agent": agent_breakdown,
            },
            "computed_at": datetime.now(timezone.utc).isoformat(),
        }

    # ── Insight Generation ────────────────────────────────────────────
    async def generate_insights(
        self,
        analytics_data: dict[str, Any],
        context: str = "",
    ) -> list[str]:
        """
        Use GPT-4o to generate actionable insights from analytics data.
        Returns a list of insight strings.
        """
        prompt = (
            "Analyze this product analytics data and return 5 specific, actionable insights.\n\n"
            f"Data:\n{json.dumps(analytics_data, indent=2)}\n\n"
            f"Context: {context}\n\n"
            "Focus on: growth blockers, revenue opportunities, and what to do next.\n"
            'Output JSON: {"insights": ["insight 1", "insight 2", ...]}'
        )
        response = await self._llm.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.4,
            max_tokens=1000,
        )
        data = json.loads(response.choices[0].message.content)
        return data.get("insights", [])

    # ── Conversion funnel ─────────────────────────────────────────────
    async def compute_funnel(self, product_id: str) -> dict[str, Any]:
        """Compute visitor → signup → paid conversion funnel metrics."""
        async with get_db_session() as session:
            product = await session.get(Product, product_id)
            if not product:
                return {}

        visitors = max(product.visitors, 1)
        signups = product.signups
        paid = product.paid_customers

        return {
            "visitors": visitors,
            "signups": signups,
            "paid": paid,
            "visitor_to_signup_rate": round(signups / visitors, 4),
            "signup_to_paid_rate": round(paid / max(signups, 1), 4),
            "overall_conversion_rate": round(paid / visitors, 4),
            "estimated_cac_usd": (
                round(product.total_revenue / max(paid, 1) * 0.3, 2)
                if paid
                else None
            ),
        }

    # ── Metric recording shortcut ─────────────────────────────────────
    async def record_metric(
        self,
        metric_type: MetricType,
        value: float,
        product_id: Optional[str] = None,
        source: str = "analytics",
    ) -> None:
        """Write a metric to the database."""
        async with get_db_session() as session:
            m = Metric(
                metric_type=metric_type,
                value=value,
                product_id=product_id,
                source=source,
            )
            session.add(m)
        log.info(
            "analytics.metric_recorded",
            type=metric_type.value,
            value=value,
            product_id=product_id,
        )
