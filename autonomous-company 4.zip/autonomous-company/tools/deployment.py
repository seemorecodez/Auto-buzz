"""
DeploymentTool — deploys generated code to Vercel, Railway, or Fly.io.

Each provider is encapsulated behind a common interface:
    deploy(source_dir, project_name) → DeployResult
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import httpx

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)


@dataclass
class DeployResult:
    success: bool
    url: Optional[str]
    deploy_id: Optional[str]
    provider: str
    logs: str
    error: Optional[str] = None


class DeploymentTool:
    """
    Unified deployment abstraction.
    Provider is selected from settings.DEPLOY_PROVIDER.
    """

    def __init__(self) -> None:
        self.provider = settings.DEPLOY_PROVIDER.lower()

    async def deploy(
        self,
        source_dir: str,
        project_name: str,
    ) -> DeployResult:
        """Deploy source_dir to the configured cloud provider."""
        log.info(
            "deployment.starting",
            provider=self.provider,
            project=project_name,
        )
        try:
            if self.provider == "vercel":
                return await self._deploy_vercel(source_dir, project_name)
            elif self.provider == "railway":
                return await self._deploy_railway(source_dir, project_name)
            elif self.provider == "fly":
                return await self._deploy_fly(source_dir, project_name)
            else:
                return await self._deploy_local(source_dir, project_name)
        except Exception as exc:
            log.error("deployment.failed", error=str(exc), provider=self.provider)
            return DeployResult(
                success=False,
                url=None,
                deploy_id=None,
                provider=self.provider,
                logs="",
                error=str(exc),
            )

    # ── Vercel ────────────────────────────────────────────────────────
    async def _deploy_vercel(
        self, source_dir: str, project_name: str
    ) -> DeployResult:
        """Deploy a static or serverless project via the Vercel REST API."""
        token = settings.VERCEL_TOKEN
        if not token:
            raise ValueError("VERCEL_TOKEN not configured")

        from slugify import slugify  # type: ignore
        slug = slugify(project_name)[:32]

        # Build file payload
        source = Path(source_dir)
        files = []
        for fpath in source.rglob("*"):
            if fpath.is_file():
                rel = str(fpath.relative_to(source))
                content = fpath.read_text(encoding="utf-8", errors="replace")
                files.append({"file": rel, "data": content})

        payload = {
            "name": slug,
            "files": files,
            "projectSettings": {"framework": None},
        }

        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                "https://api.vercel.com/v13/deployments",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()

        deploy_id = data.get("id", "")
        url = f"https://{data.get('url', '')}"
        log.info("deployment.vercel_success", url=url, deploy_id=deploy_id)

        return DeployResult(
            success=True,
            url=url,
            deploy_id=deploy_id,
            provider="vercel",
            logs=json.dumps(data, indent=2),
        )

    # ── Railway ───────────────────────────────────────────────────────
    async def _deploy_railway(
        self, source_dir: str, project_name: str
    ) -> DeployResult:
        """Deploy via Railway GraphQL API."""
        token = settings.RAILWAY_TOKEN
        if not token:
            raise ValueError("RAILWAY_TOKEN not configured")

        from slugify import slugify  # type: ignore
        slug = slugify(project_name)[:32]

        # Create project mutation
        create_project_gql = """
        mutation CreateProject($name: String!) {
          projectCreate(input: { name: $name }) {
            id
            name
          }
        }
        """
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                "https://backboard.railway.app/graphql/v2",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json={"query": create_project_gql, "variables": {"name": slug}},
            )
            resp.raise_for_status()
            project_data = resp.json()

        project_id = project_data["data"]["projectCreate"]["id"]
        url = f"https://{slug}.up.railway.app"

        log.info(
            "deployment.railway_success",
            project_id=project_id,
            url=url,
        )
        return DeployResult(
            success=True,
            url=url,
            deploy_id=project_id,
            provider="railway",
            logs=json.dumps(project_data, indent=2),
        )

    # ── Fly.io ────────────────────────────────────────────────────────
    async def _deploy_fly(
        self, source_dir: str, project_name: str
    ) -> DeployResult:
        """Deploy using the flyctl CLI (must be installed in image)."""
        from slugify import slugify  # type: ignore
        slug = slugify(project_name)[:32]

        fly_toml = (
            f"app = '{slug}'\n"
            "kill_signal = 'SIGINT'\n"
            "kill_timeout = 5\n\n"
            "[build]\n"
            '  builder = "paketobuildpacks/builder:base"\n\n'
            "[[services]]\n"
            '  internal_port = 8080\n'
            '  protocol = "tcp"\n'
            "  [[services.ports]]\n"
            "    handlers = ['http']\n"
            "    port = 80\n"
            "  [[services.ports]]\n"
            "    handlers = ['tls', 'http']\n"
            "    port = 443\n"
        )
        fly_path = Path(source_dir) / "fly.toml"
        fly_path.write_text(fly_toml)

        token = settings.FLY_API_TOKEN or ""
        env = {"FLY_API_TOKEN": token}

        proc = await asyncio.create_subprocess_exec(
            "flyctl", "deploy", "--remote-only", "--app", slug,
            cwd=source_dir,
            env={**__import__("os").environ, **env},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
        logs = stdout.decode()

        if proc.returncode != 0:
            return DeployResult(
                success=False,
                url=None,
                deploy_id=None,
                provider="fly",
                logs=logs,
                error="flyctl exited non-zero",
            )

        url = f"https://{slug}.fly.dev"
        log.info("deployment.fly_success", url=url)
        return DeployResult(
            success=True,
            url=url,
            deploy_id=slug,
            provider="fly",
            logs=logs,
        )

    # ── Local fallback ────────────────────────────────────────────────
    async def _deploy_local(
        self, source_dir: str, project_name: str
    ) -> DeployResult:
        """
        Fallback: start the app locally on port 8080.
        Used for development / testing without cloud credentials.
        """
        from slugify import slugify  # type: ignore
        slug = slugify(project_name)[:32]

        proc = await asyncio.create_subprocess_exec(
            "bash", "-c",
            f"cd {source_dir} && pip install -r requirements.txt -q && "
            "uvicorn main:app --host 0.0.0.0 --port 8080 &",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        await asyncio.sleep(3)  # Let the server start

        url = "http://localhost:8080"
        log.info("deployment.local_started", url=url, project=project_name)

        return DeployResult(
            success=True,
            url=url,
            deploy_id="local",
            provider="local",
            logs=f"Local deployment of {slug} started at {url}",
        )
