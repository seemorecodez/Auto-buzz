"""
CryptoWalletTool — generates and manages Ethereum wallets for product payments.

Features:
  - HD wallet generation (BIP-44) with a single master mnemonic
  - One child address derived per product (deterministic, recoverable)
  - AES-256 private key encryption at rest
  - ETH + USDC (ERC-20) balance checking via Etherscan API
  - QR code generation for payment pages
  - USD price conversion via CoinGecko API

No Stripe required — each product gets its own on-chain wallet.

USDC contract (mainnet): 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48
USDC contract (sepolia):  0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import uuid
from pathlib import Path
from typing import Any, Optional

import httpx
from cryptography.fernet import Fernet
from eth_account import Account
from eth_account.hdaccount import generate_mnemonic

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)

# Enable HD wallet support in eth-account
Account.enable_unaudited_hdwallet_features()

# ERC-20 USDC contract addresses
USDC_CONTRACTS = {
    "mainnet": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    "sepolia": "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238",
}

# Etherscan API endpoints
ETHERSCAN_APIS = {
    "mainnet": "https://api.etherscan.io/api",
    "sepolia": "https://api-sepolia.etherscan.io/api",
}

# BIP-44 derivation path for Ethereum
ETH_DERIVATION_PATH = "m/44'/60'/0'/0/{index}"


class CryptoWalletTool:
    """
    Manages HD wallet generation, address derivation, and payment verification.
    """

    def __init__(self) -> None:
        self._network = settings.CRYPTO_NETWORK  # mainnet | sepolia
        self._etherscan_key = settings.ETHERSCAN_API_KEY or ""
        self._fernet = self._build_fernet()
        self._mnemonic = self._get_or_create_mnemonic()

    # ── Encryption ────────────────────────────────────────────────────
    def _build_fernet(self) -> Fernet:
        """Derive a stable Fernet key from the app SECRET_KEY."""
        secret_bytes = settings.SECRET_KEY.encode()
        key_bytes = hashlib.sha256(secret_bytes).digest()
        fernet_key = base64.urlsafe_b64encode(key_bytes)
        return Fernet(fernet_key)

    def encrypt(self, plaintext: str) -> str:
        return self._fernet.encrypt(plaintext.encode()).decode()

    def decrypt(self, ciphertext: str) -> str:
        return self._fernet.decrypt(ciphertext.encode()).decode()

    # ── Mnemonic management ───────────────────────────────────────────
    def _get_or_create_mnemonic(self) -> str:
        """
        Return the master mnemonic from config or generate + persist one.
        The mnemonic is written to .env on first generation.
        """
        if settings.CRYPTO_MASTER_MNEMONIC:
            return settings.CRYPTO_MASTER_MNEMONIC

        # Generate a new 12-word mnemonic
        mnemonic = generate_mnemonic(num_words=12, lang="english")

        # Persist to .env so it survives restarts
        env_path = Path(".env")
        if env_path.exists():
            content = env_path.read_text()
            if "CRYPTO_MASTER_MNEMONIC=" in content:
                content = content.replace(
                    "CRYPTO_MASTER_MNEMONIC=",
                    f"CRYPTO_MASTER_MNEMONIC={mnemonic}",
                )
                env_path.write_text(content)
        log.info(
            "crypto_wallet.mnemonic_generated",
            words=12,
            note="BACK UP your .env file — this mnemonic controls all product wallets",
        )
        return mnemonic

    # ── Wallet generation ─────────────────────────────────────────────
    def generate_wallet(self, derivation_index: int = 0) -> dict[str, str]:
        """
        Derive an Ethereum wallet at BIP-44 index N.
        Returns: {address, private_key, derivation_path}
        """
        path = ETH_DERIVATION_PATH.format(index=derivation_index)
        account = Account.from_mnemonic(
            self._mnemonic,
            account_path=path,
        )
        return {
            "address": account.address,
            "private_key": account.key.hex(),
            "derivation_path": path,
        }

    async def create_product_wallet(
        self,
        product_id: str,
        product_name: str,
        price_monthly_usd: float = 0.0,
    ) -> dict[str, Any]:
        """
        Create and persist a wallet for a product.
        Returns the wallet data including the public address.
        """
        from core.database import get_db_session
        from models.crypto_wallet import CryptoWallet, CryptoNetwork
        from sqlalchemy import select

        # Check if product already has a wallet
        async with get_db_session() as session:
            existing = await session.scalar(
                select(CryptoWallet).where(CryptoWallet.product_id == product_id)
            )
            if existing:
                return self._wallet_to_dict(existing)

            # Get next derivation index
            from sqlalchemy import func
            max_index = await session.scalar(
                select(func.max(CryptoWallet.derivation_index))
            )
            next_index = (max_index or 0) + 1

        # Generate wallet at the next index
        wallet_data = self.generate_wallet(derivation_index=next_index)

        # Convert USD price to ETH (approximate)
        eth_price = await self._get_eth_usd_price()
        price_eth = round(price_monthly_usd / eth_price, 6) if eth_price > 0 else 0.0
        price_usdc = price_monthly_usd  # USDC is 1:1 with USD

        # Generate QR code for the payment address
        qr_path = await self._generate_qr(wallet_data["address"], product_name)

        # Encrypt private key before storing
        encrypted_key = self.encrypt(wallet_data["private_key"])

        network_enum = (
            CryptoNetwork.ETH_MAINNET
            if self._network == "mainnet"
            else CryptoNetwork.ETH_SEPOLIA
        )

        async with get_db_session() as session:
            wallet = CryptoWallet(
                id=str(uuid.uuid4()),
                product_id=product_id,
                network=network_enum,
                address=wallet_data["address"],
                encrypted_private_key=encrypted_key,
                derivation_index=next_index,
                price_eth=price_eth,
                price_usdc=price_usdc,
                qr_code_path=qr_path,
            )
            session.add(wallet)
            await session.flush()
            wallet_id = wallet.id

        log.info(
            "crypto_wallet.created",
            product_id=product_id,
            address=wallet_data["address"],
            network=self._network,
        )

        return {
            "wallet_id": wallet_id,
            "address": wallet_data["address"],
            "network": self._network,
            "price_eth": price_eth,
            "price_usdc": price_usdc,
            "qr_code_path": qr_path,
            "etherscan_url": self._etherscan_address_url(wallet_data["address"]),
            "payment_deeplink": self._payment_deeplink(wallet_data["address"], price_eth),
        }

    # ── Balance checking ──────────────────────────────────────────────
    async def check_balance(self, address: str) -> dict[str, Any]:
        """
        Check ETH and USDC balance for an address via Etherscan.
        Updates the database record if balance has changed.
        """
        eth_balance = await self._get_eth_balance(address)
        usdc_balance = await self._get_usdc_balance(address)
        eth_usd = await self._get_eth_usd_price()

        total_usd = eth_balance * eth_usd + usdc_balance

        # Update DB record
        from core.database import get_db_session
        from models.crypto_wallet import CryptoWallet
        from sqlalchemy import select

        async with get_db_session() as session:
            wallet = await session.scalar(
                select(CryptoWallet).where(CryptoWallet.address == address)
            )
            if wallet:
                wallet.eth_balance = eth_balance
                wallet.usdc_balance = usdc_balance
                if total_usd > wallet.total_received_usd:
                    wallet.total_received_usd = total_usd
                    wallet.total_received_eth = eth_balance
                session.add(wallet)

        return {
            "address": address,
            "eth_balance": eth_balance,
            "usdc_balance": usdc_balance,
            "eth_usd_price": eth_usd,
            "total_usd_value": round(total_usd, 2),
        }

    async def _get_eth_balance(self, address: str) -> float:
        """Get ETH balance in ETH (not wei)."""
        api_url = ETHERSCAN_APIS.get(self._network, ETHERSCAN_APIS["mainnet"])
        params = {
            "module": "account",
            "action": "balance",
            "address": address,
            "tag": "latest",
        }
        if self._etherscan_key:
            params["apikey"] = self._etherscan_key

        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(api_url, params=params)
                data = resp.json()
                if data.get("status") == "1":
                    wei = int(data.get("result", 0))
                    return round(wei / 1e18, 8)
        except Exception as e:
            log.warning("crypto_wallet.eth_balance_failed", error=str(e))
        return 0.0

    async def _get_usdc_balance(self, address: str) -> float:
        """Get USDC balance (6 decimals)."""
        contract = USDC_CONTRACTS.get(self._network, USDC_CONTRACTS["mainnet"])
        api_url = ETHERSCAN_APIS.get(self._network, ETHERSCAN_APIS["mainnet"])
        params = {
            "module": "account",
            "action": "tokenbalance",
            "contractaddress": contract,
            "address": address,
            "tag": "latest",
        }
        if self._etherscan_key:
            params["apikey"] = self._etherscan_key

        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(api_url, params=params)
                data = resp.json()
                if data.get("status") == "1":
                    raw = int(data.get("result", 0))
                    return round(raw / 1e6, 4)  # USDC has 6 decimals
        except Exception as e:
            log.warning("crypto_wallet.usdc_balance_failed", error=str(e))
        return 0.0

    async def _get_eth_usd_price(self) -> float:
        """Get current ETH/USD price from CoinGecko (free, no key)."""
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={"ids": "ethereum", "vs_currencies": "usd"},
                )
                data = resp.json()
                return float(data.get("ethereum", {}).get("usd", 0))
        except Exception as e:
            log.warning("crypto_wallet.eth_price_failed", error=str(e))
            return 3000.0  # Fallback estimate

    # ── QR code ───────────────────────────────────────────────────────
    async def _generate_qr(self, address: str, product_name: str) -> str:
        """Generate a QR code PNG for the wallet address."""
        try:
            import qrcode
            from slugify import slugify  # type: ignore

            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=8,
                border=4,
            )
            qr.add_data(f"ethereum:{address}")
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")

            slug = slugify(product_name)
            qr_dir = Path(f"/tmp/acai_pages/{slug}")
            qr_dir.mkdir(parents=True, exist_ok=True)
            qr_path = qr_dir / "wallet_qr.png"
            img.save(str(qr_path))
            return str(qr_path)
        except Exception as e:
            log.warning("crypto_wallet.qr_failed", error=str(e))
            return ""

    # ── Helpers ───────────────────────────────────────────────────────
    def _etherscan_address_url(self, address: str) -> str:
        base = (
            "https://etherscan.io/address/"
            if self._network == "mainnet"
            else "https://sepolia.etherscan.io/address/"
        )
        return base + address

    def _payment_deeplink(self, address: str, amount_eth: float) -> str:
        """EIP-681 payment URI for MetaMask / mobile wallets."""
        if amount_eth > 0:
            wei = int(amount_eth * 1e18)
            return f"ethereum:{address}?value={wei}"
        return f"ethereum:{address}"

    def _wallet_to_dict(self, wallet) -> dict[str, Any]:
        return {
            "wallet_id": wallet.id,
            "address": wallet.address,
            "network": wallet.network.value,
            "price_eth": wallet.price_eth,
            "price_usdc": wallet.price_usdc,
            "qr_code_path": wallet.qr_code_path,
            "eth_balance": wallet.eth_balance,
            "usdc_balance": wallet.usdc_balance,
            "total_received_usd": wallet.total_received_usd,
            "etherscan_url": self._etherscan_address_url(wallet.address),
            "payment_deeplink": self._payment_deeplink(
                wallet.address, wallet.price_eth or 0.0
            ),
        }

    async def get_product_wallet(self, product_id: str) -> Optional[dict[str, Any]]:
        """Look up a product's wallet by product_id."""
        from core.database import get_db_session
        from models.crypto_wallet import CryptoWallet
        from sqlalchemy import select

        async with get_db_session() as session:
            wallet = await session.scalar(
                select(CryptoWallet).where(CryptoWallet.product_id == product_id)
            )
            if wallet:
                return self._wallet_to_dict(wallet)
        return None

    async def check_all_product_wallets(self) -> list[dict[str, Any]]:
        """Refresh balances for all product wallets."""
        from core.database import get_db_session
        from models.crypto_wallet import CryptoWallet
        from sqlalchemy import select

        async with get_db_session() as session:
            result = await session.execute(select(CryptoWallet))
            wallets = result.scalars().all()

        results = []
        for w in wallets:
            balance = await self.check_balance(w.address)
            results.append(balance)
        return results
