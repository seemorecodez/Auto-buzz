"""
LandingPageTool — generates high-converting landing pages.

Uses GPT-4o to produce copy and Jinja2 to render the HTML template.
Output is a standalone HTML file deployable to any static host.
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path
from typing import Any, Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from core.config import settings
from core.logger import get_logger
from core.llm import get_llm_client, get_primary_model

log = get_logger(__name__)

TEMPLATE_DIR = Path(__file__).parent / "templates"
TEMPLATE_DIR.mkdir(exist_ok=True)

# ── Embedded HTML template ─────────────────────────────────────────────────
_LANDING_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>{{ headline }} | {{ product_name }}</title>
  <meta name="description" content="{{ meta_description }}"/>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap');
    body { font-family: 'Inter', sans-serif; }
    .gradient-bg { background: linear-gradient(135deg, {{ primary_color }} 0%, {{ secondary_color }} 100%); }
  </style>
</head>
<body class="bg-gray-950 text-white">

  <!-- Hero -->
  <section class="gradient-bg min-h-screen flex items-center justify-center px-6 py-20">
    <div class="max-w-4xl mx-auto text-center">
      <span class="inline-block bg-white/10 text-white text-sm font-semibold px-4 py-1 rounded-full mb-6">
        {{ badge_text }}
      </span>
      <h1 class="text-5xl md:text-7xl font-black leading-tight mb-6">{{ headline }}</h1>
      <p class="text-xl md:text-2xl text-white/80 mb-10 max-w-2xl mx-auto">{{ subheadline }}</p>
      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="{{ cta_url }}"
           class="bg-white text-gray-900 font-bold text-lg px-8 py-4 rounded-xl hover:bg-gray-100 transition">
          {{ cta_primary }}
        </a>
        <a href="#features"
           class="border border-white/30 text-white font-semibold text-lg px-8 py-4 rounded-xl hover:bg-white/10 transition">
          {{ cta_secondary }}
        </a>
      </div>
      <p class="mt-4 text-white/50 text-sm">{{ social_proof }}</p>
    </div>
  </section>

  <!-- Problem / Solution -->
  <section class="bg-gray-900 py-20 px-6">
    <div class="max-w-3xl mx-auto text-center">
      <h2 class="text-3xl md:text-4xl font-bold mb-6">{{ problem_headline }}</h2>
      <p class="text-gray-400 text-lg mb-10">{{ problem_body }}</p>
      <div class="bg-gradient-to-r from-{{ accent }}-500/20 to-{{ accent }}-600/20 border border-{{ accent }}-500/30 rounded-2xl p-8">
        <h3 class="text-2xl font-bold mb-4 text-{{ accent }}-300">{{ solution_headline }}</h3>
        <p class="text-gray-300 text-lg">{{ solution_body }}</p>
      </div>
    </div>
  </section>

  <!-- Features -->
  <section id="features" class="py-20 px-6">
    <div class="max-w-6xl mx-auto">
      <h2 class="text-3xl md:text-4xl font-bold text-center mb-4">{{ features_headline }}</h2>
      <p class="text-gray-400 text-center mb-12 max-w-xl mx-auto">{{ features_subheadline }}</p>
      <div class="grid md:grid-cols-3 gap-8">
        {% for feature in features %}
        <div class="bg-gray-900 rounded-2xl p-6 border border-gray-800 hover:border-{{ accent }}-500/50 transition">
          <div class="text-4xl mb-4">{{ feature.icon }}</div>
          <h3 class="text-xl font-bold mb-2">{{ feature.title }}</h3>
          <p class="text-gray-400">{{ feature.description }}</p>
        </div>
        {% endfor %}
      </div>
    </div>
  </section>

  <!-- Pricing -->
  <section class="bg-gray-900 py-20 px-6">
    <div class="max-w-4xl mx-auto text-center">
      <h2 class="text-3xl md:text-4xl font-bold mb-4">{{ pricing_headline }}</h2>
      <p class="text-gray-400 mb-12">{{ pricing_subheadline }}</p>
      <div class="grid md:grid-cols-{{ pricing_tiers|length }} gap-8">
        {% for tier in pricing_tiers %}
        <div class="rounded-2xl p-8 border {% if tier.highlight %}border-{{ accent }}-500 bg-{{ accent }}-500/10{% else %}border-gray-800 bg-gray-950{% endif %}">
          {% if tier.highlight %}<div class="text-{{ accent }}-400 text-sm font-bold mb-4">MOST POPULAR</div>{% endif %}
          <h3 class="text-xl font-bold mb-2">{{ tier.name }}</h3>
          <div class="text-4xl font-black mb-1">${{ tier.price }}<span class="text-gray-500 text-lg font-normal">/mo</span></div>
          <p class="text-gray-500 text-sm mb-6">{{ tier.description }}</p>
          <ul class="text-left space-y-2 mb-8">
            {% for feature in tier.features %}
            <li class="flex items-center gap-2 text-gray-300"><span class="text-green-400">✓</span> {{ feature }}</li>
            {% endfor %}
          </ul>
          <a href="{{ cta_url }}" class="block text-center font-bold py-3 rounded-xl {% if tier.highlight %}bg-{{ accent }}-500 hover:bg-{{ accent }}-400{% else %}border border-gray-700 hover:bg-gray-800{% endif %} transition">
            {{ tier.cta }}
          </a>
        </div>
        {% endfor %}
      </div>
    </div>
  </section>

  <!-- Testimonials -->
  <section class="py-20 px-6">
    <div class="max-w-4xl mx-auto">
      <h2 class="text-3xl font-bold text-center mb-12">What early users say</h2>
      <div class="grid md:grid-cols-2 gap-8">
        {% for t in testimonials %}
        <div class="bg-gray-900 rounded-2xl p-6 border border-gray-800">
          <p class="text-gray-300 mb-4">"{{ t.quote }}"</p>
          <div class="font-semibold">{{ t.name }}</div>
          <div class="text-gray-500 text-sm">{{ t.role }}</div>
        </div>
        {% endfor %}
      </div>
    </div>
  </section>

  <!-- Crypto Payment -->
  {% if wallet_address %}
  <section class="bg-gray-950 py-20 px-6" id="pay">
    <div class="max-w-2xl mx-auto text-center">
      <h2 class="text-3xl md:text-4xl font-bold mb-4">Pay with Crypto</h2>
      <p class="text-gray-400 mb-10">Send ETH or USDC directly to our wallet — no middleman, instant settlement.</p>

      <!-- Live prices -->
      <div class="flex justify-center gap-6 mb-8">
        {% if price_eth %}
        <div class="bg-gray-900 border border-gray-800 rounded-xl px-6 py-4">
          <div class="text-xs text-gray-500 uppercase tracking-widest mb-1">ETH Price</div>
          <div class="text-2xl font-black text-white">${{ "%.2f"|format(price_eth) }}</div>
        </div>
        {% endif %}
        {% if price_usdc %}
        <div class="bg-gray-900 border border-gray-800 rounded-xl px-6 py-4">
          <div class="text-xs text-gray-500 uppercase tracking-widest mb-1">USDC</div>
          <div class="text-2xl font-black text-white">${{ "%.4f"|format(price_usdc) }}</div>
        </div>
        {% endif %}
      </div>

      <!-- Wallet address card -->
      <div class="bg-gray-900 border border-indigo-500/30 rounded-2xl p-6 mb-6">
        <div class="text-xs text-gray-500 uppercase tracking-widest mb-3">Ethereum Wallet Address</div>
        <div class="flex items-center gap-3 bg-gray-950 rounded-xl px-4 py-3 border border-gray-800">
          <code class="text-indigo-400 text-sm break-all flex-1">{{ wallet_address }}</code>
          <button
            onclick="navigator.clipboard.writeText('{{ wallet_address }}').then(()=>{this.textContent='\u2713';setTimeout(()=>{this.textContent='Copy'},1500)})"
            class="text-xs bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded-lg transition flex-shrink-0">
            Copy
          </button>
        </div>
        {% if qr_code_path %}
        <div class="mt-6">
          <img src="{{ qr_code_path }}" alt="Wallet QR Code"
               class="mx-auto w-40 h-40 rounded-xl border border-gray-700" />
          <p class="text-gray-500 text-xs mt-2">Scan with any Ethereum wallet app</p>
        </div>
        {% endif %}
      </div>

      <!-- Action buttons -->
      <div class="flex flex-col sm:flex-row gap-4 justify-center mb-6">
        {% if payment_deeplink %}
        <a href="{{ payment_deeplink }}"
           class="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-xl transition">
          Open in Wallet App
        </a>
        {% endif %}
        {% if etherscan_url %}
        <a href="{{ etherscan_url }}" target="_blank" rel="noopener"
           class="border border-gray-700 hover:bg-gray-800 text-gray-300 font-semibold px-6 py-3 rounded-xl transition">
          View on Etherscan &#8599;
        </a>
        {% endif %}
      </div>

      <p class="text-gray-600 text-xs">
        Payments are final on-chain. ETH and USDC (ERC-20) accepted.
        Network: {{ crypto_network|default("mainnet") }}.
      </p>
    </div>
  </section>
  {% endif %}

  <!-- Final CTA -->
  <section class="gradient-bg py-20 px-6 text-center">
    <h2 class="text-4xl md:text-5xl font-black mb-6">{{ final_cta_headline }}</h2>
    <p class="text-white/70 text-xl mb-10 max-w-xl mx-auto">{{ final_cta_body }}</p>
    <a href="{{ cta_url }}"
       class="inline-block bg-white text-gray-900 font-bold text-xl px-10 py-5 rounded-xl hover:bg-gray-100 transition">
      {{ cta_primary }} →
    </a>
  </section>

  <footer class="bg-gray-950 border-t border-gray-800 py-8 text-center text-gray-500 text-sm">
    © {{ year }} {{ product_name }}. All rights reserved.
    <br/>Built with Autonomous Company AI.
  </footer>

</body>
</html>
"""


class LandingPageTool:
    """Generates and optionally deploys landing pages."""

    COPY_SYSTEM_PROMPT = textwrap.dedent("""
        You are a world-class copywriter specializing in SaaS landing pages.
        Given a product spec, output a JSON object with ALL fields needed to
        render the landing page template. Be persuasive, benefit-focused, and specific.

        Required JSON schema:
        {
          "headline": "...",
          "subheadline": "...",
          "badge_text": "...",
          "meta_description": "...",
          "cta_primary": "...",
          "cta_secondary": "...",
          "cta_url": "#signup",
          "social_proof": "...",
          "problem_headline": "...",
          "problem_body": "...",
          "solution_headline": "...",
          "solution_body": "...",
          "features_headline": "...",
          "features_subheadline": "...",
          "features": [
            {"icon": "⚡", "title": "...", "description": "..."},
            ...  (6 features)
          ],
          "pricing_headline": "...",
          "pricing_subheadline": "...",
          "pricing_tiers": [
            {
              "name": "Starter",
              "price": "0",
              "description": "...",
              "features": ["...", "..."],
              "cta": "Get started free",
              "highlight": false
            },
            {
              "name": "Pro",
              "price": "29",
              "description": "...",
              "features": ["...", "...", "...", "...", "..."],
              "cta": "Start free trial",
              "highlight": true
            },
            {
              "name": "Scale",
              "price": "99",
              "description": "...",
              "features": ["...", "...", "...", "...", "..."],
              "cta": "Contact sales",
              "highlight": false
            }
          ],
          "testimonials": [
            {"quote": "...", "name": "...", "role": "..."},
            {"quote": "...", "name": "...", "role": "..."}
          ],
          "final_cta_headline": "...",
          "final_cta_body": "...",
          "primary_color": "#6366f1",
          "secondary_color": "#8b5cf6",
          "accent": "indigo"
        }
    """).strip()

    def __init__(self) -> None:
        self._client = get_llm_client()
        self._model = get_primary_model()
    async def generate(
        self,
        product_name: str,
        product_description: str,
        niche: str,
        target_audience: str,
        value_proposition: str,
        price_monthly: Optional[float] = None,
        # Crypto payment widget (all optional — widget hidden when wallet_address is None)
        wallet_address: Optional[str] = None,
        price_eth: Optional[float] = None,
        price_usdc: Optional[float] = None,
        payment_deeplink: Optional[str] = None,
        etherscan_url: Optional[str] = None,
        qr_code_path: Optional[str] = None,
        crypto_network: str = "mainnet",
    ) -> dict[str, Any]:
        """
        Generate a complete landing page for the product.
        Returns: {html: str, copy: dict, output_path: str}
        """
        spec = json.dumps(
            {
                "product_name": product_name,
                "description": product_description,
                "niche": niche,
                "target_audience": target_audience,
                "value_proposition": value_proposition,
                "price_monthly": price_monthly,
            },
            indent=2,
        )

        log.info("landing_page.generating_copy", product=product_name)
        # Build kwargs — only Gemini/OpenAI support response_format JSON mode
        _is_mistral = "mistral" in self._model.lower() or "ministral" in self._model.lower() or "nemo" in self._model.lower()
        _extra: dict = {} if _is_mistral else {"response_format": {"type": "json_object"}}
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": self.COPY_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": f"Generate landing page copy for:\n\n{spec}",
                },
            ],
            temperature=0.7,
            max_tokens=6000,
            **_extra,
        )

        raw_copy = response.choices[0].message.content.strip()
        # Strip fences if any
        if raw_copy.startswith("```"):
            raw_copy = "\n".join(l for l in raw_copy.split("\n") if not l.strip().startswith("```")).strip()
        # Find JSON object boundaries
        _s = raw_copy.find("{")
        _e = raw_copy.rfind("}")
        if _s != -1 and _e != -1:
            raw_copy = raw_copy[_s:_e + 1]
        try:
            copy: dict[str, Any] = json.loads(raw_copy)
        except json.JSONDecodeError:
            log.warning("landing_page.json_parse_failed", product=product_name)
            copy = {
                "headline": f"The Smartest {product_name} for Modern Teams",
                "subheadline": value_proposition,
                "meta_description": f"{product_name} — {value_proposition[:120]}",
                "badge_text": "Now Available",
                "hero_cta": "Start Free Trial",
                "hero_cta_secondary": "See How It Works",
                "primary_color": "#6366f1",
                "secondary_color": "#8b5cf6",
                "features": [{"icon": "⚡", "title": "Fast", "description": "Built for speed"}, {"icon": "🔒", "title": "Secure", "description": "Enterprise-grade security"}, {"icon": "📊", "title": "Analytics", "description": "Real-time insights"}],
                "testimonials": [{"quote": "Changed how we work.", "name": "Sarah K.", "role": "CEO", "company": "TechCorp", "avatar_letter": "S"}],
                "pricing_headline": "Simple, Transparent Pricing",
                "price_monthly": price_monthly or 29,
                "price_annual": round((price_monthly or 29) * 10, 0),
                "pricing_cta": "Get Started Free",
                "faq": [{"question": "Is there a free trial?", "answer": "Yes, 14 days free, no credit card required."}],
                "footer_tagline": f"Built for modern teams.",
            }
        copy["product_name"] = product_name
        copy["year"] = __import__("datetime").datetime.now().year

        # Inject crypto fields (falsy values render the widget invisible via {% if %})
        copy["wallet_address"] = wallet_address
        copy["price_eth"] = price_eth
        copy["price_usdc"] = price_usdc
        copy["payment_deeplink"] = payment_deeplink
        copy["etherscan_url"] = etherscan_url
        copy["qr_code_path"] = qr_code_path
        copy["crypto_network"] = crypto_network

        # Render HTML
        from jinja2 import BaseLoader, Environment

        env = Environment(loader=BaseLoader())
        template = env.from_string(_LANDING_TEMPLATE)
        html = template.render(**copy)

        # Write to disk
        from slugify import slugify  # type: ignore

        slug = slugify(product_name)
        output_dir = Path(f"/tmp/acai_pages/{slug}")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "index.html"
        output_path.write_text(html, encoding="utf-8")

        log.info(
            "landing_page.generated",
            product=product_name,
            path=str(output_path),
        )
        return {
            "html": html,
            "copy": copy,
            "output_path": str(output_path),
            "output_dir": str(output_dir),
        }
