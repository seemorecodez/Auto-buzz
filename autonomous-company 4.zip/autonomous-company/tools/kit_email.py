"""
KitEmailTool — full integration with Kit (ConvertKit) v3 API.

Replaces SMTP for all email outreach.

Capabilities:
  - Create / tag subscribers
  - Send broadcast emails to a tag or all subscribers
  - Create email sequences and add subscribers to them
  - Fetch subscriber counts and open rates
  - List existing forms and tags

API reference: https://developers.convertkit.com/
"""

from __future__ import annotations

import json
import textwrap
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

from core.config import settings
from core.logger import get_logger
from core.llm import get_llm_client, get_primary_model

log = get_logger(__name__)


@dataclass
class KitSubscriber:
    email: str
    first_name: str = ""
    last_name: str = ""
    tags: list[str] = field(default_factory=list)
    fields: dict[str, str] = field(default_factory=dict)


@dataclass
class KitBroadcast:
    subject: str
    content_html: str
    content_text: str
    description: str = ""   # Internal label visible only in Kit dashboard


class KitEmailTool:
    """
    Full Kit API client for subscriber management and email broadcasting.
    All outreach runs through Kit — no SMTP required.
    """

    def __init__(self) -> None:
        self._api_key = settings.KIT_API_KEY
        self._api_secret = settings.KIT_API_SECRET
        self._base = settings.KIT_API_BASE.rstrip("/")
        self._llm = get_llm_client()
        self._model = get_primary_model()
        if not self._api_key:
            log.warning("kit_email.no_api_key")

    # ── Auth helpers ──────────────────────────────────────────────────
    def _auth_params(self) -> dict[str, str]:
        """Query params for public endpoints (API key only)."""
        return {"api_key": self._api_key}

    def _secret_params(self) -> dict[str, str]:
        """Query params for protected endpoints (API key + secret)."""
        return {"api_key": self._api_key, "api_secret": self._api_secret}

    # ── Subscriber Management ─────────────────────────────────────────
    async def _get_or_create_tag(self, tag_name: str) -> Optional[int]:
        """Return the Kit tag_id for tag_name, creating it if it doesn't exist."""
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{self._base}/tags",
                params={"api_key": self._api_key},
            )
            if resp.status_code == 200:
                for t in resp.json().get("tags", []):
                    if t.get("name", "").lower() == tag_name.lower():
                        return t["id"]
            # Tag not found — create it
            resp2 = await client.post(
                f"{self._base}/tags",
                json={"api_key": self._api_key, "tag": {"name": tag_name}},
            )
            if resp2.status_code in (200, 201):
                tags = resp2.json().get("tags", [])
                if tags:
                    return tags[0]["id"]
        return None

    async def add_subscriber(
        self,
        subscriber: KitSubscriber,
        form_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Add or update a subscriber in Kit.
        Uses form-based subscription (form_id) or tag-based subscription.
        ConvertKit v3 does NOT have a generic POST /subscribers endpoint;
        subscribers must be added via a form or tag.
        """
        if not self._api_key:
            return {"success": False, "error": "KIT_API_KEY not configured"}

        payload: dict[str, Any] = {
            "api_key": self._api_key,
            "email": subscriber.email,
            "first_name": subscriber.first_name,
        }
        if subscriber.fields:
            payload["fields"] = subscriber.fields

        async with httpx.AsyncClient(timeout=30) as client:
            if form_id:
                url = f"{self._base}/forms/{form_id}/subscribe"
            else:
                # Use tag-based subscription (correct ConvertKit v3 approach)
                tag_name = (subscriber.tags[0] if subscriber.tags else None) or "acai-lead"
                tag_id = await self._get_or_create_tag(tag_name)
                if tag_id:
                    url = f"{self._base}/tags/{tag_id}/subscribe"
                else:
                    log.warning("kit_email.no_tag_id", email=subscriber.email)
                    return {"success": False, "error": "Could not create tag"}

            resp = await client.post(url, json=payload)

            if resp.status_code not in (200, 201):
                log.warning(
                    "kit_email.subscribe_failed",
                    email=subscriber.email,
                    status=resp.status_code,
                    body=resp.text[:200],
                )
                return {"success": False, "error": resp.text[:200]}

            data = resp.json()
            subscriber_id = (
                data.get("subscriber", {}).get("id")
                or data.get("id")
            )

        log.info("kit_email.subscriber_added", email=subscriber.email)
        return {"success": True, "subscriber_id": subscriber_id, "email": subscriber.email}

    async def add_subscribers_bulk(
        self,
        subscribers: list[KitSubscriber],
        form_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Add multiple subscribers, returning aggregate stats."""
        added = 0
        failed = 0
        errors: list[str] = []

        for sub in subscribers:
            result = await self.add_subscriber(sub, form_id=form_id)
            if result.get("success"):
                added += 1
            else:
                failed += 1
                errors.append(f"{sub.email}: {result.get('error', 'unknown')}")

        return {"added": added, "failed": failed, "errors": errors}

    async def tag_subscriber(
        self, subscriber_id: int, tags: list[str]
    ) -> None:
        """Apply one or more tags to an existing subscriber."""
        if not self._api_key:
            return

        for tag_name in tags:
            tag_id = await self._get_or_create_tag(tag_name)
            if tag_id:
                async with httpx.AsyncClient(timeout=20) as client:
                    await client.post(
                        f"{self._base}/tags/{tag_id}/subscribe",
                        json={
                            "api_key": self._api_key,
                            "email": str(subscriber_id),
                        },
                    )

    # ── Broadcast Emails ──────────────────────────────────────────────
    async def send_broadcast(
        self,
        broadcast: KitBroadcast,
        tag_id: Optional[int] = None,
        send_at: Optional[str] = None,   # ISO-8601 datetime or None for immediate
    ) -> dict[str, Any]:
        """
        Create and send (or schedule) a broadcast email.

        tag_id:   send only to subscribers with this tag; None = all subscribers
        send_at:  schedule for later, e.g. "2026-04-10T09:00:00Z"; None = send now
        """
        if not self._api_secret:
            return {"success": False, "error": "KIT_API_SECRET not configured"}

        payload: dict[str, Any] = {
            "api_secret": self._api_secret,
            "subject": broadcast.subject,
            "content": broadcast.content_html,
            "description": broadcast.description or broadcast.subject,
            "public": False,
        }
        if tag_id:
            payload["subscriber_filter"] = [{"all": [{"type": "tag", "tag_id": tag_id}]}]
        if send_at:
            payload["send_at"] = send_at

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{self._base}/broadcasts",
                json=payload,
            )

        if resp.status_code not in (200, 201):
            log.error(
                "kit_email.broadcast_failed",
                status=resp.status_code,
                body=resp.text[:300],
            )
            return {"success": False, "error": resp.text[:300]}

        data = resp.json()
        broadcast_id = data.get("broadcast", {}).get("id") or data.get("id")
        log.info("kit_email.broadcast_created", broadcast_id=broadcast_id)
        return {"success": True, "broadcast_id": broadcast_id}

    # ── Single-subscriber targeted email ─────────────────────────────
    async def send_email_to_subscriber(
        self,
        subscriber_email: str,
        subject: str,
        html_body: str,
    ) -> dict[str, Any]:
        """
        Send an email to a single specific subscriber.

        Strategy:
          1. Create a one-time ephemeral tag for this subscriber.
          2. Tag the subscriber with it.
          3. Send a broadcast filtered to that tag.
          4. The tag is left in place (Kit has no delete-tag API in v3);
             the subscriber will not receive it again as no future broadcasts
             target this ephemeral tag.

        Returns: {"success": bool, "broadcast_id": Optional[int]}
        """
        if not self._api_key or not self._api_secret:
            return {"success": False, "error": "KIT credentials not configured"}

        import time as _time
        ts = int(_time.time())
        ephemeral_tag = f"_drip-send-{ts}-{subscriber_email.replace('@', '-').replace('.', '-')[:30]}"

        # Step 1: Get or create the ephemeral tag
        tag_id = await self._get_or_create_tag(ephemeral_tag)
        if not tag_id:
            return {"success": False, "error": "Could not create ephemeral tag"}

        # Step 2: Subscribe / tag the target subscriber
        async with httpx.AsyncClient(timeout=30) as client:
            sub_resp = await client.post(
                f"{self._base}/tags/{tag_id}/subscribe",
                json={
                    "api_key": self._api_key,
                    "email": subscriber_email,
                },
            )
            if sub_resp.status_code not in (200, 201):
                log.warning(
                    "kit_email.tag_subscriber_failed",
                    email=subscriber_email,
                    status=sub_resp.status_code,
                    body=sub_resp.text[:200],
                )
                return {"success": False, "error": sub_resp.text[:200]}

        # Step 3: Send broadcast to this ephemeral tag
        broadcast = KitBroadcast(
            subject=subject,
            content_html=html_body,
            content_text="",  # Kit will auto-generate text from HTML
            description=f"Targeted send to {subscriber_email}",
        )
        result = await self.send_broadcast(broadcast, tag_id=tag_id)

        log.info(
            "kit_email.single_subscriber_sent",
            email=subscriber_email,
            subject=subject,
            broadcast_id=result.get("broadcast_id"),
        )
        return result

    # ── List / Analytics ──────────────────────────────────────────────
    async def get_subscriber_count(self) -> int:
        """Return total active subscriber count."""
        if not self._api_secret:
            return 0
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{self._base}/subscribers",
                params=self._secret_params(),
            )
        if resp.status_code == 200:
            return resp.json().get("total_subscribers", 0)
        return 0

    async def list_forms(self) -> list[dict[str, Any]]:
        """Return all forms from the Kit account."""
        if not self._api_key:
            return []
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{self._base}/forms",
                params=self._auth_params(),
            )
        if resp.status_code == 200:
            return resp.json().get("forms", [])
        return []

    async def list_tags(self) -> list[dict[str, Any]]:
        """Return all tags from the Kit account."""
        if not self._api_key:
            return []
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{self._base}/tags",
                params=self._auth_params(),
            )
        if resp.status_code == 200:
            return resp.json().get("tags", [])
        return []

    # ── AI-Powered Email Generation ───────────────────────────────────
    async def generate_broadcast(
        self,
        product_name: str,
        product_description: str,
        value_proposition: str,
        target_audience: str,
        cta_url: str,
        email_type: str = "launch",  # launch | update | nurture | offer
    ) -> KitBroadcast:
        """
        Use GPT-4o to generate a complete broadcast email for Kit.
        """
        prompt = textwrap.dedent(f"""
            Write a high-converting {email_type} email for Kit (ConvertKit).

            Product: {product_name}
            Description: {product_description}
            Value proposition: {value_proposition}
            Target audience: {target_audience}
            CTA URL: {cta_url}
            Email type: {email_type}

            Rules:
            - Subject: 5-9 words, curiosity/benefit-driven, no spam triggers
            - Body HTML: 3 short paragraphs, conversational, benefit-focused
            - Personal tone, no "I hope this email finds you well"
            - End with one clear CTA button
            - Include {{ subscriber.first_name | default: 'there' }} personalisation
            - Plain HTML (no external CSS frameworks)
            - Include a plain text fallback

            Return JSON:
            {{
              "subject": "...",
              "content_html": "...",
              "content_text": "...",
              "description": "Internal: {email_type} email for {product_name}"
            }}
        """).strip()

        response = await self._llm.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.7,
            max_tokens=2000,
        )
        data = json.loads(response.choices[0].message.content)

        return KitBroadcast(
            subject=data["subject"],
            content_html=data["content_html"],
            content_text=data["content_text"],
            description=data.get("description", ""),
        )

    # ── Full campaign flow ────────────────────────────────────────────
    async def run_launch_campaign(
        self,
        product_name: str,
        product_description: str,
        value_proposition: str,
        target_audience: str,
        cta_url: str,
        leads: list[dict[str, Any]],   # [{email, first_name, last_name, company, title}]
        product_tag: str = "",
    ) -> dict[str, Any]:
        """
        Full Kit campaign:
        1. Add all leads as subscribers with a product tag
        2. Generate AI email copy
        3. Send broadcast to that tag

        Returns campaign stats.
        """
        # Step 1: Add subscribers
        tag_name = product_tag or f"acai-{product_name.lower().replace(' ', '-')}"
        kit_subscribers = [
            KitSubscriber(
                email=lead["email"],
                first_name=lead.get("first_name", ""),
                last_name=lead.get("last_name", ""),
                tags=[tag_name],
                fields={"company": lead.get("company", ""), "title": lead.get("title", "")},
            )
            for lead in leads
            if lead.get("email")
        ]

        add_result = await self.add_subscribers_bulk(kit_subscribers)
        log.info("kit_email.subscribers_added", **{k: v for k, v in add_result.items() if k != "errors"})

        # Step 2: Generate copy
        broadcast = await self.generate_broadcast(
            product_name=product_name,
            product_description=product_description,
            value_proposition=value_proposition,
            target_audience=target_audience,
            cta_url=cta_url,
            email_type="launch",
        )

        # Step 3: Get tag ID and send broadcast
        tags = await self.list_tags()
        tag_obj = next((t for t in tags if t.get("name") == tag_name), None)
        tag_id = tag_obj["id"] if tag_obj else None

        send_result = await self.send_broadcast(broadcast, tag_id=tag_id)

        return {
            "subscribers_added": add_result["added"],
            "subscribers_failed": add_result["failed"],
            "broadcast_subject": broadcast.subject,
            "broadcast_sent": send_result.get("success", False),
            "broadcast_id": send_result.get("broadcast_id"),
            "tag": tag_name,
        }
