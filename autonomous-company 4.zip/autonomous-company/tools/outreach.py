"""
OutreachTool — lead generation and email outreach automation.

Lead sources:
  1. Hunter.io API  — domain → email addresses
  2. Apollo.io API  — company/role-based lead search
  3. Heuristic fallback — generate plausible leads from niche keywords

Email sending: aiosmtplib (async SMTP) with Jinja2 templates.
All sent emails are recorded in the database.
"""

from __future__ import annotations

import asyncio
import json
import textwrap
from dataclasses import dataclass, field
from typing import Any, Optional

import aiosmtplib
import httpx
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from core.config import settings
from core.logger import get_logger
from core.llm import get_llm_client, get_primary_model

log = get_logger(__name__)


@dataclass
class Lead:
    email: str
    first_name: str
    last_name: str
    company: str
    title: str
    website: str = ""
    linkedin_url: str = ""
    source: str = "unknown"


@dataclass
class EmailCampaign:
    subject: str
    html_body: str
    text_body: str
    from_name: str = field(default_factory=lambda: settings.FROM_NAME)
    from_email: str = field(default_factory=lambda: settings.FROM_EMAIL)


class OutreachTool:
    """Handles lead discovery and personalised email outreach."""

    def __init__(self) -> None:
        self._llm = get_llm_client()
        self._model = get_primary_model()
    # ── Lead Generation ───────────────────────────────────────────────
    async def find_leads(
        self,
        niche: str,
        target_role: str = "founder",
        target_company_size: str = "1-50",
        limit: int = 20,
    ) -> list[Lead]:
        """
        Find leads for a given niche via Apollo, Hunter, or AI fallback.
        Returns a deduplicated list of Lead objects.
        """
        leads: list[Lead] = []

        if settings.APOLLO_API_KEY:
            leads = await self._leads_from_apollo(niche, target_role, limit)
        elif settings.HUNTER_API_KEY:
            leads = await self._leads_from_hunter(niche, limit)
        else:
            leads = await self._leads_from_ai(niche, target_role, limit)

        # Deduplicate by email
        seen: set[str] = set()
        unique: list[Lead] = []
        for lead in leads:
            if lead.email not in seen:
                seen.add(lead.email)
                unique.append(lead)

        log.info("outreach.leads_found", niche=niche, count=len(unique))
        return unique[:limit]

    async def _leads_from_apollo(
        self, niche: str, role: str, limit: int
    ) -> list[Lead]:
        """Query Apollo.io People Search API."""
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://api.apollo.io/v1/mixed_people/search",
                headers={
                    "Content-Type": "application/json",
                    "Cache-Control": "no-cache",
                    "X-Api-Key": settings.APOLLO_API_KEY,
                },
                json={
                    "q_keywords": niche,
                    "person_titles": [role],
                    "per_page": min(limit, 25),
                },
            )
            resp.raise_for_status()
            data = resp.json()

        leads: list[Lead] = []
        for person in data.get("people", []):
            email = person.get("email") or ""
            if not email or "@" not in email:
                continue
            leads.append(
                Lead(
                    email=email,
                    first_name=person.get("first_name", ""),
                    last_name=person.get("last_name", ""),
                    company=person.get("organization", {}).get("name", ""),
                    title=person.get("title", ""),
                    linkedin_url=person.get("linkedin_url", ""),
                    source="apollo",
                )
            )
        return leads

    async def _leads_from_hunter(
        self, niche: str, limit: int
    ) -> list[Lead]:
        """Use Hunter.io domain search to find leads."""
        # Hunter requires a domain; map niche to likely SaaS domains
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                "https://api.hunter.io/v2/domain-search",
                params={
                    "domain": f"{niche.lower().replace(' ', '')}.com",
                    "api_key": settings.HUNTER_API_KEY,
                    "limit": min(limit, 10),
                },
            )
            resp.raise_for_status()
            data = resp.json()

        leads: list[Lead] = []
        for item in data.get("data", {}).get("emails", []):
            email = item.get("value", "")
            if not email:
                continue
            leads.append(
                Lead(
                    email=email,
                    first_name=item.get("first_name", ""),
                    last_name=item.get("last_name", ""),
                    company=data["data"].get("organization", ""),
                    title=item.get("position", ""),
                    website=data["data"].get("domain", ""),
                    source="hunter",
                )
            )
        return leads

    async def _leads_from_ai(
        self, niche: str, role: str, limit: int
    ) -> list[Lead]:
        """
        Fallback: use GPT-4o to generate a plausible list of leads.
        NOTE: These are synthetic and should only be used for testing.
        In production, replace with real API credentials.
        """
        prompt = (
            f"Generate {limit} realistic B2B leads for a product in the '{niche}' niche "
            f"targeting {role}s.\n\n"
            "Output a JSON array of objects with keys: "
            "email, first_name, last_name, company, title, website\n"
            "Use realistic company names and professional email formats.\n"
            "Return ONLY the JSON array."
        )
        response = await self._llm.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.8,
            max_tokens=2000,
        )
        # GPT wraps the array in an object for JSON mode
        raw = json.loads(response.choices[0].message.content)
        # LLM may return a bare list or a dict wrapping the list
        if isinstance(raw, list):
            items = raw
        else:
            items = raw.get("leads", raw.get("people", list(raw.values())[0] if raw else []))

        leads: list[Lead] = []
        for item in items[:limit]:
            if isinstance(item, dict) and item.get("email"):
                leads.append(
                    Lead(
                        email=item["email"],
                        first_name=item.get("first_name", ""),
                        last_name=item.get("last_name", ""),
                        company=item.get("company", ""),
                        title=item.get("title", ""),
                        website=item.get("website", ""),
                        source="ai_generated",
                    )
                )
        return leads

    # ── Email Copy Generation ─────────────────────────────────────────
    async def generate_email_campaign(
        self,
        product_name: str,
        product_description: str,
        value_proposition: str,
        target_audience: str,
        cta_url: str,
    ) -> EmailCampaign:
        """Use GPT-4o to write a personalised cold email sequence."""
        prompt = textwrap.dedent(f"""
            Write a cold outreach email for this product:
            - Product: {product_name}
            - Description: {product_description}
            - Value Proposition: {value_proposition}
            - Target Audience: {target_audience}
            - CTA URL: {cta_url}

            Rules:
            - Subject line: under 50 chars, curiosity-driven
            - Body: 3-4 short paragraphs, benefit-focused
            - End with a single clear CTA
            - Tone: professional but conversational
            - NO spammy phrases like "I hope this finds you well"

            Output JSON: {{"subject": "...", "html_body": "...", "text_body": "..."}}
        """).strip()

        response = await self._llm.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.7,
            max_tokens=1500,
        )
        data = json.loads(response.choices[0].message.content)

        return EmailCampaign(
            subject=data["subject"],
            html_body=data["html_body"],
            text_body=data["text_body"],
        )

    # ── Email Sending ─────────────────────────────────────────────────
    async def send_email(
        self,
        lead: Lead,
        campaign: EmailCampaign,
        personalise: bool = True,
    ) -> dict[str, Any]:
        """
        Send a single email to a lead via SMTP.
        Returns a result dict with success/error info.
        """
        if not settings.SMTP_HOST:
            log.warning("outreach.smtp_not_configured")
            return {
                "success": False,
                "error": "SMTP not configured",
                "email": lead.email,
            }

        # Personalise the HTML body
        html = campaign.html_body
        text = campaign.text_body
        if personalise and lead.first_name:
            html = html.replace("{{first_name}}", lead.first_name).replace(
                "Hi,", f"Hi {lead.first_name},"
            )
            text = text.replace("{{first_name}}", lead.first_name)

        msg = MIMEMultipart("alternative")
        msg["Subject"] = campaign.subject
        msg["From"] = f"{campaign.from_name} <{campaign.from_email}>"
        msg["To"] = lead.email
        msg.attach(MIMEText(text, "plain"))
        msg.attach(MIMEText(html, "html"))

        try:
            await aiosmtplib.send(
                msg,
                hostname=settings.SMTP_HOST,
                port=settings.SMTP_PORT,
                username=settings.SMTP_USER,
                password=settings.SMTP_PASSWORD,
                use_tls=False,
                start_tls=True,
                timeout=30,
            )
            log.info("outreach.email_sent", to=lead.email)
            return {"success": True, "email": lead.email}
        except Exception as exc:
            log.error("outreach.email_failed", to=lead.email, error=str(exc))
            return {"success": False, "email": lead.email, "error": str(exc)}

    async def run_campaign(
        self,
        leads: list[Lead],
        campaign: EmailCampaign,
        delay_seconds: float = 2.0,
    ) -> dict[str, Any]:
        """
        Send emails to all leads with a rate-limit delay between sends.
        Returns campaign stats.
        """
        sent = 0
        failed = 0
        errors: list[str] = []

        for lead in leads:
            result = await self.send_email(lead, campaign)
            if result["success"]:
                sent += 1
            else:
                failed += 1
                if result.get("error"):
                    errors.append(f"{lead.email}: {result['error']}")
            await asyncio.sleep(delay_seconds)

        stats = {
            "total": len(leads),
            "sent": sent,
            "failed": failed,
            "errors": errors,
        }
        log.info("outreach.campaign_complete", **{k: v for k, v in stats.items() if k != "errors"})
        return stats
