"""
SEOTool — generates SEO content assets for traffic generation.

Responsibilities:
  1. Blog posts with full HTML + embedded CSS
  2. Programmatic landing page variants by segment
  3. Sitemap.xml generation
  4. JSON-LD structured data
  5. Competitor comparison pages
  6. Product Hunt submission kits
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from core.config import settings
from core.logger import get_logger
from core.llm import get_llm_client, get_primary_model

log = get_logger(__name__)


def _slugify(text: str) -> str:
    """Simple slug generator (mirrors python-slugify behaviour for ASCII text)."""
    import re
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text.strip("-")


class SEOTool:
    """Generates SEO content assets: blog posts, programmatic pages, sitemaps, etc."""

    def __init__(self) -> None:
        self._client = get_llm_client()
        self._model = get_primary_model()
    # ── Internal LLM helpers ───────────────────────────────────────────

    async def _chat_json(
        self,
        system: str,
        user: str,
        temperature: float = 0.7,
        max_tokens: int = 4000,
    ) -> dict[str, Any]:
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            response_format={"type": "json_object"},
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return json.loads(response.choices[0].message.content)

    async def _chat(
        self,
        system: str,
        user: str,
        temperature: float = 0.7,
        max_tokens: int = 4000,
    ) -> str:
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""

    # ── Blog Post ─────────────────────────────────────────────────────

    async def generate_blog_post(
        self,
        product_name: str,
        niche: str,
        target_audience: str,
        keyword_hint: str = "",
    ) -> dict[str, Any]:
        """
        Generate a full HTML blog post optimised for organic search.

        Returns: {title, slug, html_path, word_count}
        """
        product_slug = _slugify(product_name)

        log.info("seo.generating_blog_post", product=product_name, keyword=keyword_hint)

        meta = await self._chat_json(
            system=(
                "You are an expert SEO content strategist. "
                "Given a product, niche, and target audience, produce blog post metadata. "
                'Return JSON: {"title": "...", "slug": "...", "meta_description": "...", '
                '"keywords": ["kw1", "kw2", ...], "intro": "...", '
                '"sections": [{"heading": "H2 title", "subheadings": ["H3 a", "H3 b"], '
                '"content": "paragraph text"}, ...], "cta_text": "..."}'
            ),
            user=(
                f"Product: {product_name}\n"
                f"Niche: {niche}\n"
                f"Target audience: {target_audience}\n"
                f"Keyword hint: {keyword_hint or 'any relevant'}\n\n"
                "Write an SEO-optimised blog post outline (1 200+ words total across sections). "
                "Make sections rich and informative. Include at least 4 H2 sections."
            ),
            temperature=0.7,
            max_tokens=4000,
        )

        title = meta.get("title", f"Why {product_name} Is Right for {target_audience}")
        post_slug = meta.get("slug") or _slugify(title)
        meta_description = meta.get("meta_description", "")
        keywords = meta.get("keywords", [])
        intro = meta.get("intro", "")
        sections = meta.get("sections", [])
        cta_text = meta.get("cta_text", f"Try {product_name} free today.")

        # Build full HTML
        keywords_csv = ", ".join(keywords)
        sections_html_parts = []
        for section in sections:
            heading = section.get("heading", "")
            subheadings = section.get("subheadings", [])
            content = section.get("content", "")
            sub_html = "".join(f"<h3>{sh}</h3>" for sh in subheadings)
            sections_html_parts.append(
                f"<h2>{heading}</h2>{sub_html}<p>{content}</p>"
            )
        sections_html = "\n".join(sections_html_parts)

        year = datetime.now().year
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>{title}</title>
  <meta name="description" content="{meta_description}"/>
  <meta name="keywords" content="{keywords_csv}"/>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{
      font-family: 'Georgia', serif;
      background: #fafafa;
      color: #1a1a1a;
      margin: 0;
      padding: 0;
    }}
    header {{
      background: #1e293b;
      color: #fff;
      padding: 2rem 1rem;
      text-align: center;
    }}
    header h1 {{
      font-size: 2.2rem;
      margin: 0 0 0.5rem;
      line-height: 1.3;
    }}
    header p.meta {{
      font-size: 0.9rem;
      color: #94a3b8;
    }}
    article {{
      max-width: 780px;
      margin: 2.5rem auto;
      padding: 0 1.5rem;
      line-height: 1.8;
    }}
    article p {{ margin: 0 0 1.4rem; font-size: 1.05rem; }}
    article h2 {{
      font-size: 1.6rem;
      color: #1e293b;
      margin: 2.5rem 0 0.8rem;
      border-left: 4px solid #6366f1;
      padding-left: 0.75rem;
    }}
    article h3 {{
      font-size: 1.2rem;
      color: #334155;
      margin: 1.5rem 0 0.5rem;
    }}
    .cta-box {{
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      color: #fff;
      border-radius: 12px;
      padding: 2rem;
      text-align: center;
      margin: 3rem 0 2rem;
    }}
    .cta-box p {{ font-size: 1.1rem; margin-bottom: 1rem; }}
    .cta-box a {{
      display: inline-block;
      background: #fff;
      color: #6366f1;
      font-weight: 700;
      padding: 0.75rem 2rem;
      border-radius: 8px;
      text-decoration: none;
    }}
    footer {{
      text-align: center;
      padding: 2rem;
      color: #64748b;
      font-size: 0.85rem;
      border-top: 1px solid #e2e8f0;
    }}
  </style>
</head>
<body>
  <header>
    <h1>{title}</h1>
    <p class="meta">By {product_name} Team &bull; {year} &bull; {keywords_csv}</p>
  </header>
  <article>
    <p>{intro}</p>
    {sections_html}
    <div class="cta-box">
      <p>{cta_text}</p>
      <a href="#signup">Get Started Free</a>
    </div>
  </article>
  <footer>&copy; {year} {product_name}. All rights reserved.</footer>
</body>
</html>"""

        # Persist to disk
        out_dir = Path(f"/tmp/acai_pages/{product_slug}/blog")
        out_dir.mkdir(parents=True, exist_ok=True)
        html_path = out_dir / f"{post_slug}.html"
        html_path.write_text(html, encoding="utf-8")

        word_count = len(html.split())
        log.info("seo.blog_post_written", path=str(html_path), words=word_count)

        return {
            "title": title,
            "slug": post_slug,
            "html_path": str(html_path),
            "word_count": word_count,
        }

    # ── Programmatic Page ─────────────────────────────────────────────

    async def generate_programmatic_page(
        self,
        product_name: str,
        product_slug: str,
        niche: str,
        variation: str,
        cta_url: str,
    ) -> dict[str, Any]:
        """
        Generate a segment-focused landing page variant.

        variation: e.g. "for freelancers", "for law firms"
        Returns: {path, variation, title}
        """
        variation_slug = _slugify(variation)
        log.info("seo.generating_programmatic_page", product=product_name, variation=variation)

        page_data = await self._chat_json(
            system=(
                "You are a conversion-focused copywriter. "
                "Generate a targeted landing page for a specific audience segment. "
                'Return JSON: {"title": "...", "headline": "...", "subheadline": "...", '
                '"pain_points": ["...", "..."], "benefits": ["...", "..."], '
                '"social_proof": "...", "cta_label": "..."}'
            ),
            user=(
                f"Product: {product_name}\n"
                f"Niche: {niche}\n"
                f"Audience segment: {variation}\n\n"
                f"Create persuasive copy for this specific segment. "
                f"Focus on their unique pain points and how {product_name} solves them."
            ),
            temperature=0.7,
            max_tokens=2000,
        )

        title = page_data.get("title", f"{product_name} {variation}")
        headline = page_data.get("headline", title)
        subheadline = page_data.get("subheadline", "")
        pain_points = page_data.get("pain_points", [])
        benefits = page_data.get("benefits", [])
        social_proof = page_data.get("social_proof", "")
        cta_label = page_data.get("cta_label", "Get Started Free")

        pain_html = "".join(f"<li>{p}</li>" for p in pain_points)
        benefits_html = "".join(f"<li>&#10003; {b}</li>" for b in benefits)
        year = datetime.now().year

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>{title}</title>
  <meta name="description" content="{subheadline}"/>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{ font-family: 'Inter', sans-serif; background: #0f172a; color: #f8fafc; margin: 0; }}
    .hero {{
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      padding: 5rem 1.5rem 4rem;
      text-align: center;
    }}
    .hero h1 {{ font-size: 2.5rem; font-weight: 900; margin: 0 0 1rem; line-height: 1.2; }}
    .hero p {{ font-size: 1.2rem; opacity: 0.85; max-width: 600px; margin: 0 auto 2rem; }}
    .cta-btn {{
      display: inline-block;
      background: #fff;
      color: #6366f1;
      font-weight: 700;
      font-size: 1.1rem;
      padding: 0.9rem 2.5rem;
      border-radius: 10px;
      text-decoration: none;
    }}
    section {{ max-width: 900px; margin: 0 auto; padding: 3rem 1.5rem; }}
    h2 {{ font-size: 1.8rem; color: #e2e8f0; margin-bottom: 1rem; }}
    ul {{ list-style: none; padding: 0; }}
    ul li {{ padding: 0.5rem 0; font-size: 1.05rem; color: #cbd5e1; }}
    .proof {{ background: #1e293b; border-radius: 12px; padding: 2rem; font-style: italic; color: #94a3b8; }}
    footer {{ text-align: center; padding: 2rem; color: #475569; font-size: 0.85rem; border-top: 1px solid #1e293b; }}
  </style>
</head>
<body>
  <div class="hero">
    <h1>{headline}</h1>
    <p>{subheadline}</p>
    <a href="{cta_url}" class="cta-btn">{cta_label}</a>
  </div>
  <section>
    <h2>Common Challenges {variation.title()} Face</h2>
    <ul>{pain_html}</ul>
  </section>
  <section>
    <h2>Why {product_name} Is Built for {variation.title()}</h2>
    <ul>{benefits_html}</ul>
  </section>
  <section>
    <div class="proof"><p>"{social_proof}"</p></div>
  </section>
  <section style="text-align:center;">
    <a href="{cta_url}" class="cta-btn" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;">{cta_label}</a>
  </section>
  <footer>&copy; {year} {product_name}. All rights reserved.</footer>
</body>
</html>"""

        out_dir = Path(f"/tmp/acai_pages/{product_slug}/seo")
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{variation_slug}.html"
        out_path.write_text(html, encoding="utf-8")

        log.info("seo.programmatic_page_written", path=str(out_path))

        return {
            "path": str(out_path),
            "variation": variation,
            "title": title,
        }

    # ── Sitemap ───────────────────────────────────────────────────────

    async def generate_sitemap(
        self,
        product_slug: str,
        deploy_url: str,
        pages: list[str],
    ) -> str:
        """
        Generate a valid sitemap.xml and save it to disk.

        Returns: file path
        """
        deploy_url = deploy_url.rstrip("/")
        today = datetime.now().strftime("%Y-%m-%d")

        url_entries = []
        for page in pages:
            page = page.lstrip("/")
            loc = f"{deploy_url}/{page}" if page else deploy_url
            url_entries.append(
                f"  <url>\n"
                f"    <loc>{loc}</loc>\n"
                f"    <lastmod>{today}</lastmod>\n"
                f"    <changefreq>weekly</changefreq>\n"
                f"    <priority>{'1.0' if not page else '0.8'}</priority>\n"
                f"  </url>"
            )

        xml = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
            + "\n".join(url_entries)
            + "\n</urlset>"
        )

        out_dir = Path(f"/tmp/acai_pages/{product_slug}")
        out_dir.mkdir(parents=True, exist_ok=True)
        sitemap_path = out_dir / "sitemap.xml"
        sitemap_path.write_text(xml, encoding="utf-8")

        log.info("seo.sitemap_written", path=str(sitemap_path), pages=len(pages))
        return str(sitemap_path)

    # ── JSON-LD ───────────────────────────────────────────────────────

    async def generate_json_ld(
        self,
        product_name: str,
        description: str,
        url: str,
        price_monthly: float | None,
    ) -> str:
        """
        Return a JSON-LD <script> block for SoftwareApplication schema.
        """
        schema: dict[str, Any] = {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": product_name,
            "description": description,
            "url": url,
            "applicationCategory": "BusinessApplication",
            "operatingSystem": "Web",
        }

        if price_monthly is not None:
            schema["offers"] = {
                "@type": "Offer",
                "price": str(price_monthly),
                "priceCurrency": "USD",
                "priceSpecification": {
                    "@type": "UnitPriceSpecification",
                    "price": str(price_monthly),
                    "priceCurrency": "USD",
                    "unitCode": "MON",
                },
            }

        return (
            '<script type="application/ld+json">\n'
            + json.dumps(schema, indent=2)
            + "\n</script>"
        )

    # ── Comparison Page ───────────────────────────────────────────────

    async def generate_comparison_page(
        self,
        product_name: str,
        product_slug: str,
        niche: str,
        competitor_name: str,
        our_advantages: list[str],
        cta_url: str,
    ) -> dict[str, Any]:
        """
        Generate a "{product_name} vs {competitor_name}" comparison page.

        Returns: {path, title}
        """
        competitor_slug = _slugify(competitor_name)
        log.info("seo.generating_comparison_page", product=product_name, competitor=competitor_name)

        page_data = await self._chat_json(
            system=(
                "You are a conversion copywriter. Generate content for a competitor comparison page. "
                'Return JSON: {"title": "...", "intro": "...", '
                '"feature_table": [{"feature": "...", "us": "...", "them": "..."}, ...], '
                '"why_we_win": ["reason 1", ...], '
                '"testimonials": [{"name": "...", "role": "...", "quote": "..."}, ...], '
                '"cta_headline": "...", "cta_body": "..."}'
            ),
            user=(
                f"Our product: {product_name}\n"
                f"Competitor: {competitor_name}\n"
                f"Niche: {niche}\n"
                f"Our key advantages: {', '.join(our_advantages)}\n\n"
                f"Create a professional, factual comparison page. "
                f"Include 6 features in the comparison table and 3 testimonials."
            ),
            temperature=0.6,
            max_tokens=3000,
        )

        title = page_data.get("title", f"{product_name} vs {competitor_name}")
        intro = page_data.get("intro", "")
        feature_table = page_data.get("feature_table", [])
        why_we_win = page_data.get("why_we_win", [])
        testimonials = page_data.get("testimonials", [])
        cta_headline = page_data.get("cta_headline", f"Switch to {product_name} Today")
        cta_body = page_data.get("cta_body", "")

        # Build HTML
        table_rows = "".join(
            f"<tr><td>{row.get('feature','')}</td>"
            f"<td class='us'>&#10003; {row.get('us','')}</td>"
            f"<td class='them'>&#10007; {row.get('them','')}</td></tr>"
            for row in feature_table
        )
        win_items = "".join(f"<li>{r}</li>" for r in why_we_win)
        testimonial_cards = "".join(
            f'<div class="card"><p>"{t.get("quote","")}"</p>'
            f'<strong>{t.get("name","")}</strong><br/>'
            f'<span>{t.get("role","")}</span></div>'
            for t in testimonials
        )
        year = datetime.now().year

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>{title}</title>
  <meta name="description" content="{product_name} vs {competitor_name}: See why teams switch to {product_name}."/>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{ font-family: 'Inter', sans-serif; background: #0f172a; color: #f8fafc; margin: 0; }}
    .hero {{
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      padding: 5rem 1.5rem 3rem;
      text-align: center;
      border-bottom: 1px solid #1e3a5f;
    }}
    .hero h1 {{ font-size: 2.8rem; font-weight: 900; margin: 0 0 1rem; }}
    .hero p {{ font-size: 1.15rem; color: #94a3b8; max-width: 640px; margin: 0 auto; }}
    section {{ max-width: 960px; margin: 0 auto; padding: 3rem 1.5rem; }}
    h2 {{ font-size: 1.8rem; margin-bottom: 1.5rem; color: #e2e8f0; }}
    table {{ width: 100%; border-collapse: collapse; }}
    thead tr {{ background: #1e293b; }}
    thead th {{ padding: 1rem; text-align: left; font-weight: 700; }}
    tbody tr:nth-child(even) {{ background: #1e293b55; }}
    td {{ padding: 0.85rem 1rem; border-bottom: 1px solid #1e293b; color: #cbd5e1; }}
    td.us {{ color: #34d399; font-weight: 600; }}
    td.them {{ color: #f87171; }}
    ul.wins {{ list-style: none; padding: 0; }}
    ul.wins li {{ padding: 0.5rem 0 0.5rem 1.5rem; position: relative; color: #cbd5e1; }}
    ul.wins li::before {{ content: "✓"; position: absolute; left: 0; color: #6366f1; font-weight: 700; }}
    .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem; }}
    .card {{ background: #1e293b; border-radius: 12px; padding: 1.5rem; }}
    .card p {{ font-style: italic; color: #94a3b8; margin-bottom: 0.75rem; }}
    .card strong {{ color: #e2e8f0; }}
    .card span {{ color: #64748b; font-size: 0.9rem; }}
    .cta-section {{
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      text-align: center;
      padding: 4rem 1.5rem;
    }}
    .cta-section h2 {{ color: #fff; }}
    .cta-section p {{ color: rgba(255,255,255,0.85); max-width: 560px; margin: 0 auto 2rem; }}
    .cta-btn {{
      display: inline-block;
      background: #fff;
      color: #6366f1;
      font-weight: 700;
      font-size: 1.1rem;
      padding: 0.9rem 2.5rem;
      border-radius: 10px;
      text-decoration: none;
    }}
    footer {{ text-align: center; padding: 2rem; color: #475569; font-size: 0.85rem; }}
  </style>
</head>
<body>
  <div class="hero">
    <h1>{title}</h1>
    <p>{intro}</p>
  </div>

  <section>
    <h2>Feature Comparison</h2>
    <table>
      <thead>
        <tr>
          <th>Feature</th>
          <th>{product_name}</th>
          <th>{competitor_name}</th>
        </tr>
      </thead>
      <tbody>{table_rows}</tbody>
    </table>
  </section>

  <section>
    <h2>Why Teams Switch to {product_name}</h2>
    <ul class="wins">{win_items}</ul>
  </section>

  <section>
    <h2>What Our Customers Say</h2>
    <div class="cards">{testimonial_cards}</div>
  </section>

  <div class="cta-section">
    <h2>{cta_headline}</h2>
    <p>{cta_body}</p>
    <a href="{cta_url}" class="cta-btn">Get Started Free</a>
  </div>

  <footer>&copy; {year} {product_name}. All rights reserved.</footer>
</body>
</html>"""

        out_dir = Path(f"/tmp/acai_pages/{product_slug}")
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"vs-{competitor_slug}.html"
        out_path.write_text(html, encoding="utf-8")

        log.info("seo.comparison_page_written", path=str(out_path))

        return {
            "path": str(out_path),
            "title": title,
        }

    # ── Product Hunt Kit ──────────────────────────────────────────────

    async def generate_ph_kit(
        self,
        product_name: str,
        product_description: str,
        tagline: str,
        value_prop: str,
        target_audience: str,
        deploy_url: str,
    ) -> dict[str, Any]:
        """
        Generate a complete Product Hunt submission kit.

        Returns dict with: tagline, description, first_comment, topics,
                            maker_note, twitter_post
        """
        product_slug = _slugify(product_name)
        log.info("seo.generating_ph_kit", product=product_name)

        kit = await self._chat_json(
            system=(
                "You are a Product Hunt launch expert. "
                "Generate a complete PH submission kit. "
                'Return JSON: {"tagline": "...", "description": "...", '
                '"first_comment": "...", "topics": ["Topic1", ...], '
                '"maker_note": "...", "twitter_post": "..."}'
            ),
            user=(
                f"Product name: {product_name}\n"
                f"Description: {product_description}\n"
                f"Tagline hint: {tagline}\n"
                f"Value proposition: {value_prop}\n"
                f"Target audience: {target_audience}\n"
                f"URL: {deploy_url}\n\n"
                "Rules:\n"
                "- tagline: max 60 characters, punchy\n"
                "- description: max 260 characters\n"
                "- first_comment: maker intro + story, ~500 words\n"
                "- topics: list of 5 Product Hunt topic tags\n"
                "- maker_note: 200-word personal note from the founder\n"
                "- twitter_post: 280 char tweet announcing the launch"
            ),
            temperature=0.75,
            max_tokens=3000,
        )

        # Enforce character limits
        kit["tagline"] = (kit.get("tagline") or "")[:60]
        kit["description"] = (kit.get("description") or "")[:260]
        kit["twitter_post"] = (kit.get("twitter_post") or "")[:280]

        if not isinstance(kit.get("topics"), list):
            kit["topics"] = ["Productivity", "SaaS", "Startup Tools", "AI", "Marketing"]

        # Save kit to disk
        out_dir = Path(f"/tmp/acai_pages/{product_slug}")
        out_dir.mkdir(parents=True, exist_ok=True)
        kit_path = out_dir / "product_hunt_kit.json"
        kit_path.write_text(json.dumps(kit, indent=2), encoding="utf-8")

        log.info("seo.ph_kit_written", path=str(kit_path))

        return kit
