"""
FreeTrialTool — tracks free-trial state in Redis and sends expiry nudges via Kit.

Redis key: `trial:{email}:{product_slug}`
TTL: 20 days

Trial state schema:
  {
    "started_at":    ISO-8601 timestamp,
    "email":         str,
    "product_id":    str,
    "product_slug":  str,
    "product_name":  str,
    "cta_url":       str,
    "converted":     bool,
  }
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from core.config import settings
from core.logger import get_logger
from tools.kit_email import KitEmailTool, KitSubscriber, KitBroadcast

log = get_logger(__name__)

# Number of days after which we consider a trial "expiring"
EXPIRY_WARN_DAYS = 13


def _get_redis():
    import redis.asyncio as aioredis
    return aioredis.from_url(settings.REDIS_URL, decode_responses=True)


class FreeTrialTool:
    """
    Manages free-trial lifecycle: start, warn, and convert.
    """

    def __init__(self) -> None:
        self._kit = KitEmailTool()

    # ── Start a trial ──────────────────────────────────────────────────
    async def start_trial(
        self,
        email: str,
        product_id: str,
        product_name: str,
        product_slug: str,
        cta_url: str,
    ) -> dict[str, Any]:
        """
        Register a new free trial in Redis and tag the subscriber in Kit.

        Returns: {success, email, product_slug, redis_key}
        """
        redis_key = f"trial:{email}:{product_slug}"

        trial_state = {
            "started_at": datetime.now(timezone.utc).isoformat(),
            "email": email,
            "product_id": product_id,
            "product_slug": product_slug,
            "product_name": product_name,
            "cta_url": cta_url,
            "converted": False,
        }

        redis = _get_redis()
        try:
            await redis.set(
                redis_key,
                json.dumps(trial_state),
                ex=60 * 60 * 24 * 20,  # 20-day TTL
            )
        finally:
            await redis.aclose()

        # Tag the subscriber in Kit so we can target them with broadcasts
        trial_tag = f"trial-{product_slug}"
        subscriber = KitSubscriber(
            email=email,
            tags=[trial_tag],
        )
        kit_result = await self._kit.add_subscriber(subscriber)

        log.info(
            "free_trial.started",
            email=email,
            product=product_slug,
            kit_tagged=kit_result.get("success", False),
        )

        return {
            "success": True,
            "email": email,
            "product_slug": product_slug,
            "redis_key": redis_key,
            "trial_tag": trial_tag,
            "kit_subscribed": kit_result.get("success", False),
        }

    # ── Process expiring trials ───────────────────────────────────────
    async def process_expiring_trials(self) -> int:
        """
        Scan Redis for `trial:*` keys.
        For each trial where age >= EXPIRY_WARN_DAYS and not yet converted,
        send a "your trial expires tomorrow" email via Kit.

        Returns the number of expiry emails sent.
        """
        redis = _get_redis()
        sent_count = 0

        try:
            now = datetime.now(timezone.utc)
            cursor = 0

            while True:
                cursor, keys = await redis.scan(cursor, match="trial:*", count=200)

                for key in keys:
                    try:
                        raw = await redis.get(key)
                        if not raw:
                            continue

                        state: dict[str, Any] = json.loads(raw)

                        # Skip already-converted trials
                        if state.get("converted", False):
                            continue

                        started_at = datetime.fromisoformat(state["started_at"])
                        days_elapsed = (now - started_at).total_seconds() / 86400

                        if days_elapsed < EXPIRY_WARN_DAYS:
                            continue  # Not yet time to warn

                        # Check we haven't already sent the expiry email
                        if state.get("expiry_email_sent", False):
                            continue

                        # Send expiry nudge
                        result = await self._send_expiry_email(state)

                        if result.get("success"):
                            sent_count += 1
                            state["expiry_email_sent"] = True
                            ttl = await redis.ttl(key)
                            await redis.set(
                                key,
                                json.dumps(state),
                                ex=ttl if ttl > 0 else 60 * 60 * 24 * 20,
                            )
                            log.info(
                                "free_trial.expiry_email_sent",
                                email=state["email"],
                                product=state["product_slug"],
                            )
                        else:
                            log.warning(
                                "free_trial.expiry_email_failed",
                                email=state["email"],
                                error=result.get("error"),
                            )

                    except Exception as exc:
                        log.error(
                            "free_trial.process_key_failed",
                            key=key,
                            error=str(exc),
                        )

                if cursor == 0:
                    break  # Full scan complete

        finally:
            await redis.aclose()

        log.info("free_trial.process_complete", expiry_emails_sent=sent_count)
        return sent_count

    # ── Mark converted ────────────────────────────────────────────────
    async def mark_converted(self, email: str, product_slug: str) -> dict[str, Any]:
        """
        Mark a trial as converted (paid). Updates the Redis record.

        Returns: {success, email, product_slug}
        """
        redis_key = f"trial:{email}:{product_slug}"

        redis = _get_redis()
        try:
            raw = await redis.get(redis_key)
            if not raw:
                log.warning(
                    "free_trial.not_found",
                    email=email,
                    product_slug=product_slug,
                )
                return {"success": False, "error": "Trial record not found"}

            state: dict[str, Any] = json.loads(raw)
            state["converted"] = True
            state["converted_at"] = datetime.now(timezone.utc).isoformat()

            ttl = await redis.ttl(redis_key)
            await redis.set(
                redis_key,
                json.dumps(state),
                ex=ttl if ttl > 0 else 60 * 60 * 24 * 20,
            )
        finally:
            await redis.aclose()

        log.info("free_trial.converted", email=email, product=product_slug)
        return {"success": True, "email": email, "product_slug": product_slug}

    # ── Internal helpers ──────────────────────────────────────────────
    async def _send_expiry_email(self, state: dict[str, Any]) -> dict[str, Any]:
        """
        Send the "trial expires tomorrow" email to a single subscriber.
        Uses Kit send_email_to_subscriber for targeted delivery.
        """
        product_name = state.get("product_name", "the product")
        cta_url = state.get("cta_url", "")
        email = state["email"]

        subject = f"Your {product_name} trial expires tomorrow ⏰"

        html_body = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
             max-width: 600px; margin: 0 auto; padding: 20px; color: #1a1a1a;">

  <p style="font-size: 16px; line-height: 1.6;">
    Hey {{{{ subscriber.first_name | default: "there" }}}},
  </p>

  <p style="font-size: 16px; line-height: 1.6;">
    Your free trial of <strong>{product_name}</strong> expires tomorrow.
  </p>

  <p style="font-size: 16px; line-height: 1.6;">
    You've had the chance to explore everything — now it's time to decide.
    Lock in your access today and keep the momentum going.
  </p>

  <p style="font-size: 16px; line-height: 1.6;">
    <strong>Lifetime access — limited spots available.</strong>
    We can only support a limited number of active users at our current pricing.
  </p>

  <p style="text-align: center; margin: 32px 0;">
    <a href="{cta_url}"
       style="display: inline-block; background: #2563eb; color: #ffffff;
              text-decoration: none; padding: 14px 32px; border-radius: 8px;
              font-size: 16px; font-weight: 600;">
      Secure my access now →
    </a>
  </p>

  <p style="font-size: 14px; color: #6b7280;">
    Questions? Just reply to this email — we read every one.
  </p>

  <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
  <p style="font-size: 12px; color: #9ca3af;">
    You're receiving this because you signed up for a free trial of {product_name}.
    <a href="{{{{ unsubscribe_url }}}}" style="color: #9ca3af;">Unsubscribe</a>
  </p>

</body>
</html>"""

        return await self._kit.send_email_to_subscriber(
            subscriber_email=email,
            subject=subject,
            html_body=html_body,
        )
