"""
CodeGenerator — uses GPT-4o to produce full-stack application code.

Generates:
  - FastAPI backend with SQLite (portable)
  - React/Tailwind frontend via CDN
  - Dockerfile + docker-compose.yml
  - .env.example
  - README.md

All code is written to a temporary directory and zipped for deployment.
"""

from __future__ import annotations

import asyncio
import json
import os
import textwrap
import zipfile
from pathlib import Path
from typing import Any

from core.llm import get_llm_client, get_primary_model

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)


class CodeGenerator:
    """Generates complete application code using GPT-4o structured prompting."""

    SYSTEM_PROMPT = textwrap.dedent("""
        You are an expert full-stack developer.
        Given a product specification, you output a complete, production-ready
        codebase as a JSON object with this exact structure:

        {
          "files": {
            "<relative_path>": "<file_content_string>",
            ...
          },
          "start_command": "<command to start the app>",
          "install_command": "<command to install dependencies>",
          "description": "<one-sentence description of what was built>"
        }

        Rules:
        - Use FastAPI for the backend (Python 3.11+).
        - Use SQLite for persistence (portable, no external DB needed).
        - Use vanilla HTML + Tailwind CSS CDN for the frontend (no npm build step).
        - Include a working health endpoint: GET /health → {"status": "ok"}.
        - Include a Dockerfile and docker-compose.yml.
        - Include .env.example listing all required env vars.
        - Write a clear README.md.
        - Every function must be implemented — no placeholder stubs.
        - Backend port: 8080.
    """).strip()

    def __init__(self) -> None:
        self._client = get_llm_client()
        self._model = get_primary_model()  # Mistral or Gemini
    async def generate(
        self,
        product_name: str,
        product_description: str,
        niche: str,
        target_audience: str,
        features: list[str],
        tech_stack: str = "FastAPI + SQLite + Tailwind CSS",
    ) -> dict[str, Any]:
        """
        Generate a complete MVP codebase for the given product spec.

        Returns a dict with keys: files, start_command, install_command,
        description, and output_dir (local path where files were written).
        """
        spec = json.dumps(
            {
                "name": product_name,
                "description": product_description,
                "niche": niche,
                "target_audience": target_audience,
                "core_features": features,
                "tech_stack": tech_stack,
            },
            indent=2,
        )
        log.info("code_generator.generating", product=product_name)

        # Rate-limit: respect the free-tier RPM cap shared with all agents
        await asyncio.sleep(10)

        system_prompt = (
            self.SYSTEM_PROMPT
            + "\n\nCRITICAL: Your entire response MUST be a single valid JSON object. "
            "No markdown fences, no code blocks, no explanation. "
            "Just the raw JSON starting with { and ending with }."
        )

        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": f"Generate the full codebase for this product:\n\n{spec}",
                },
            ],
            temperature=0.3,
            max_tokens=8000,
        )

        raw = response.choices[0].message.content.strip()
        # Strip markdown fences if model still wraps the response
        if raw.startswith("```"):
            lines = raw.split("\n")
            raw = "\n".join(l for l in lines if not l.strip().startswith("```")).strip()
        # Find JSON boundaries
        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1:
            raw = raw[start : end + 1]
        try:
            code_result: dict[str, Any] = json.loads(raw)
        except json.JSONDecodeError as exc:
            log.warning("code_generator.json_parse_failed", error=str(exc))
            # Fallback: use the landing page HTML if it exists (real content > README)
            from slugify import slugify as _slugify  # type: ignore
            _slug = _slugify(product_name)
            landing_html_path = Path(f"/tmp/acai_pages/{_slug}/index.html")
            if landing_html_path.exists():
                log.info("code_generator.using_landing_page_fallback", product=product_name)
                code_result = {
                    "files": {
                        "index.html": landing_html_path.read_text(encoding="utf-8"),
                    },
                    "start_command": "echo 'Static site — no server needed'",
                    "install_command": "",
                    "description": f"Landing page for {product_name} (static HTML)",
                }
            else:
                code_result = {
                    "files": {"README.md": f"# {product_name}\n\nCode generation truncated.\nRe-run to generate full codebase."},
                    "start_command": "echo 'Re-run code generation'",
                    "install_command": "pip install fastapi uvicorn",
                    "description": f"MVP scaffold for {product_name} (generation truncated — retry)",
                }

        # Write files to disk
        output_dir = self._write_files(product_name, code_result["files"])
        code_result["output_dir"] = str(output_dir)

        log.info(
            "code_generator.generated",
            product=product_name,
            file_count=len(code_result["files"]),
            output_dir=str(output_dir),
        )
        return code_result

    def _write_files(self, product_name: str, files: dict[str, str]) -> Path:
        """Write generated files to /tmp/acai_builds/<slug> and return the path."""
        from slugify import slugify  # type: ignore

        slug = slugify(product_name)
        base_dir = Path(f"/tmp/acai_builds/{slug}")
        base_dir.mkdir(parents=True, exist_ok=True)

        for relative_path, content in files.items():
            target = base_dir / relative_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")

        log.info("code_generator.files_written", dir=str(base_dir), count=len(files))
        return base_dir

    async def create_zip(self, output_dir: str) -> str:
        """Zip the generated project directory. Returns the zip file path."""
        source = Path(output_dir)
        zip_path = source.parent / f"{source.name}.zip"

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for file_path in source.rglob("*"):
                if file_path.is_file():
                    zf.write(file_path, file_path.relative_to(source.parent))

        log.info("code_generator.zipped", path=str(zip_path))
        return str(zip_path)

    async def generate_component(
        self,
        component_type: str,
        requirements: str,
        context: str = "",
    ) -> str:
        """
        Generate a single code component (e.g. an API endpoint, a React component).
        Returns the raw code string.
        """
        prompt = (
            f"Write a production-ready {component_type}.\n\n"
            f"Requirements:\n{requirements}\n\n"
            f"Context:\n{context}\n\n"
            "Output ONLY the code, no explanation."
        )

        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert software engineer. Write clean, working code.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=3000,
        )
        return response.choices[0].message.content.strip()
