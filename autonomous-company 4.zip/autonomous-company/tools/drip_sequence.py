"""
DripSequenceTool — 7-email drip sequence manager backed by Redis.

Sequence schedule:
  Day  1  — Welcome / orientation
  Day  3  — Problem agitation
  Day  5  — Solution walkthrough
  Day  7  — Social proof / testimonials
  Day 10  — FAQ / objection handling
  Day 14  — Trial expiring (urgency)
  Day 15  — Special offer (last chance)

Drip state stored in Redis under key `drip:{email}:{tag_name}` as JSON.
"""

from __future__ import annotations

import json
import textwrap
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from core.llm import get_llm_client, get_primary_model

from core.config import settings
from core.logger import get_logger
from tools.kit_email import KitEmailTool, KitSubscriber

log = get_logger(__name__)

# Day offsets for each email in the sequence (0-indexed position → day number)
DRIP_SCHEDULE = [1, 3, 5, 7, 10, 14, 15]

DRIP_TYPES = [
    "welcome",
    "problem_agitation",
    "solution_walkthrough",
    "social_proof",
    "faq_objections",
    "trial_expiring",
    "special_offer",
]


def _get_redis():
    """Return a synchronous-style async Redis client (aioredis / redis-py)."""
    import redis.asyncio as aioredis  # redis-py >= 4.2 ships async support
    return aioredis.from_url(settings.REDIS_URL, decode_responses=True)


class DripSequenceTool:
    """
    Manages 7-email drip sequences per subscriber.
    Uses Kit for delivery and Redis for state tracking.
    """

    def __init__(self) -> None:
        self._kit = KitEmailTool()
        self._llm = get_llm_client()
        self._model = get_primary_model()
    # ── Enrollment ────────────────────────────────────────────────────
    async def enroll_subscriber(
        self,
        email: str,
        first_name: str,
        product_name: str,
        product_description: str,
        value_prop: str,
        cta_url: str,
        tag_name: str,
        niche: str,
    ) -> dict[str, Any]:
        """
        Generate 7 LLM-written emails, store them in Redis, and subscribe
        the user to the Kit tag.

        Returns: {success, email, tag_name, redis_key}
        """
        log.info("drip_sequence.enrolling", email=email, tag=tag_name)

        # 1. Generate 7-email sequence via LLM
        emails = await self._generate_sequence(
            email=email,
            first_name=first_name or "there",
            product_name=product_name,
            product_description=product_description,
            value_prop=value_prop,
            cta_url=cta_url,
            niche=niche,
        )

        # 2. Subscribe user to Kit tag
        subscriber = KitSubscriber(
            email=email,
            first_name=first_name or "",
            tags=[tag_name],
        )
        kit_result = await self._kit.add_subscriber(subscriber)
        if not kit_result.get("success"):
            log.warning(
                "drip_sequence.kit_subscribe_failed",
                email=email,
                error=kit_result.get("error"),
            )

        # 3. Store drip state in Redis
        redis_key = f"drip:{email}:{tag_name}"
        drip_state = {
            "emails": emails,
            "enrolled_at": datetime.now(timezone.utc).isoformat(),
            "sent_index": 0,
            "email": email,
            "first_name": first_name or "",
            "tag_name": tag_name,
            "product_name": product_name,
            "cta_url": cta_url,
            "kit_subscriber_id": kit_result.get("subscriber_id"),
        }

        redis = _get_redis()
        try:
            await redis.set(
                redis_key,
                json.dumps(drip_state),
                ex=60 * 60 * 24 * 20,  # 20-day TTL
            )
        finally:
            await redis.aclose()

        log.info(
            "drip_sequence.enrolled",
            email=email,
            tag=tag_name,
            email_count=len(emails),
        )
        return {
            "success": True,
            "email": email,
            "tag_name": tag_name,
            "redis_key": redis_key,
            "emails_queued": len(emails),
            "kit_subscribed": kit_result.get("success", False),
        }

    # ── Due drip processing ───────────────────────────────────────────
    async def process_due_drips(self) -> int:
        """
        Scan all `drip:*` Redis keys, determine which emails are due based on
        enrolled_at + DRIP_SCHEDULE, send via Kit, and update sent_index.

        Returns the number of emails sent.
        """
        redis = _get_redis()
        sent_count = 0

        try:
            now = datetime.now(timezone.utc)
            cursor = 0
            pattern = "drip:*"

            while True:
                cursor, keys = await redis.scan(cursor, match=pattern, count=200)
                for key in keys:
                    try:
                        raw = await redis.get(key)
                        if not raw:
                            continue
                        state: dict[str, Any] = json.loads(raw)
                        sent_index: int = state.get("sent_index", 0)
                        emails: list[dict] = state.get("emails", [])

                        if sent_index >= len(emails):
                            continue  # Sequence complete

                        enrolled_at = datetime.fromisoformat(state["enrolled_at"])
                        days_elapsed = (now - enrolled_at).total_seconds() / 86400

                        # Find all emails due up to today that haven't been sent
                        while sent_index < len(DRIP_SCHEDULE):
                            due_day = DRIP_SCHEDULE[sent_index]
                            if days_elapsed >= due_day:
                                email_data = emails[sent_index]
                                result = await self._kit.send_email_to_subscriber(
                                    subscriber_email=state["email"],
                                    subject=email_data["subject"],
                                    html_body=email_data["html_body"],
                                )
                                if result.get("success"):
                                    sent_count += 1
                                    sent_index += 1
                                    log.info(
                                        "drip_sequence.sent",
                                        email=state["email"],
                                        index=sent_index,
                                        day=due_day,
                                    )
                                else:
                                    log.warning(
                                        "drip_sequence.send_failed",
                                        email=state["email"],
                                        error=result.get("error"),
                                    )
                                    break  # Retry next cycle
                            else:
                                break  # Not yet due

                        # Update state
                        state["sent_index"] = sent_index
                        ttl = await redis.ttl(key)
                        await redis.set(
                            key,
                            json.dumps(state),
                            ex=ttl if ttl > 0 else 60 * 60 * 24 * 20,
                        )

                    except Exception as exc:
                        log.error("drip_sequence.process_key_failed", key=key, error=str(exc))

                if cursor == 0:
                    break  # Full scan complete

        finally:
            await redis.aclose()

        log.info("drip_sequence.process_complete", emails_sent=sent_count)
        return sent_count

    # ── LLM email generation ──────────────────────────────────────────
    async def _generate_sequence(
        self,
        email: str,
        first_name: str,
        product_name: str,
        product_description: str,
        value_prop: str,
        cta_url: str,
        niche: str,
    ) -> list[dict[str, str]]:
        """
        Ask the LLM to write all 7 drip emails in one shot.
        Returns a list of {subject, html_body, text_body, day, email_type} dicts.
        """
        prompt = textwrap.dedent(f"""
            You are a world-class email copywriter specialising in SaaS drip sequences.

            Write a 7-email drip sequence for the product below.

            Product: {product_name}
            Description: {product_description}
            Value proposition: {value_prop}
            CTA URL: {cta_url}
            Niche / industry: {niche}

            Email schedule and purpose:
            1. Day 1  — Welcome: orient the subscriber, deliver quick win
            2. Day 3  — Problem: agitate the core pain they feel without this product
            3. Day 5  — Solution walkthrough: show step-by-step how the product solves it
            4. Day 7  — Social proof: testimonials, case studies, or results data
            5. Day 10 — FAQ / objection handling: address top 3 objections
            6. Day 14 — Trial expiring: urgency, "your access expires soon"
            7. Day 15 — Special offer: 20% discount code SAVE20, limited time

            Rules:
            - Use {{{{ subscriber.first_name | default: "there" }}}} personalisation in subject or opener
            - Subject lines: 6-10 words, high curiosity/benefit, no spam triggers
            - Body: conversational, short paragraphs, 150-250 words each
            - One clear CTA button per email pointing to: {cta_url}
            - Plain HTML, inline styles only, no external CSS
            - Include a text version fallback

            Return a JSON array of exactly 7 objects:
            [
              {{
                "day": 1,
                "email_type": "welcome",
                "subject": "...",
                "html_body": "<full HTML email body>",
                "text_body": "plain text version"
              }},
              ...
            ]
        """).strip()

        response = await self._llm.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.7,
            max_tokens=8000,
        )

        raw = json.loads(response.choices[0].message.content)

        # Handle both {emails: [...]} and plain [...] responses
        if isinstance(raw, dict):
            emails = raw.get("emails") or raw.get("sequence") or list(raw.values())[0]
        else:
            emails = raw

        if not isinstance(emails, list):
            log.warning("drip_sequence.unexpected_llm_format", type=type(emails).__name__)
            emails = []

        # Normalise keys — accept html_body or content_html
        normalised: list[dict[str, str]] = []
        for i, item in enumerate(emails[:7]):
            normalised.append(
                {
                    "day": item.get("day", DRIP_SCHEDULE[i] if i < len(DRIP_SCHEDULE) else i + 1),
                    "email_type": item.get("email_type", DRIP_TYPES[i] if i < len(DRIP_TYPES) else "nurture"),
                    "subject": item.get("subject", f"A message about {product_name}"),
                    "html_body": item.get("html_body") or item.get("content_html", ""),
                    "text_body": item.get("text_body") or item.get("content_text", ""),
                }
            )

        log.info("drip_sequence.generated", count=len(normalised), product=product_name)
        return normalised
