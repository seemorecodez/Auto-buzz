"""
LeadScoringTool — behavioural lead scoring backed by Redis.

Scores are stored as integers in Redis under the key pattern:
    lead_score:{product_slug}:{email}

Event point values:
    subscribed      → 1
    opened_email    → 3
    clicked_link    → 5
    visited_pricing → 8
    started_trial   → 15
    replied         → 10
"""

from __future__ import annotations

from typing import Any

import httpx

from core.config import settings
from core.logger import get_logger
from core.redis_client import get_redis

log = get_logger(__name__)

EVENT_POINTS: dict[str, int] = {
    "subscribed": 1,
    "opened_email": 3,
    "clicked_link": 5,
    "visited_pricing": 8,
    "started_trial": 15,
    "replied": 10,
}

_KEY_PREFIX = "lead_score"


def _score_key(product_slug: str, email: str) -> str:
    return f"{_KEY_PREFIX}:{product_slug}:{email}"


class LeadScoringTool:
    """Scores leads based on behavioural events and caches results in Redis."""

    # ── score_subscriber ──────────────────────────────────────────────────────
    async def score_subscriber(self, email: str, product_slug: str) -> int:
        """
        Return the current lead score for *email* on *product_slug*.
        Checks Redis cache first; falls back to base score of 1 (subscribed).
        """
        try:
            r = await get_redis()
            key = _score_key(product_slug, email)
            raw = await r.get(key)
            if raw is not None:
                return int(raw)
        except Exception as exc:
            log.debug("lead_scoring.score_subscriber.redis_error", error=str(exc))
        # Base score: subscriber exists
        return 1

    # ── update_score ──────────────────────────────────────────────────────────
    async def update_score(self, email: str, product_slug: str, event: str) -> int:
        """
        Add points for *event* to the stored score and return the new total.
        Unrecognised events add 0 points.
        """
        points = EVENT_POINTS.get(event, 0)
        key = _score_key(product_slug, email)
        try:
            r = await get_redis()
            raw = await r.get(key)
            current = int(raw) if raw is not None else 0
            new_score = current + points
            await r.set(key, str(new_score))
            log.debug(
                "lead_scoring.updated",
                email=email,
                product=product_slug,
                event=event,
                points=points,
                new_score=new_score,
            )
            return new_score
        except Exception as exc:
            log.warning("lead_scoring.update_score.redis_error", error=str(exc))
            return points  # Best-effort: return at least the points for this event

    # ── get_top_leads ─────────────────────────────────────────────────────────
    async def get_top_leads(self, product_slug: str, limit: int = 20) -> list[dict]:
        """
        Scan Redis for all lead scores for *product_slug* and return the top
        *limit* leads sorted by score descending.

        Returns: [{email: str, score: int}, ...]
        """
        pattern = f"{_KEY_PREFIX}:{product_slug}:*"
        leads: list[dict] = []
        try:
            r = await get_redis()
            cursor = 0
            while True:
                cursor, keys = await r.scan(cursor, match=pattern, count=200)
                for key in keys:
                    raw = await r.get(key)
                    if raw is not None:
                        # Key format: lead_score:{product_slug}:{email}
                        email = key.split(":", 2)[-1]
                        leads.append({"email": email, "score": int(raw)})
                if cursor == 0:
                    break
        except Exception as exc:
            log.warning("lead_scoring.get_top_leads.redis_error", error=str(exc))

        leads.sort(key=lambda x: x["score"], reverse=True)
        return leads[:limit]

    # ── score_all_kit_subscribers ─────────────────────────────────────────────
    async def score_all_kit_subscribers(
        self, product_slug: str, kit_tool: Any
    ) -> dict:
        """
        Pull all subscribers tagged with *product_slug* from Kit and assign
        initial scores based on engagement stats.

        Returns: {scored: int, top_leads: [{email, score}, ...]}
        """
        # Find the Kit tag that matches this product
        tags = await kit_tool.list_tags()
        tag_id: int | None = None
        for tag in tags:
            tag_name = tag.get("name", "").lower()
            slug_lower = product_slug.lower()
            if tag_name in (
                slug_lower,
                f"acai-{slug_lower}",
                slug_lower.replace("-", "_"),
            ):
                tag_id = tag["id"]
                break

        if not tag_id:
            log.info("lead_scoring.no_tag_found", product_slug=product_slug)
            return {"scored": 0, "top_leads": []}

        # Fetch subscribers for this tag via Kit API
        api_key = settings.KIT_API_KEY
        base = settings.KIT_API_BASE.rstrip("/")
        subscriptions: list[dict] = []
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{base}/tags/{tag_id}/subscriptions",
                    params={"api_key": api_key},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    subscriptions = data.get("subscriptions", [])
        except Exception as exc:
            log.warning(
                "lead_scoring.kit_fetch_error",
                product_slug=product_slug,
                error=str(exc),
            )

        scored = 0
        try:
            r = await get_redis()
            for sub in subscriptions:
                subscriber = sub.get("subscriber", sub)
                email = subscriber.get("email_address", "")
                if not email:
                    continue

                # Base score: 1 for being subscribed
                score = EVENT_POINTS["subscribed"]

                # Add points for engagement stats if available
                stats = subscriber.get("stats", {})
                if stats.get("total_email_opens", 0) > 0 or stats.get("opens", 0) > 0:
                    score += EVENT_POINTS["opened_email"]
                if stats.get("total_clicks", 0) > 0 or stats.get("clicks", 0) > 0:
                    score += EVENT_POINTS["clicked_link"]

                key = _score_key(product_slug, email)
                await r.set(key, str(score))
                scored += 1
        except Exception as exc:
            log.warning(
                "lead_scoring.redis_store_error",
                product_slug=product_slug,
                error=str(exc),
            )

        top_leads = await self.get_top_leads(product_slug, limit=10)
        log.info(
            "lead_scoring.batch_complete",
            product_slug=product_slug,
            scored=scored,
            top_leads_count=len(top_leads),
        )
        return {"scored": scored, "top_leads": top_leads}
