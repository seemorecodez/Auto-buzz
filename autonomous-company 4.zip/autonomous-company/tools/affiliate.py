"""
AffiliateTool — affiliate tracking and portal generation for portfolio products.

Features:
  - Generate unique affiliate links per email+product
  - Track clicks and conversions in Redis
  - 30% recurring commission
  - HTML affiliate portal page
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from core.logger import get_logger
from core.redis_client import get_redis

log = get_logger(__name__)


class AffiliateTool:
    """Manages affiliate links, tracking, and portal pages for portfolio products."""

    COMMISSION_RATE = 0.30

    # ── Link Generation ───────────────────────────────────────────────
    async def generate_affiliate_link(
        self, product_slug: str, affiliate_email: str
    ) -> dict[str, Any]:
        """
        Create a unique affiliate link for an email+product pair.
        Stores tracking data in Redis and returns the affiliate details.
        """
        affiliate_id = hashlib.md5(
            f"{affiliate_email}:{product_slug}".encode()
        ).hexdigest()[:8]

        redis = await get_redis()

        record = {
            "email": affiliate_email,
            "product_slug": product_slug,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "clicks": 0,
            "conversions": 0,
            "commission_rate": self.COMMISSION_RATE,
            "total_commission_earned": 0.0,
        }

        await redis.set(f"affiliate:{affiliate_id}", json.dumps(record))
        await redis.set(
            f"affiliate_by_email:{affiliate_email}:{product_slug}", affiliate_id
        )

        tracking_url = f"https://{product_slug}.vercel.app/?ref={affiliate_id}"

        log.info(
            "affiliate.link_generated",
            affiliate_id=affiliate_id,
            product=product_slug,
            email=affiliate_email,
        )

        return {
            "affiliate_id": affiliate_id,
            "tracking_url": tracking_url,
            "commission_rate": self.COMMISSION_RATE,
        }

    # ── Click Tracking ────────────────────────────────────────────────
    async def track_click(self, affiliate_id: str) -> bool:
        """
        Increment the click counter for an affiliate.
        Returns True if the affiliate exists, False otherwise.
        """
        redis = await get_redis()
        raw = await redis.get(f"affiliate:{affiliate_id}")
        if not raw:
            return False

        record = json.loads(raw)
        record["clicks"] = record.get("clicks", 0) + 1
        await redis.set(f"affiliate:{affiliate_id}", json.dumps(record))

        log.info(
            "affiliate.click_tracked",
            affiliate_id=affiliate_id,
            total_clicks=record["clicks"],
        )
        return True

    # ── Conversion Tracking ───────────────────────────────────────────
    async def track_conversion(
        self, affiliate_id: str, sale_amount_usd: float
    ) -> dict[str, Any]:
        """
        Record a conversion and calculate commission earned.
        Returns commission details.
        """
        redis = await get_redis()
        raw = await redis.get(f"affiliate:{affiliate_id}")
        if not raw:
            return {"commission_earned": 0.0, "total_conversions": 0}

        record = json.loads(raw)
        commission = round(sale_amount_usd * self.COMMISSION_RATE, 2)
        record["conversions"] = record.get("conversions", 0) + 1
        record["total_commission_earned"] = round(
            record.get("total_commission_earned", 0.0) + commission, 2
        )
        await redis.set(f"affiliate:{affiliate_id}", json.dumps(record))

        log.info(
            "affiliate.conversion_tracked",
            affiliate_id=affiliate_id,
            sale_amount=sale_amount_usd,
            commission=commission,
            total_conversions=record["conversions"],
        )

        return {
            "commission_earned": commission,
            "total_conversions": record["conversions"],
        }

    # ── Stats Retrieval ───────────────────────────────────────────────
    async def get_affiliate_stats(self, product_slug: str) -> list[dict[str, Any]]:
        """
        Return all affiliate records for a given product, sorted by conversions desc.
        """
        redis = await get_redis()

        # Scan for all affiliate keys
        affiliates: list[dict[str, Any]] = []
        cursor = 0
        while True:
            cursor, keys = await redis.scan(cursor, match="affiliate:*", count=100)
            for key in keys:
                # Skip reverse-lookup keys
                key_str = key if isinstance(key, str) else key.decode()
                if "affiliate_by_email" in key_str:
                    continue
                raw = await redis.get(key_str)
                if not raw:
                    continue
                try:
                    record = json.loads(raw)
                except (json.JSONDecodeError, TypeError):
                    continue
                if record.get("product_slug") == product_slug:
                    affiliate_id = key_str.replace("affiliate:", "")
                    affiliates.append({"affiliate_id": affiliate_id, **record})
            if cursor == 0:
                break

        affiliates.sort(key=lambda x: x.get("conversions", 0), reverse=True)
        return affiliates

    # ── Portal HTML Generation ────────────────────────────────────────
    async def generate_affiliate_portal_html(
        self,
        product_slug: str,
        product_name: str,
        deploy_url: str,
    ) -> str:
        """
        Generate a complete HTML affiliate signup + dashboard page.
        Includes signup form, commission details, and affiliate link display.
        """
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{product_name} Affiliate Program</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    :root {{
      --bg: #0a0a0a;
      --surface: #111111;
      --border: #222222;
      --accent: #00ff88;
      --accent-dim: #00cc6a;
      --text: #e8e8e8;
      --muted: #888888;
      --radius: 12px;
    }}
    body {{
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      min-height: 100vh;
    }}
    .container {{
      max-width: 800px;
      margin: 0 auto;
      padding: 40px 20px;
    }}
    header {{
      text-align: center;
      margin-bottom: 60px;
    }}
    .badge {{
      display: inline-block;
      background: rgba(0, 255, 136, 0.1);
      color: var(--accent);
      border: 1px solid var(--accent);
      border-radius: 20px;
      padding: 4px 16px;
      font-size: 13px;
      font-weight: 600;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      margin-bottom: 20px;
    }}
    h1 {{
      font-size: clamp(28px, 5vw, 48px);
      font-weight: 800;
      letter-spacing: -0.02em;
      margin-bottom: 16px;
      background: linear-gradient(135deg, #fff 0%, #aaa 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }}
    .subtitle {{
      color: var(--muted);
      font-size: 18px;
      max-width: 600px;
      margin: 0 auto;
    }}
    .cards {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-bottom: 50px;
    }}
    .card {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 28px;
      text-align: center;
    }}
    .card .value {{
      font-size: 36px;
      font-weight: 800;
      color: var(--accent);
      display: block;
    }}
    .card .label {{
      color: var(--muted);
      font-size: 14px;
      margin-top: 6px;
    }}
    .section {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 40px;
      margin-bottom: 30px;
    }}
    .section h2 {{
      font-size: 22px;
      font-weight: 700;
      margin-bottom: 24px;
      color: #fff;
    }}
    .steps {{
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }}
    .steps li {{
      display: flex;
      align-items: flex-start;
      gap: 16px;
    }}
    .steps li .num {{
      flex-shrink: 0;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(0, 255, 136, 0.15);
      border: 1px solid var(--accent);
      color: var(--accent);
      font-weight: 700;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .steps li .text {{
      padding-top: 4px;
    }}
    .steps li .text strong {{
      display: block;
      color: #fff;
      margin-bottom: 2px;
    }}
    .steps li .text span {{
      color: var(--muted);
      font-size: 14px;
    }}
    .form-group {{
      margin-bottom: 20px;
    }}
    label {{
      display: block;
      font-size: 14px;
      font-weight: 600;
      color: var(--muted);
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }}
    input[type="email"] {{
      width: 100%;
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 14px 16px;
      color: var(--text);
      font-size: 16px;
      transition: border-color 0.2s;
      outline: none;
    }}
    input[type="email"]:focus {{
      border-color: var(--accent);
    }}
    .btn {{
      width: 100%;
      background: var(--accent);
      color: #000;
      border: none;
      border-radius: 8px;
      padding: 16px;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.2s, transform 0.1s;
    }}
    .btn:hover {{
      background: var(--accent-dim);
    }}
    .btn:active {{
      transform: scale(0.98);
    }}
    .result-box {{
      display: none;
      background: var(--bg);
      border: 1px solid var(--accent);
      border-radius: 8px;
      padding: 20px;
      margin-top: 20px;
    }}
    .result-box .link-label {{
      font-size: 12px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 8px;
    }}
    .result-box .link-value {{
      font-family: monospace;
      font-size: 14px;
      color: var(--accent);
      word-break: break-all;
    }}
    .copy-btn {{
      margin-top: 12px;
      background: transparent;
      border: 1px solid var(--accent);
      color: var(--accent);
      padding: 8px 20px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: background 0.2s;
    }}
    .copy-btn:hover {{
      background: rgba(0, 255, 136, 0.1);
    }}
    .error-msg {{
      display: none;
      color: #ff4444;
      font-size: 14px;
      margin-top: 10px;
    }}
    footer {{
      text-align: center;
      color: var(--muted);
      font-size: 13px;
      margin-top: 60px;
    }}
    footer a {{
      color: var(--accent);
      text-decoration: none;
    }}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="badge">Affiliate Program</div>
      <h1>Earn 30% Recurring Commission</h1>
      <p class="subtitle">
        Partner with {product_name} and earn a 30% recurring commission on every
        customer you refer — for the lifetime of their subscription.
      </p>
    </header>

    <!-- Stats -->
    <div class="cards">
      <div class="card">
        <span class="value">30%</span>
        <span class="label">Recurring Commission</span>
      </div>
      <div class="card">
        <span class="value">Forever</span>
        <span class="label">Commission Duration</span>
      </div>
      <div class="card">
        <span class="value">Monthly</span>
        <span class="label">Payout Schedule</span>
      </div>
    </div>

    <!-- How it works -->
    <div class="section">
      <h2>How It Works</h2>
      <ul class="steps">
        <li>
          <span class="num">1</span>
          <div class="text">
            <strong>Sign up below</strong>
            <span>Enter your email to instantly generate your unique affiliate link.</span>
          </div>
        </li>
        <li>
          <span class="num">2</span>
          <div class="text">
            <strong>Share your link</strong>
            <span>Post it on social media, your blog, newsletter, or anywhere your audience is.</span>
          </div>
        </li>
        <li>
          <span class="num">3</span>
          <div class="text">
            <strong>Get paid</strong>
            <span>Earn 30% of every subscription payment — recurring, for as long as they stay.</span>
          </div>
        </li>
      </ul>
    </div>

    <!-- Signup form -->
    <div class="section">
      <h2>Get Your Affiliate Link</h2>
      <div class="form-group">
        <label for="email">Your Email Address</label>
        <input
          type="email"
          id="email"
          placeholder="you@example.com"
          autocomplete="email"
        />
      </div>
      <button class="btn" onclick="generateLink()">Generate My Affiliate Link</button>
      <p class="error-msg" id="errorMsg"></p>

      <div class="result-box" id="resultBox">
        <div class="link-label">Your Affiliate Link</div>
        <div class="link-value" id="linkValue"></div>
        <button class="copy-btn" onclick="copyLink()">Copy Link</button>
      </div>
    </div>

    <footer>
      <p>
        Questions? Visit <a href="{deploy_url}" target="_blank">{product_name}</a>
        or email us at affiliates@{product_slug}.com
      </p>
    </footer>
  </div>

  <script>
    async function generateLink() {{
      const email = document.getElementById('email').value.trim();
      const errorMsg = document.getElementById('errorMsg');
      const resultBox = document.getElementById('resultBox');
      const linkValue = document.getElementById('linkValue');

      errorMsg.style.display = 'none';
      resultBox.style.display = 'none';

      if (!email || !email.includes('@')) {{
        errorMsg.textContent = 'Please enter a valid email address.';
        errorMsg.style.display = 'block';
        return;
      }}

      try {{
        const resp = await fetch('/api/affiliates/generate', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify({{ email, product_slug: '{product_slug}' }}),
        }});
        const data = await resp.json();
        if (data.tracking_url) {{
          linkValue.textContent = data.tracking_url;
          resultBox.style.display = 'block';
        }} else {{
          // Fallback: construct the link client-side for demo purposes
          const id = btoa(email + ':{product_slug}').substring(0, 8).toLowerCase();
          linkValue.textContent = 'https://{product_slug}.vercel.app/?ref=' + id;
          resultBox.style.display = 'block';
        }}
      }} catch (e) {{
        // Fallback for static deployments
        const encoder = new TextEncoder();
        const data = encoder.encode(email + ':{product_slug}');
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const id = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 8);
        linkValue.textContent = 'https://{product_slug}.vercel.app/?ref=' + id;
        resultBox.style.display = 'block';
      }}
    }}

    function copyLink() {{
      const text = document.getElementById('linkValue').textContent;
      navigator.clipboard.writeText(text).then(() => {{
        const btn = document.querySelector('.copy-btn');
        btn.textContent = 'Copied!';
        setTimeout(() => {{ btn.textContent = 'Copy Link'; }}, 2000);
      }});
    }}

    document.getElementById('email').addEventListener('keydown', (e) => {{
      if (e.key === 'Enter') generateLink();
    }});
  </script>
</body>
</html>"""
        return html
