"""Revenue systems: affiliate tracking, lead scoring, trial tracking.

Revision ID: 003_revenue_systems
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "003_revenue_systems"
down_revision = "002_crypto_wallet"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Affiliate referrals table
    op.create_table(
        "affiliate_referrals",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("affiliate_id", sa.String(8), nullable=False, index=True),
        sa.Column("affiliate_email", sa.String(255), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("product_slug", sa.String(100), nullable=False),
        sa.Column("commission_rate", sa.Float, nullable=False, default=0.30),
        sa.Column("clicks", sa.Integer, nullable=False, default=0),
        sa.Column("conversions", sa.Integer, nullable=False, default=0),
        sa.Column("commission_earned_usd", sa.Float, nullable=False, default=0.0),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Lead scoring table
    op.create_table(
        "lead_scores",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("product_slug", sa.String(100), nullable=False),
        sa.Column("score", sa.Integer, nullable=False, default=0),
        sa.Column("events", sa.JSON, nullable=True),
        sa.Column("last_updated", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("email", "product_slug", name="uq_lead_score"),
    )

    # Free trial tracking table
    op.create_table(
        "free_trials",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("product_id", sa.String(36), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("product_slug", sa.String(100), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("converted", sa.Boolean, nullable=False, default=False),
        sa.Column("converted_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("email", "product_slug", name="uq_free_trial"),
    )

    # Add ltd_price_usd to products if missing
    try:
        op.add_column("products", sa.Column("ltd_price_usd", sa.Float, nullable=True))
    except Exception:
        pass

    # Add price_bumped flag to products
    try:
        op.add_column("products", sa.Column("price_bumped", sa.Boolean, nullable=True, default=False))
    except Exception:
        pass


def downgrade() -> None:
    op.drop_table("free_trials")
    op.drop_table("lead_scores")
    op.drop_table("affiliate_referrals")
