"""Initial schema — products, tasks, metrics, actions

Revision ID: 001
Revises:
Create Date: 2025-01-01 00:00:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── products ──────────────────────────────────────────────────────
    op.create_table(
        "products",
        sa.Column("id", sa.String(36), primary_key=True, nullable=False),
        sa.Column("name", sa.String(256), nullable=False),
        sa.Column("slug", sa.String(256), nullable=False, unique=True),
        sa.Column("niche", sa.String(256), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("tagline", sa.String(512), nullable=True),
        sa.Column(
            "status",
            sa.Enum(
                "ideating", "building", "deployed", "growing",
                "monetizing", "optimizing", "paused", "archived",
                name="productstatus",
            ),
            nullable=False,
            default="ideating",
        ),
        sa.Column("landing_page_url", sa.String(512), nullable=True),
        sa.Column("repo_url", sa.String(512), nullable=True),
        sa.Column("deploy_url", sa.String(512), nullable=True),
        sa.Column("stripe_product_id", sa.String(256), nullable=True),
        sa.Column("stripe_price_id", sa.String(256), nullable=True),
        sa.Column("mrr", sa.Float, nullable=False, default=0.0),
        sa.Column("arr", sa.Float, nullable=False, default=0.0),
        sa.Column("total_revenue", sa.Float, nullable=False, default=0.0),
        sa.Column("price_monthly", sa.Float, nullable=True),
        sa.Column("price_annual", sa.Float, nullable=True),
        sa.Column("visitors", sa.Integer, nullable=False, default=0),
        sa.Column("signups", sa.Integer, nullable=False, default=0),
        sa.Column("paid_customers", sa.Integer, nullable=False, default=0),
        sa.Column("churn_rate", sa.Float, nullable=False, default=0.0),
        sa.Column("target_audience", sa.Text, nullable=True),
        sa.Column("value_proposition", sa.Text, nullable=True),
        sa.Column("go_to_market_strategy", sa.Text, nullable=True),
        sa.Column("tech_stack", sa.String(512), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index("ix_products_slug", "products", ["slug"])
    op.create_index("ix_products_status", "products", ["status"])

    # ── tasks ─────────────────────────────────────────────────────────
    op.create_table(
        "tasks",
        sa.Column("id", sa.String(36), primary_key=True, nullable=False),
        sa.Column(
            "product_id",
            sa.String(36),
            sa.ForeignKey("products.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column(
            "agent_type",
            sa.Enum(
                "meta", "builder", "growth", "content",
                "monetization", "data", "operator",
                name="agenttype",
            ),
            nullable=False,
        ),
        sa.Column("task_type", sa.String(128), nullable=False),
        sa.Column("priority", sa.Integer, nullable=False, default=5),
        sa.Column("instruction", sa.Text, nullable=False),
        sa.Column("context", sa.Text, nullable=True),
        sa.Column("result", sa.Text, nullable=True),
        sa.Column("error", sa.Text, nullable=True),
        sa.Column(
            "status",
            sa.Enum(
                "pending", "queued", "in_progress", "completed",
                "failed", "retrying", "cancelled",
                name="taskstatus",
            ),
            nullable=False,
            default="pending",
        ),
        sa.Column("retry_count", sa.Integer, nullable=False, default=0),
        sa.Column("celery_task_id", sa.String(256), nullable=True),
        sa.Column("duration_ms", sa.Integer, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index("ix_tasks_product_id", "tasks", ["product_id"])
    op.create_index("ix_tasks_status", "tasks", ["status"])
    op.create_index("ix_tasks_agent_type", "tasks", ["agent_type"])

    # ── metrics ───────────────────────────────────────────────────────
    op.create_table(
        "metrics",
        sa.Column("id", sa.String(36), primary_key=True, nullable=False),
        sa.Column(
            "product_id",
            sa.String(36),
            sa.ForeignKey("products.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column("metric_type", sa.String(64), nullable=False),
        sa.Column("value", sa.Float, nullable=False),
        sa.Column("unit", sa.String(64), nullable=True),
        sa.Column("notes", sa.Text, nullable=True),
        sa.Column("source", sa.String(128), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index("ix_metrics_product_id", "metrics", ["product_id"])
    op.create_index("ix_metrics_type_created", "metrics", ["metric_type", "created_at"])

    # ── actions ───────────────────────────────────────────────────────
    op.create_table(
        "actions",
        sa.Column("id", sa.String(36), primary_key=True, nullable=False),
        sa.Column(
            "product_id",
            sa.String(36),
            sa.ForeignKey("products.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column(
            "task_id",
            sa.String(36),
            sa.ForeignKey("tasks.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column("agent_type", sa.String(64), nullable=False),
        sa.Column("action_type", sa.String(128), nullable=False),
        sa.Column("payload", sa.Text, nullable=True),
        sa.Column("result", sa.Text, nullable=True),
        sa.Column("error_detail", sa.Text, nullable=True),
        sa.Column(
            "status",
            sa.Enum("success", "failure", "partial", name="actionstatus"),
            nullable=False,
            default="success",
        ),
        sa.Column("external_id", sa.String(256), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index("ix_actions_product_id", "actions", ["product_id"])
    op.create_index("ix_actions_agent_type", "actions", ["agent_type"])


def downgrade() -> None:
    op.drop_table("actions")
    op.drop_table("metrics")
    op.drop_table("tasks")
    op.drop_table("products")

    # Drop enums
    for enum in ("actionstatus", "taskstatus", "agenttype", "productstatus"):
        op.execute(f"DROP TYPE IF EXISTS {enum}")
