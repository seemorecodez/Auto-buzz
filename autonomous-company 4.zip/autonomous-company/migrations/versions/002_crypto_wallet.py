"""Add crypto_wallets table.

Revision ID: 002
Revises: 001
Create Date: 2026-04-09

Replaces Stripe payment records with self-custodied Ethereum HD wallet rows.
Each product gets one derived address (BIP-44 path m/44'/60'/0'/0/{index}).
Private keys are AES-256 encrypted at rest using SECRET_KEY.

Schema mirrors models/crypto_wallet.py exactly.
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

# revision identifiers
revision: str = "002"
down_revision: str = "001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "crypto_wallets",

        # ── Identity (String(36) matches products.id / UUIDMixin) ─────────────
        sa.Column("id", sa.String(36), primary_key=True, nullable=False),

        # ── Foreign key to products ────────────────────────────────────────────
        sa.Column(
            "product_id",
            sa.String(36),
            sa.ForeignKey("products.id", ondelete="CASCADE"),
            nullable=True,
            unique=True,
        ),

        # ── Wallet identity (plain VARCHAR avoids Postgres enum type issues) ───
        sa.Column(
            "network",
            sa.String(32),
            nullable=False,
            server_default="eth_mainnet",
        ),
        sa.Column("address", sa.String(64), nullable=False, unique=True),
        sa.Column("encrypted_private_key", sa.Text(), nullable=False),
        sa.Column("derivation_index", sa.Integer(), nullable=False, server_default="0"),

        # ── Balances (cached from chain) ───────────────────────────────────────
        sa.Column("eth_balance", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("usdc_balance", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("total_received_eth", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("total_received_usd", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("last_tx_hash", sa.String(128), nullable=True),

        # ── Payment links ──────────────────────────────────────────────────────
        sa.Column("price_eth", sa.Float(), nullable=True),
        sa.Column("price_usdc", sa.Float(), nullable=True),
        sa.Column("qr_code_path", sa.String(512), nullable=True),

        # ── Timestamps (from TimestampMixin) ───────────────────────────────────
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )

    # Indexes
    op.create_index("ix_crypto_wallets_address", "crypto_wallets", ["address"], unique=True)
    op.create_index("ix_crypto_wallets_product_id", "crypto_wallets", ["product_id"])


def downgrade() -> None:
    op.drop_index("ix_crypto_wallets_product_id", table_name="crypto_wallets")
    op.drop_index("ix_crypto_wallets_address", table_name="crypto_wallets")
    op.drop_table("crypto_wallets")
    sa.Enum(name="cryptonetwork").drop(op.get_bind(), checkfirst=True)
