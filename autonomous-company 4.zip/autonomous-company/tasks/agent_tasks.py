"""
Celery task implementations.

Each task wraps async agent calls using asyncio.run() since Celery workers
are synchronous by default.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from celery.utils.log import get_task_logger

from tasks.celery_app import celery_app

logger = get_task_logger(__name__)


def _run_async(coro):
    """Run an async coroutine in a new event loop (Celery worker context)."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


# ── Main agent task ───────────────────────────────────────────────────────────
@celery_app.task(
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    name="tasks.agent_tasks.execute_agent_task",
)
def execute_agent_task(
    self,
    agent_type: str,
    task_payload: dict[str, Any],
) -> dict[str, Any]:
    """
    Execute a single agent task.
    Retried automatically on transient failures.
    """
    from agents import AGENT_REGISTRY

    logger.info(f"execute_agent_task: agent={agent_type} task={task_payload.get('task_type')}")

    async def _run():
        agent_class = AGENT_REGISTRY.get(agent_type)
        if not agent_class:
            raise ValueError(f"Unknown agent: {agent_type}")
        agent = agent_class()
        result = await agent.run(task_payload)
        return result.to_dict()

    try:
        return _run_async(_run())
    except Exception as exc:
        logger.error(f"execute_agent_task failed: {exc}")
        raise self.retry(exc=exc)


# ── Execute DB-backed pending tasks ───────────────────────────────────────────
@celery_app.task(
    name="tasks.agent_tasks.execute_pending_db_tasks",
    max_retries=1,
)
def execute_pending_db_tasks(limit: int = 10) -> dict[str, Any]:
    """Pull pending tasks from the database and execute them."""

    async def _run():
        from execution.orchestrator import Orchestrator
        orch = Orchestrator()
        results = await orch.execute_pending_tasks(limit=limit)
        return {
            "executed": len(results),
            "succeeded": sum(1 for r in results if r.get("success")),
            "results": results,
        }

    return _run_async(_run())


# ── Main loop tick ────────────────────────────────────────────────────────────
@celery_app.task(
    name="tasks.agent_tasks.run_loop_tick",
    max_retries=1,
    time_limit=600,
)
def run_loop_tick() -> dict[str, Any]:
    """
    Execute one full loop iteration via Celery Beat.
    This is the primary scheduled driver of autonomous operation.
    """

    async def _run():
        from core.database import init_db
        from execution.loop import ExecutionLoop

        await init_db()
        loop = ExecutionLoop()
        return await loop.run_once()

    logger.info("run_loop_tick: starting")
    try:
        result = _run_async(_run())
        logger.info(f"run_loop_tick: done steps={len(result.get('steps', []))}")
        return result
    except Exception as exc:
        logger.error(f"run_loop_tick failed: {exc}")
        return {"error": str(exc), "success": False}


# ── Metric collection ─────────────────────────────────────────────────────────
@celery_app.task(
    name="tasks.agent_tasks.collect_all_metrics",
    max_retries=2,
)
def collect_all_metrics() -> dict[str, Any]:
    """Collect metrics for all active products."""

    async def _run():
        from core.database import init_db
        from execution.orchestrator import Orchestrator

        await init_db()
        orch = Orchestrator()
        products_result = await orch.run_task(
            {
                "agent_type": "meta",
                "task_type": "orchestrate",
                "instruction": "Return list of active product IDs",
            }
        )
        products = products_result.output.get("summary", {}).get("product_counts", {})

        collected: list[dict] = []
        from memory.structured_memory import StructuredMemory

        mem = StructuredMemory()
        active_products = await mem.get_active_products()

        for product in active_products:
            result = await orch.run_task(
                {
                    "agent_type": "data",
                    "task_type": "collect_metrics",
                    "instruction": f"Collect metrics for {product['name']}",
                    "product_id": product["id"],
                }
            )
            collected.append(
                {
                    "product_id": product["id"],
                    "success": result.success,
                }
            )

        return {"products_processed": len(collected), "results": collected}

    return _run_async(_run())


# ── On-demand agent task (for API use) ────────────────────────────────────────
@celery_app.task(
    name="tasks.agent_tasks.dispatch_agent_task",
    bind=True,
    max_retries=3,
    default_retry_delay=30,
)
def dispatch_agent_task(
    self,
    db_task_id: str,
) -> dict[str, Any]:
    """
    Pull a DB task by ID and execute it.
    Called when tasks are created via the API.
    """

    async def _run():
        from core.database import init_db
        from execution.orchestrator import Orchestrator
        from memory.structured_memory import StructuredMemory

        await init_db()
        mem = StructuredMemory()
        tasks = await mem.get_pending_tasks(limit=100)
        task_meta = next((t for t in tasks if t["id"] == db_task_id), None)

        if not task_meta:
            return {"error": f"Task {db_task_id} not found or not pending"}

        orch = Orchestrator()
        return await orch._execute_db_task(db_task_id, task_meta)

    try:
        return _run_async(_run())
    except Exception as exc:
        raise self.retry(exc=exc)
