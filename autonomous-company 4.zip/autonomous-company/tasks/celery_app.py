"""
Celery application configuration.

Broker:  Redis DB 1
Backend: Redis DB 2

Workers run with asyncio via celery[gevent] or a custom loop runner.
"""

from __future__ import annotations

from celery import Celery
from celery.schedules import crontab

from core.config import settings

celery_app = Celery(
    "acai",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["tasks.agent_tasks"],
)

# ── Configuration ─────────────────────────────────────────────────────────────
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_reject_on_worker_lost=True,
    task_soft_time_limit=300,   # 5 minutes soft limit
    task_time_limit=600,        # 10 minutes hard limit
    result_expires=86400,       # 24 hours
    worker_max_tasks_per_child=50,  # Restart worker every 50 tasks (memory safety)
    broker_connection_retry_on_startup=True,
)

# ── Beat schedule (periodic tasks) ───────────────────────────────────────────
celery_app.conf.beat_schedule = {
    # Main execution loop tick — every 5 minutes
    "loop-tick": {
        "task": "tasks.agent_tasks.run_loop_tick",
        "schedule": settings.LOOP_INTERVAL_SECONDS,
        "options": {"queue": "loop"},
    },
    # Operator health check — every 10 minutes
    "health-check": {
        "task": "tasks.agent_tasks.execute_agent_task",
        "schedule": 600,
        "kwargs": {
            "agent_type": "operator",
            "task_payload": {
                "task_type": "health_check",
                "instruction": "Perform system health check",
            },
        },
        "options": {"queue": "operator"},
    },
    # Collect metrics — every 15 minutes
    "collect-metrics": {
        "task": "tasks.agent_tasks.collect_all_metrics",
        "schedule": 900,
        "options": {"queue": "data"},
    },
    # System cleanup — every hour
    "cleanup": {
        "task": "tasks.agent_tasks.execute_agent_task",
        "schedule": 3600,
        "kwargs": {
            "agent_type": "operator",
            "task_payload": {
                "task_type": "cleanup_stale",
                "instruction": "Clean up stale tasks and old data",
            },
        },
        "options": {"queue": "operator"},
    },
}

# ── Queue routing ─────────────────────────────────────────────────────────────
celery_app.conf.task_routes = {
    "tasks.agent_tasks.execute_agent_task": {"queue": "agents"},
    "tasks.agent_tasks.run_loop_tick": {"queue": "loop"},
    "tasks.agent_tasks.collect_all_metrics": {"queue": "data"},
}
