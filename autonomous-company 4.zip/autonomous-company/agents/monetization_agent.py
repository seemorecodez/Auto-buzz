"""
MonetizationAgent — pricing strategy and cryptocurrency payment infrastructure.

Responsibilities:
  1. Design pricing tiers based on value analysis
  2. Generate a unique Ethereum wallet per product
  3. Set ETH + USDC prices based on live exchange rates
  4. Embed crypto payment widget into the landing page
  5. Monitor wallets for incoming payments
  6. Optimise conversion funnels
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

from agents.base import AgentResult, BaseAgent
from core.logger import get_logger
from models.product import ProductStatus
from tools.crypto_wallet import CryptoWalletTool
from tools.deployment import DeploymentTool

log = get_logger(__name__)


class MonetizationAgent(BaseAgent):
    """Handles pricing strategy and crypto payment setup."""

    name = "monetization"

    def __init__(self) -> None:
        super().__init__()
        self._crypto = CryptoWalletTool()
        self._deployer = DeploymentTool()

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "setup_payments")

        if task_type == "design_pricing":
            return await self._design_pricing(task)
        elif task_type == "setup_wallet":
            return await self._setup_wallet(task)
        elif task_type == "setup_payments" or task_type == "setup_pricing":
            return await self._setup_payments_full(task)
        elif task_type == "check_payments":
            return await self._check_payments(task)
        elif task_type == "optimise_funnel":
            return await self._optimise_funnel(task)
        elif task_type == "analyse_pricing":
            return await self._analyse_pricing(task)
        elif task_type == "create_checkout_page":
            return await self._create_checkout_page(task)
        elif task_type == "add_ltd_tier":
            return await self._add_ltd_tier(task)
        else:
            return await self._setup_payments_full(task)

    # ── Full setup (design + wallet) ──────────────────────────────────
    async def _setup_payments_full(self, task: dict[str, Any]) -> AgentResult:
        """Design pricing AND generate crypto wallet in one pass."""
        design_result = await self._design_pricing(task)
        if not design_result.success:
            return design_result

        wallet_result = await self._setup_wallet(
            {**task, "pricing": design_result.output}
        )

        combined_output = {**design_result.output}
        if wallet_result.success:
            combined_output["wallet"] = wallet_result.output

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="setup_payments",
            output=combined_output,
            actions_taken=design_result.actions_taken + wallet_result.actions_taken,
        )

    # ── Pricing Design ────────────────────────────────────────────────
    async def _design_pricing(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="design_pricing",
                error="Product not found",
            )

        memory_ctx = await self.recall(
            "pricing strategies and conversion rates", product_id=product_id
        )

        # Get live ETH price for reference
        eth_usd = await self._crypto._get_eth_usd_price()

        pricing: dict[str, Any] = await self.chat_json(
            system=(
                "You are a SaaS pricing expert specialising in crypto-native products. "
                "Design a 3-tier pricing model. "
                "Return JSON: {"
                "\"rationale\": \"...\", "
                "\"tiers\": ["
                "  {\"name\": \"Starter\", \"price_monthly_usd\": 0, "
                "   \"features\": [...], \"limits\": {...}}, "
                "  {\"name\": \"Pro\", \"price_monthly_usd\": 29, "
                "   \"features\": [...], \"limits\": {...}}, "
                "  {\"name\": \"Scale\", \"price_monthly_usd\": 99, "
                "   \"features\": [...], \"limits\": {...}}"
                "], "
                "\"recommended_tier\": \"Pro\", "
                "\"freemium\": true, "
                "\"trial_days\": 14, "
                "\"crypto_discount_percent\": 10"
                "}"
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Niche: {product['niche']}\n"
                f"Target audience: {product['target_audience']}\n"
                f"Value prop: {product['value_proposition']}\n"
                f"Current price hint: ${product.get('price_monthly', 29)}/mo\n"
                f"Current ETH price: ${eth_usd:,.0f}\n\n"
                f"Memory context:\n{memory_ctx}\n\n"
                "Design crypto-friendly pricing. Offer a 10% discount for "
                "paying with crypto vs. traditional payment. Include a free tier."
            ),
            temperature=0.4,
        )

        # Update product with recommended price
        tiers = pricing.get("tiers", [])
        pro_tier = next(
            (t for t in tiers if t.get("price_monthly_usd", 0) > 0), None
        )
        if pro_tier:
            price_usd = pro_tier.get("price_monthly_usd", 29)
            price_eth = round(price_usd / eth_usd, 6) if eth_usd > 0 else 0.0
            await self.structured_memory.update_product_field(
                product_id,
                price_monthly=price_usd,
                price_annual=price_usd * 10,
            )
            pricing["eth_usd_rate"] = eth_usd
            pricing["pro_price_eth"] = price_eth

        await self.record_action(
            action_type="design_pricing",
            payload={"product_id": product_id},
            result={"tiers": len(tiers), "eth_usd": eth_usd},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Designed crypto pricing for {product['name']}: "
            f"{[t['name'] + '=$' + str(t.get('price_monthly_usd', 0)) for t in tiers]}. "
            f"ETH rate: ${eth_usd:,.0f}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="design_pricing",
            output=pricing,
            actions_taken=["design_pricing_tiers", "fetch_eth_price"],
        )

    # ── Wallet Setup ──────────────────────────────────────────────────
    async def _setup_wallet(self, task: dict[str, Any]) -> AgentResult:
        """
        Generate a unique Ethereum wallet for this product.
        The wallet's address is displayed on the landing page for payments.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="setup_wallet",
                error="Product not found",
            )

        pricing = task.get("pricing", {})
        tiers = pricing.get("tiers", [])
        pro_tier = next(
            (t for t in tiers if t.get("price_monthly_usd", 0) > 0), None
        )
        price_monthly_usd = (
            pro_tier.get("price_monthly_usd", 29) if pro_tier
            else product.get("price_monthly", 29) or 29
        )

        try:
            wallet = await self._crypto.create_product_wallet(
                product_id=product_id,
                product_name=product["name"],
                price_monthly_usd=price_monthly_usd,
            )
        except Exception as exc:
            log.error("monetization_agent.wallet_error", error=str(exc))
            return AgentResult(
                success=False, agent=self.name, task_type="setup_wallet",
                error=str(exc),
            )

        await self.structured_memory.update_product_field(
            product_id, status=ProductStatus.MONETIZING
        )
        await self.record_action(
            action_type="create_crypto_wallet",
            payload={"product_id": product_id, "network": wallet["network"]},
            result={
                "address": wallet["address"],
                "price_eth": wallet["price_eth"],
                "price_usdc": wallet["price_usdc"],
            },
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Created ETH wallet for {product['name']}: {wallet['address']} "
            f"({wallet['network']}). "
            f"Price: ${price_monthly_usd}/mo = {wallet['price_eth']} ETH",
            product_id=product_id,
        )

        log.info(
            "monetization_agent.wallet_created",
            product=product["name"],
            address=wallet["address"],
            network=wallet["network"],
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="setup_wallet",
            output=wallet,
            actions_taken=["generate_eth_wallet", "generate_qr_code", "set_crypto_prices"],
        )

    # ── Check incoming payments ───────────────────────────────────────
    async def _check_payments(self, task: dict[str, Any]) -> AgentResult:
        """
        Check all product wallets for incoming payments and update revenue.
        """
        product_id = task.get("product_id")

        if product_id:
            wallet = await self._crypto.get_product_wallet(product_id)
            if not wallet:
                return AgentResult(
                    success=False, agent=self.name, task_type="check_payments",
                    error="No wallet found for product",
                )
            balance = await self._crypto.check_balance(wallet["address"])
            results = [balance]
        else:
            results = await self._crypto.check_all_product_wallets()

        # Update product revenue from wallet balances
        for result in results:
            if result.get("total_usd_value", 0) > 0:
                wallet_data = await self._crypto.get_product_wallet(product_id or "")
                if wallet_data:
                    total_usd = result["total_usd_value"]
                    await self.structured_memory.update_product_field(
                        product_id or "",
                        total_revenue=total_usd,
                        mrr=total_usd,
                    )

        await self.record_action(
            action_type="check_crypto_payments",
            payload={"product_id": product_id},
            result={"wallets_checked": len(results)},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="check_payments",
            output={"wallets": results, "count": len(results)},
            actions_taken=["check_eth_balance", "check_usdc_balance"],
        )

    # ── Funnel Optimisation ───────────────────────────────────────────
    async def _optimise_funnel(self, task: dict[str, Any]) -> AgentResult:
        from tools.analytics import AnalyticsTool
        analytics = AnalyticsTool()

        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        funnel = await analytics.compute_funnel(product_id) if product_id else {}

        wallet = await self._crypto.get_product_wallet(product_id) if product_id else {}

        optimisations: dict[str, Any] = await self.chat_json(
            system=(
                "You are a conversion rate optimisation expert for crypto-native SaaS. "
                "Analyse the funnel and wallet payment data. "
                "Return JSON: {\"tests\": [{\"element\": \"...\", \"hypothesis\": \"...\", "
                "\"expected_lift\": \"...%\"}], \"quick_wins\": [...], "
                "\"crypto_ux_suggestions\": [...]}"
            ),
            user=(
                f"Product: {product['name'] if product else 'unknown'}\n"
                f"Funnel data: {json.dumps(funnel, indent=2)}\n"
                f"Wallet (ETH balance): {wallet.get('eth_balance', 0) if wallet else 0}\n"
                f"Total received USD: {wallet.get('total_received_usd', 0) if wallet else 0}\n\n"
                "What are the top conversion improvements for a crypto payment flow?"
            ),
            temperature=0.5,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="optimise_funnel",
            output={"funnel": funnel, "wallet": wallet, "optimisations": optimisations},
            actions_taken=["analyse_funnel", "generate_optimisations"],
        )

    # ── Pricing Analysis ──────────────────────────────────────────────
    async def _analyse_pricing(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        eth_usd = await self._crypto._get_eth_usd_price()
        wallet = await self._crypto.get_product_wallet(product_id) if product_id else None

        analysis: dict[str, Any] = await self.chat_json(
            system=(
                "You are a pricing analyst for crypto-native SaaS companies. "
                "Return JSON: {\"current_assessment\": \"...\", "
                "\"recommended_changes\": [...], "
                "\"crypto_adoption_rate\": \"...\", "
                "\"optimal_eth_price\": ...}"
            ),
            user=(
                f"Product: {product['name'] if product else 'unknown'}\n"
                f"Current monthly price: ${product.get('price_monthly', 0) if product else 0}\n"
                f"ETH balance received: {wallet.get('eth_balance', 0) if wallet else 0} ETH\n"
                f"Total revenue USD: {wallet.get('total_received_usd', 0) if wallet else 0}\n"
                f"Current ETH/USD: ${eth_usd:,.0f}\n"
                f"Niche: {product.get('niche', '') if product else ''}"
            ),
            temperature=0.3,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="analyse_pricing",
            output={**analysis, "eth_usd_price": eth_usd},
            actions_taken=["pricing_analysis", "fetch_eth_price"],
        )

    # ── Checkout Page ─────────────────────────────────────────────────
    async def _create_checkout_page(self, task: dict[str, Any]) -> AgentResult:
        """
        Generate a complete HTML checkout page with 3 pricing tiers + LTD option,
        ETH wallet address, and deploy it to Vercel alongside the landing page.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="create_checkout_page",
                error="Product not found",
            )

        # Fetch live ETH/USD price
        eth_usd = await self._crypto._get_eth_usd_price()

        # Derive pricing tiers
        monthly_usd: float = float(product.get("price_monthly") or 29)
        annual_usd: float = round(monthly_usd * 10, 2)   # 2 months free
        ltd_usd: float = round(monthly_usd * 20, 2)      # 20x monthly = LTD

        monthly_eth = round(monthly_usd / eth_usd, 6) if eth_usd else 0.0
        annual_eth  = round(annual_usd  / eth_usd, 6) if eth_usd else 0.0
        ltd_eth     = round(ltd_usd     / eth_usd, 6) if eth_usd else 0.0

        # Get or create product wallet (check structured_memory first)
        wallet_data: Optional[dict[str, Any]] = await self.structured_memory.get(
            f"wallet:{product_id}"
        ) if hasattr(self.structured_memory, "get") else None

        if not wallet_data:
            wallet_data = await self._crypto.get_product_wallet(product_id)

        if not wallet_data:
            wallet_data = await self._crypto.create_product_wallet(
                product_id=product_id,
                product_name=product["name"],
                price_monthly_usd=monthly_usd,
            )

        eth_address = wallet_data.get("address", "")

        # Generate checkout HTML via LLM
        slug = product.get("slug", product_id)
        checkout_html: dict[str, Any] = await self.chat_json(
            system=(
                "You are a world-class SaaS landing page designer and copywriter. "
                "Generate a complete, beautiful, production-ready HTML checkout page "
                "(pure HTML + inline CSS + vanilla JS, no external frameworks). "
                "Return JSON with a single key 'html' containing the full page string."
            ),
            user=(
                f"Product name: {product['name']}\n"
                f"Description: {product.get('description', '')}\n"
                f"Value proposition: {product.get('value_proposition', '')}\n"
                f"\nPricing tiers:\n"
                f"  - Starter (Free): core features, limited usage\n"
                f"  - Pro (Monthly): ${monthly_usd}/mo = {monthly_eth} ETH — full access\n"
                f"  - Scale (Annual): ${annual_usd}/yr = {annual_eth} ETH — 2 months free\n"
                f"  - Lifetime Deal (LTD): ${ltd_usd} one-time = {ltd_eth} ETH — all future features\n"
                f"\nETH wallet address: {eth_address}\n"
                f"Current ETH/USD price: ${eth_usd:,.0f}\n"
                f"\nRequirements:\n"
                "- Hero section with product name and tagline\n"
                "- 4 pricing cards (Starter free, Pro monthly, Scale annual, LTD)\n"
                "- LTD shown prominently with 'Best Value' badge\n"
                "- ETH wallet address displayed with copy-to-clipboard button\n"
                "- Text-based QR placeholder (show address in monospace)\n"
                "- Payment instructions section: 'Send exact ETH amount → click confirm'\n"
                "- 'I've sent payment' button calling /api/confirm-payment via fetch POST\n"
                "  with JSON body {email, tier, tx_hash}\n"
                "- Live ETH price badge (populated from page load)\n"
                "- Mobile-responsive, dark-mode friendly\n"
                "- Professional color scheme (dark navy + electric blue accents)\n"
                "- Trust signals: 'Secure crypto payment', 'Instant access', '30-day guarantee'"
            ),
            temperature=0.5,
            max_tokens=8000,
        )

        html_content: str = checkout_html.get("html", "")
        if not html_content:
            # Fallback: build a minimal checkout page
            html_content = self._build_fallback_checkout(
                product=product,
                monthly_usd=monthly_usd, monthly_eth=monthly_eth,
                annual_usd=annual_usd,  annual_eth=annual_eth,
                ltd_usd=ltd_usd,        ltd_eth=ltd_eth,
                eth_address=eth_address,
                eth_usd=eth_usd,
            )

        # Save HTML to disk
        page_dir = Path(f"/tmp/acai_pages/{slug}")
        page_dir.mkdir(parents=True, exist_ok=True)
        checkout_path = page_dir / "checkout.html"
        checkout_path.write_text(html_content, encoding="utf-8")

        # Deploy to Vercel (project name mirrors landing page project)
        project_name = f"acai-{slug}-checkout"
        deploy_result = await self._deployer.deploy(
            source_dir=str(page_dir),
            project_name=project_name,
        )

        checkout_url = deploy_result.url or f"/tmp/acai_pages/{slug}/checkout.html"

        await self.record_action(
            action_type="create_checkout_page",
            payload={"product_id": product_id, "slug": slug},
            result={
                "checkout_url": checkout_url,
                "eth_address": eth_address,
                "monthly_usd": monthly_usd,
                "ltd_usd": ltd_usd,
                "eth_usd": eth_usd,
            },
            product_id=product_id,
            success=deploy_result.success,
        )
        await self.remember(
            f"Created checkout page for {product['name']} at {checkout_url}. "
            f"ETH wallet: {eth_address}. "
            f"LTD: ${ltd_usd} = {ltd_eth} ETH.",
            product_id=product_id,
        )

        log.info(
            "monetization_agent.checkout_created",
            product=product["name"],
            url=checkout_url,
            eth_address=eth_address,
        )

        return AgentResult(
            success=deploy_result.success,
            agent=self.name,
            task_type="create_checkout_page",
            output={
                "checkout_url": checkout_url,
                "checkout_html_path": str(checkout_path),
                "eth_address": eth_address,
                "eth_usd": eth_usd,
                "tiers": {
                    "starter": {"price_usd": 0, "price_eth": 0},
                    "pro_monthly": {"price_usd": monthly_usd, "price_eth": monthly_eth},
                    "scale_annual": {"price_usd": annual_usd, "price_eth": annual_eth},
                    "ltd": {"price_usd": ltd_usd, "price_eth": ltd_eth},
                },
                "deploy_id": deploy_result.deploy_id,
            },
            error=deploy_result.error,
            actions_taken=[
                "fetch_eth_price",
                "get_or_create_wallet",
                "generate_checkout_html",
                "deploy_checkout_page",
            ],
        )

    def _build_fallback_checkout(
        self,
        product: dict[str, Any],
        monthly_usd: float,
        monthly_eth: float,
        annual_usd: float,
        annual_eth: float,
        ltd_usd: float,
        ltd_eth: float,
        eth_address: str,
        eth_usd: float,
    ) -> str:
        """Minimal but functional fallback checkout page."""
        name = product.get("name", "Product")
        desc = product.get("description", "")
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{name} — Checkout</title>
  <style>
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
          background:#0f172a;color:#f1f5f9;min-height:100vh;padding:40px 20px}}
    .container{{max-width:1000px;margin:0 auto}}
    h1{{font-size:2.5rem;font-weight:800;margin-bottom:.5rem;color:#f8fafc}}
    .subtitle{{color:#94a3b8;font-size:1.1rem;margin-bottom:3rem}}
    .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;margin-bottom:3rem}}
    .card{{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:28px;position:relative}}
    .card.featured{{border-color:#3b82f6;box-shadow:0 0 0 2px #3b82f6}}
    .badge{{position:absolute;top:-12px;left:50%;transform:translateX(-50%);
             background:#3b82f6;color:#fff;font-size:.75rem;font-weight:700;
             padding:4px 12px;border-radius:999px}}
    .tier-name{{font-size:1.2rem;font-weight:700;margin-bottom:.5rem}}
    .price{{font-size:2rem;font-weight:800;color:#3b82f6;margin:.75rem 0 .25rem}}
    .eth-price{{color:#94a3b8;font-size:.85rem;margin-bottom:1rem}}
    .cta-btn{{width:100%;padding:12px;border-radius:8px;border:none;cursor:pointer;
               font-size:1rem;font-weight:600;transition:.2s}}
    .cta-btn.primary{{background:#3b82f6;color:#fff}}
    .cta-btn.secondary{{background:#1e293b;color:#94a3b8;border:1px solid #334155}}
    .wallet-section{{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:28px;margin-bottom:2rem}}
    .wallet-address{{font-family:monospace;font-size:.85rem;word-break:break-all;
                      background:#0f172a;padding:12px;border-radius:8px;margin:12px 0;color:#7dd3fc}}
    .confirm-btn{{background:#10b981;color:#fff;border:none;padding:14px 32px;
                   border-radius:8px;font-size:1rem;font-weight:600;cursor:pointer;margin-top:16px}}
    .trust{{display:flex;gap:24px;justify-content:center;flex-wrap:wrap;color:#64748b;font-size:.875rem;margin-top:2rem}}
    .eth-live{{display:inline-block;background:#1e293b;border:1px solid #334155;
                border-radius:999px;padding:4px 14px;font-size:.85rem;margin-bottom:2rem}}
  </style>
</head>
<body>
  <div class="container">
    <h1>{name}</h1>
    <p class="subtitle">{desc}</p>
    <div class="eth-live">ETH price: <strong id="eth-price">${eth_usd:,.0f}</strong></div>
    <div class="grid">
      <div class="card">
        <div class="tier-name">Starter</div>
        <div class="price">Free</div>
        <div class="eth-price">No credit card required</div>
        <button class="cta-btn secondary">Get Started Free</button>
      </div>
      <div class="card">
        <div class="tier-name">Pro Monthly</div>
        <div class="price">${monthly_usd}<span style="font-size:1rem;color:#94a3b8">/mo</span></div>
        <div class="eth-price">{monthly_eth} ETH/month</div>
        <button class="cta-btn primary" onclick="selectTier('pro_monthly',{monthly_eth})">Choose Pro</button>
      </div>
      <div class="card">
        <div class="tier-name">Scale Annual</div>
        <div class="price">${annual_usd}<span style="font-size:1rem;color:#94a3b8">/yr</span></div>
        <div class="eth-price">{annual_eth} ETH total · 2 months free</div>
        <button class="cta-btn primary" onclick="selectTier('scale_annual',{annual_eth})">Choose Scale</button>
      </div>
      <div class="card featured">
        <div class="badge">BEST VALUE</div>
        <div class="tier-name">Lifetime Deal</div>
        <div class="price">${ltd_usd}<span style="font-size:1rem;color:#94a3b8"> once</span></div>
        <div class="eth-price">{ltd_eth} ETH · all future features included</div>
        <button class="cta-btn primary" onclick="selectTier('ltd',{ltd_eth})">Get Lifetime Access</button>
      </div>
    </div>
    <div class="wallet-section" id="payment-section" style="display:none">
      <h2 style="margin-bottom:.5rem">Pay with ETH</h2>
      <p style="color:#94a3b8;margin-bottom:1rem">Send exactly <strong id="pay-amount"></strong> ETH to this address:</p>
      <div class="wallet-address" id="wallet-addr">{eth_address}</div>
      <button onclick="navigator.clipboard.writeText('{eth_address}')"
              style="background:#334155;border:none;color:#94a3b8;padding:8px 16px;border-radius:6px;cursor:pointer">
        Copy Address
      </button>
      <br>
      <button class="confirm-btn" onclick="confirmPayment()">
        I've Sent Payment ✓
      </button>
    </div>
    <div class="trust">
      <span>🔒 Secure crypto payment</span>
      <span>⚡ Instant access</span>
      <span>💰 30-day money-back guarantee</span>
    </div>
  </div>
  <script>
    var selectedTier = null;
    var selectedEth = 0;
    function selectTier(tier, eth) {{
      selectedTier = tier; selectedEth = eth;
      document.getElementById('pay-amount').textContent = eth;
      document.getElementById('payment-section').style.display = 'block';
      document.getElementById('payment-section').scrollIntoView({{behavior:'smooth'}});
    }}
    function confirmPayment() {{
      var email = prompt('Enter your email address to receive access:');
      var txHash = prompt('Enter your transaction hash (optional):');
      if (!email) return;
      fetch('/api/confirm-payment', {{
        method: 'POST',
        headers: {{'Content-Type':'application/json'}},
        body: JSON.stringify({{email: email, tier: selectedTier, tx_hash: txHash, eth_amount: selectedEth}})
      }}).then(r => r.json()).then(d => {{
        alert(d.message || 'Payment received! Check your email for access details.');
      }}).catch(() => {{
        alert('Payment noted. We will verify and send access within 1 hour.');
      }});
    }}
  </script>
</body>
</html>"""

    # ── LTD Tier ──────────────────────────────────────────────────────
    async def _add_ltd_tier(self, task: dict[str, Any]) -> AgentResult:
        """
        Calculate LTD price, update product record, and generate urgency copy.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="add_ltd_tier",
                error="Product not found",
            )

        # Calculate prices
        eth_usd = await self._crypto._get_eth_usd_price()
        monthly_usd: float = float(product.get("price_monthly") or 29)
        ltd_usd: float = round(monthly_usd * 20, 2)
        ltd_eth: float = round(ltd_usd / eth_usd, 6) if eth_usd else 0.0

        # Update product record with LTD price
        await self.structured_memory.update_product_field(
            product_id,
            ltd_price_usd=ltd_usd,
        )

        # Generate urgency copy
        urgency_copy: dict[str, Any] = await self.chat_json(
            system=(
                "You are a direct-response copywriter specialising in SaaS lifetime deals. "
                "Write compelling urgency copy for a limited-time LTD offer. "
                "Return JSON: {"
                '"headline": "...", '
                '"subheadline": "...", '
                '"body": "...", '
                '"cta_text": "...", '
                '"scarcity_note": "..."'
                "}"
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Description: {product.get('description', '')}\n"
                f"Value proposition: {product.get('value_proposition', '')}\n"
                f"Monthly price: ${monthly_usd}/mo\n"
                f"LTD price: ${ltd_usd} one-time (= {ltd_eth} ETH)\n"
                f"ETH/USD: ${eth_usd:,.0f}\n\n"
                "Write high-urgency copy for the LTD offer. "
                "Emphasise: lifetime access, all future updates included, limited spots, "
                "early-adopter pricing. Make it feel like missing out would be a mistake."
            ),
            temperature=0.7,
        )

        await self.record_action(
            action_type="add_ltd_tier",
            payload={"product_id": product_id},
            result={"ltd_usd": ltd_usd, "ltd_eth": ltd_eth, "eth_usd": eth_usd},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Added LTD tier for {product['name']}: ${ltd_usd} one-time = {ltd_eth} ETH. "
            f"Headline: {urgency_copy.get('headline', '')}",
            product_id=product_id,
        )

        log.info(
            "monetization_agent.ltd_added",
            product=product["name"],
            ltd_usd=ltd_usd,
            ltd_eth=ltd_eth,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="add_ltd_tier",
            output={
                "ltd_price_usd": ltd_usd,
                "ltd_price_eth": ltd_eth,
                "monthly_price_usd": monthly_usd,
                "eth_usd_rate": eth_usd,
                "urgency_copy": urgency_copy,
            },
            actions_taken=["calculate_ltd_price", "update_product", "generate_urgency_copy"],
        )
