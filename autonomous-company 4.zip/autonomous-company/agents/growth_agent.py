"""
GrowthAgent — lead generation and Kit email outreach.

Uses Kit (ConvertKit) API for all email — no SMTP required.
Leads are added as Kit subscribers, then a broadcast is sent to their tag.
"""

from __future__ import annotations

import json
import os
from typing import Any

import httpx

from agents.base import AgentResult, BaseAgent
from core.config import settings
from core.logger import get_logger
from models.metric import MetricType
from tools.affiliate import AffiliateTool
from tools.deployment import DeploymentTool
from tools.drip_sequence import DripSequenceTool
from tools.kit_email import KitBroadcast, KitEmailTool, KitSubscriber
from tools.outreach import OutreachTool  # still used for lead generation

log = get_logger(__name__)


class GrowthAgent(BaseAgent):
    """Drives lead generation and Kit email campaigns."""

    name = "growth"

    def __init__(self) -> None:
        super().__init__()
        self._kit = KitEmailTool()
        self._leads_tool = OutreachTool()  # Only used for lead finding
        self._drip = DripSequenceTool()
        self._affiliate = AffiliateTool()
        self._deployer = DeploymentTool()

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "run_outreach")

        if task_type == "generate_leads":
            return await self._generate_leads(task)
        elif task_type == "run_outreach":
            return await self._run_outreach(task)
        elif task_type == "send_broadcast":
            return await self._send_broadcast(task)
        elif task_type == "analyse_growth":
            return await self._analyse_growth(task)
        elif task_type == "kit_stats":
            return await self._kit_stats(task)
        elif task_type == "send_drip_sequence":
            return await self._send_drip_sequence(task)
        elif task_type == "multi_touch_outreach":
            return await self._multi_touch_outreach(task)
        elif task_type == "score_leads":
            return await self._score_leads(task)
        elif task_type == "cross_sell":
            return await self._cross_sell(task)
        elif task_type == "launch_affiliate_program":
            return await self._launch_affiliate_program(task)
        else:
            return await self._run_outreach(task)

    # ── Lead Generation ───────────────────────────────────────────────
    async def _generate_leads(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="generate_leads",
                error="Product not found",
            )

        memory_ctx = await self.recall(
            "outreach leads and campaigns sent", product_id=product_id
        )
        target_role = await self._infer_target_role(product, memory_ctx)

        leads = await self._leads_tool.find_leads(
            niche=product["niche"],
            target_role=target_role,
            limit=task.get("limit", 20),
        )

        await self.structured_memory.record_metric(
            metric_type=MetricType.LEADS_GENERATED,
            value=len(leads),
            product_id=product_id,
            source="growth_agent",
        )
        await self.record_action(
            action_type="generate_leads",
            payload={"niche": product["niche"], "role": target_role},
            result={"leads_count": len(leads)},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated {len(leads)} leads for {product['name']} targeting {target_role}s.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_leads",
            output={
                "product_id": product_id,
                "leads_count": len(leads),
                "leads": [
                    {
                        "email": l.email,
                        "first_name": l.first_name,
                        "last_name": l.last_name,
                        "company": l.company,
                        "title": l.title,
                        "source": l.source,
                    }
                    for l in leads
                ],
            },
            actions_taken=["lead_discovery"],
        )

    # ── Full Kit Campaign ─────────────────────────────────────────────
    async def _run_outreach(self, task: dict[str, Any]) -> AgentResult:
        """
        Full Kit campaign cycle:
        1. Find leads
        2. Add to Kit as tagged subscribers
        3. Send broadcast to that tag
        4. Record stats
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="run_outreach",
                error="Product not found",
            )

        # Step 1: Find leads
        leads_result = await self._generate_leads(
            {**task, "limit": task.get("limit", 15)}
        )
        if not leads_result.success:
            return leads_result

        leads_data = leads_result.output.get("leads", [])

        # Step 2 + 3: Add to Kit and send broadcast
        cta_url = (
            product.get("landing_page_url")
            or product.get("deploy_url")
            or "https://example.com/signup"
        )

        campaign_result = await self._kit.run_launch_campaign(
            product_name=product["name"],
            product_description=product["description"] or "",
            value_proposition=product["value_proposition"] or "",
            target_audience=product["target_audience"] or "",
            cta_url=cta_url,
            leads=leads_data,
            product_tag=f"acai-{product['slug']}",
        )

        # Step 4: Record metrics
        await self.structured_memory.record_metric(
            metric_type=MetricType.EMAILS_SENT,
            value=campaign_result.get("subscribers_added", 0),
            product_id=product_id,
            source="kit_email",
        )
        await self.record_action(
            action_type="run_kit_campaign",
            payload={"lead_count": len(leads_data)},
            result=campaign_result,
            product_id=product_id,
            success=campaign_result.get("broadcast_sent", False),
        )
        await self.remember(
            f"Ran Kit outreach for {product['name']}: "
            f"added={campaign_result.get('subscribers_added', 0)} subscribers, "
            f"broadcast={campaign_result.get('broadcast_subject', '')}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="run_outreach",
            output={
                "product_id": product_id,
                "leads_found": len(leads_data),
                **campaign_result,
            },
            actions_taken=["generate_leads", "add_kit_subscribers", "send_broadcast"],
        )

    # ── Manual Broadcast ──────────────────────────────────────────────
    async def _send_broadcast(self, task: dict[str, Any]) -> AgentResult:
        """
        Generate and send a one-off broadcast email (update, feature, offer).
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        email_type = task.get("email_type", "update")

        cta_url = (
            product.get("deploy_url") if product else None
        ) or "https://example.com"

        broadcast = await self._kit.generate_broadcast(
            product_name=product["name"] if product else "Product Update",
            product_description=product["description"] or "" if product else "",
            value_proposition=product["value_proposition"] or "" if product else "",
            target_audience=product["target_audience"] or "" if product else "",
            cta_url=cta_url,
            email_type=email_type,
        )

        # Get tag for this product
        tags = await self._kit.list_tags()
        product_slug = product["slug"] if product else ""
        tag_obj = next(
            (t for t in tags if f"acai-{product_slug}" in t.get("name", "")), None
        )
        tag_id = tag_obj["id"] if tag_obj else None

        send_result = await self._kit.send_broadcast(broadcast, tag_id=tag_id)

        await self.record_action(
            action_type="send_broadcast",
            payload={"product_id": product_id, "email_type": email_type},
            result={"subject": broadcast.subject, **send_result},
            product_id=product_id,
            success=send_result.get("success", False),
        )

        return AgentResult(
            success=send_result.get("success", False),
            agent=self.name,
            task_type="send_broadcast",
            output={
                "subject": broadcast.subject,
                "broadcast_id": send_result.get("broadcast_id"),
                "tag_id": tag_id,
            },
            error=send_result.get("error"),
            actions_taken=["generate_email_copy", "send_kit_broadcast"],
        )

    # ── Kit Stats ─────────────────────────────────────────────────────
    async def _kit_stats(self, task: dict[str, Any]) -> AgentResult:
        """Return Kit account stats: subscriber count, forms, tags."""
        subscriber_count = await self._kit.get_subscriber_count()
        forms = await self._kit.list_forms()
        tags = await self._kit.list_tags()

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="kit_stats",
            output={
                "total_subscribers": subscriber_count,
                "forms": forms,
                "tags": tags,
            },
            actions_taken=["fetch_kit_stats"],
        )

    # ── Growth Analysis ───────────────────────────────────────────────
    async def _analyse_growth(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)

        emails_sent = await self.structured_memory.get_latest_metric(
            MetricType.EMAILS_SENT, product_id=product_id
        )
        leads = await self.structured_memory.get_latest_metric(
            MetricType.LEADS_GENERATED, product_id=product_id
        )
        subscriber_count = await self._kit.get_subscriber_count()

        analysis = await self.chat_json(
            system=(
                "You are a growth analyst. Analyse the outreach data and recommend "
                "3 specific improvements. "
                "Return JSON: {\"recommendations\": [...], \"next_focus\": \"...\"}"
            ),
            user=(
                f"Product: {product['name'] if product else 'unknown'}\n"
                f"Emails sent: {emails_sent or 0}\n"
                f"Leads generated: {leads or 0}\n"
                f"Total Kit subscribers: {subscriber_count}\n"
                f"Niche: {product['niche'] if product else 'unknown'}"
            ),
            temperature=0.4,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="analyse_growth",
            output={**analysis, "kit_subscribers": subscriber_count},
            actions_taken=["growth_analysis"],
        )

    # ── Cross-Sell ────────────────────────────────────────────────────
    async def _cross_sell(self, task: dict[str, Any]) -> AgentResult:
        """
        Send a cross-sell email from product_A subscribers introducing product_B.
        task["instruction"] should contain the target product slug.
        """
        product_id = task.get("product_id")
        instruction = task.get("instruction", "")
        product_a = await self.structured_memory.get_product_by_id(product_id)
        if not product_a:
            return AgentResult(
                success=False, agent=self.name, task_type="cross_sell",
                error="Source product not found",
            )

        # Extract target product slug from instruction
        portfolio_slugs = ("contractcraft", "hireflow", "supportsage", "pitchforge", "auditmind")
        target_slug = ""
        for word in instruction.lower().split():
            if word in portfolio_slugs and word != product_a["slug"]:
                target_slug = word
                break

        product_b = (
            await self.structured_memory.get_product_by_slug(target_slug)
            if target_slug else None
        )

        product_b_name = product_b["name"] if product_b else (target_slug or "our other product")
        product_b_url = (
            (product_b.get("deploy_url") if product_b else None)
            or f"https://{target_slug}.vercel.app"
        )
        product_b_desc = product_b.get("description", "") if product_b else ""

        # Generate cross-sell email copy via LLM
        email_data = await self.chat_json(
            system=(
                "You are an email copywriter specialising in cross-selling SaaS products. "
                "Write a short, friendly cross-sell email. "
                'Return JSON: {"subject": "...", "content_html": "...", "content_text": "..."}'
            ),
            user=(
                f"Source product (user already uses): {product_a['name']}\n"
                f"Target product to introduce: {product_b_name}\n"
                f"Target product description: {product_b_desc}\n"
                f"Target product URL: {product_b_url}\n\n"
                f"Write an email: 'You're using {product_a['name']} — here's how "
                f"{product_b_name} can help you [benefit]'. "
                f"Short (3 paragraphs), benefit-focused, CTA button to {product_b_url}."
            ),
            temperature=0.7,
        )

        broadcast = KitBroadcast(
            subject=email_data.get(
                "subject",
                f"{product_b_name} — a perfect companion to {product_a['name']}",
            ),
            content_html=email_data.get("content_html", ""),
            content_text=email_data.get("content_text", ""),
            description=f"Cross-sell {product_a['name']} → {product_b_name}",
        )

        # Send to product_A subscribers
        tags = await self._kit.list_tags()
        slug_a = product_a["slug"]
        tag_obj = next(
            (t for t in tags if f"acai-{slug_a}" in t.get("name", "")), None
        )
        tag_id = tag_obj["id"] if tag_obj else None

        send_result = await self._kit.send_broadcast(broadcast, tag_id=tag_id)
        emails_sent = 1 if send_result.get("success") else 0

        await self.record_action(
            action_type="cross_sell",
            payload={
                "source_product": slug_a,
                "target_product": target_slug,
                "subject": broadcast.subject,
            },
            result={"broadcast_id": send_result.get("broadcast_id"), "emails_sent": emails_sent},
            product_id=product_id,
            success=send_result.get("success", False),
        )
        await self.remember(
            f"Cross-sold {product_a['name']} → {product_b_name}: subject='{broadcast.subject}'",
            product_id=product_id,
        )

        return AgentResult(
            success=send_result.get("success", False),
            agent=self.name,
            task_type="cross_sell",
            output={
                "source_product": product_a["name"],
                "target_product": product_b_name,
                "subject": broadcast.subject,
                "emails_sent": emails_sent,
                "broadcast_id": send_result.get("broadcast_id"),
            },
            error=send_result.get("error"),
            actions_taken=["generate_cross_sell_email", "send_kit_broadcast"],
        )

    # ── Affiliate Program Launch ──────────────────────────────────────
    async def _launch_affiliate_program(self, task: dict[str, Any]) -> AgentResult:
        """
        Launch the affiliate program for a product:
        1. Generate affiliate portal HTML
        2. Deploy to Vercel
        3. Send Kit broadcast to product subscribers announcing the program
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="launch_affiliate_program",
                error="Product not found",
            )

        slug = product["slug"]
        name = product["name"]
        deploy_url = product.get("deploy_url") or f"https://{slug}.vercel.app"

        # Step 1: Generate affiliate portal HTML
        portal_html = await self._affiliate.generate_affiliate_portal_html(
            product_slug=slug,
            product_name=name,
            deploy_url=deploy_url,
        )

        # Step 2: Save and deploy
        portal_dir = f"/tmp/acai_pages/{slug}"
        os.makedirs(portal_dir, exist_ok=True)
        portal_path = f"{portal_dir}/affiliates.html"
        with open(portal_path, "w", encoding="utf-8") as fh:
            fh.write(portal_html)

        # Minimal index.html for the deploy dir
        index_path = f"{portal_dir}/index.html"
        if not os.path.exists(index_path):
            with open(index_path, "w", encoding="utf-8") as fh:
                fh.write(
                    '<!DOCTYPE html><html><head>'
                    '<meta http-equiv="refresh" content="0;url=affiliates.html">'
                    '</head><body></body></html>'
                )

        deploy_result = await self._deployer.deploy(
            source_dir=portal_dir,
            project_name=f"{slug}-affiliates",
        )
        portal_url = deploy_result.url or f"{deploy_url}/affiliates"

        # Step 3: Announcement broadcast to product subscribers
        tags = await self._kit.list_tags()
        tag_obj = next(
            (t for t in tags if f"acai-{slug}" in t.get("name", "")), None
        )
        tag_id = tag_obj["id"] if tag_obj else None

        announcement = KitBroadcast(
            subject=f"Earn 30% commission promoting {name}",
            content_html=(
                f"<p>Hi {{{{ subscriber.first_name | default: 'there' }}}},</p>"
                f"<p>We just launched the <strong>{name} Affiliate Program</strong> — "
                f"and you're one of the first to hear about it.</p>"
                f"<p>As a {name} user, you know firsthand how valuable it is. "
                f"Now you can earn <strong>30% recurring commission</strong> for every "
                f"customer you refer — for the lifetime of their subscription.</p>"
                f"<p><a href='{portal_url}' style='display:inline-block;background:#00ff88;"
                f"color:#000;padding:14px 28px;border-radius:8px;font-weight:700;"
                f"text-decoration:none;'>Get Your Affiliate Link &rarr;</a></p>"
                f"<p style='color:#888;font-size:13px;'>Questions? Just reply to this email.</p>"
            ),
            content_text=(
                f"Hi there,\n\nWe just launched the {name} Affiliate Program!\n\n"
                f"Earn 30% recurring commission on every customer you refer.\n\n"
                f"Get your affiliate link: {portal_url}\n"
            ),
            description=f"Affiliate program launch for {name}",
        )

        send_result = await self._kit.send_broadcast(announcement, tag_id=tag_id)

        await self.record_action(
            action_type="launch_affiliate_program",
            payload={"product_id": product_id, "slug": slug},
            result={
                "portal_url": portal_url,
                "deploy_success": deploy_result.success,
                "broadcast_sent": send_result.get("success", False),
            },
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Launched affiliate program for {name}. Portal: {portal_url}. "
            f"30% recurring commission announced to subscribers.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="launch_affiliate_program",
            output={
                "product": name,
                "portal_url": portal_url,
                "deploy_success": deploy_result.success,
                "broadcast_sent": send_result.get("success", False),
                "broadcast_id": send_result.get("broadcast_id"),
            },
            actions_taken=[
                "generate_affiliate_portal",
                "deploy_portal",
                "send_announcement_broadcast",
            ],
        )

    # ── Helper ────────────────────────────────────────────────────────
    async def _infer_target_role(
        self, product: dict[str, Any], context: str
    ) -> str:
        result = await self.chat_json(
            system=(
                "Infer the best job title to target for B2B SaaS outreach. "
                'Return JSON: {"role": "..."}'
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Target audience: {product['target_audience']}\n"
                f"Niche: {product['niche']}"
            ),
            temperature=0.3,
        )
        return result.get("role", "founder")

    # ── Drip Sequence ──────────────────────────────────────────────────
    async def _send_drip_sequence(self, task: dict[str, Any]) -> AgentResult:
        """
        Enrol leads (from DB or freshly generated) into a 7-email drip sequence.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="send_drip_sequence",
                error="Product not found",
            )

        # Get leads from task payload, or generate fresh
        leads_data: list[dict[str, Any]] = task.get("leads", [])
        if not leads_data:
            leads_result = await self._generate_leads(
                {**task, "limit": task.get("limit", 20)}
            )
            if not leads_result.success:
                return leads_result
            leads_data = leads_result.output.get("leads", [])

        tag_name = f"drip-{product.get('slug', product_id)}"
        cta_url = (
            product.get("landing_page_url")
            or product.get("deploy_url")
            or "https://example.com/signup"
        )

        enrolled_count = 0
        errors: list[str] = []

        for lead in leads_data:
            email = lead.get("email", "")
            if not email:
                continue
            try:
                result = await self._drip.enroll_subscriber(
                    email=email,
                    first_name=lead.get("first_name", ""),
                    product_name=product["name"],
                    product_description=product.get("description", ""),
                    value_prop=product.get("value_proposition", ""),
                    cta_url=cta_url,
                    tag_name=tag_name,
                    niche=product.get("niche", ""),
                )
                if result.get("success"):
                    enrolled_count += 1
                else:
                    errors.append(f"{email}: enrolment failed")
            except Exception as exc:
                log.warning("growth_agent.drip_enroll_failed", email=email, error=str(exc))
                errors.append(f"{email}: {exc}")

        # Record metrics
        await self.structured_memory.record_metric(
            metric_type=MetricType.EMAILS_SENT,
            value=enrolled_count,
            product_id=product_id,
            source="drip_sequence",
        )
        await self.record_action(
            action_type="enroll_drip_sequence",
            payload={"product_id": product_id, "tag": tag_name},
            result={"enrolled": enrolled_count, "errors": len(errors)},
            product_id=product_id,
            success=enrolled_count > 0,
        )
        await self.remember(
            f"Enrolled {enrolled_count} leads into drip sequence for {product['name']}. "
            f"Tag: {tag_name}. Errors: {len(errors)}.",
            product_id=product_id,
        )

        return AgentResult(
            success=enrolled_count > 0,
            agent=self.name,
            task_type="send_drip_sequence",
            output={
                "enrolled_count": enrolled_count,
                "tag_name": tag_name,
                "errors": errors,
            },
            actions_taken=["generate_leads", "enroll_drip_sequence"],
        )

    # ── Multi-touch Outreach ───────────────────────────────────────────
    async def _multi_touch_outreach(self, task: dict[str, Any]) -> AgentResult:
        """
        3-touch outreach sequence:
          Touch 1 (immediate): value-focused intro, no pitch, subscribed to product tag
          Touch 2 (Day 4):     case study / social proof
          Touch 3 (Day 8):     direct offer with 20% discount code SAVE20

        Uses DripSequenceTool for touches 2 & 3 via 3-step Redis schedule.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="multi_touch_outreach",
                error="Product not found",
            )

        # Find 10-15 fresh leads
        leads_result = await self._generate_leads(
            {**task, "limit": task.get("limit", 12)}
        )
        if not leads_result.success:
            return leads_result
        leads_data: list[dict[str, Any]] = leads_result.output.get("leads", [])

        product_tag = f"mto-{product.get('slug', product_id)}"
        cta_url = (
            product.get("landing_page_url")
            or product.get("deploy_url")
            or "https://example.com/signup"
        )

        # Generate Touch 1 (immediate, value-focused) via LLM
        touch1_copy: dict[str, Any] = await self.chat_json(
            system=(
                "You are an expert B2B outreach copywriter. "
                "Write a cold email that is 100% value-focused — share a useful insight, "
                "tip, or resource related to the product's niche. NO sales pitch, NO CTA to buy. "
                'Return JSON: {"subject": "...", "html_body": "...", "text_body": "..."}'
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Niche: {product.get('niche', '')}\n"
                f"Target audience: {product.get('target_audience', '')}\n"
                f"Value proposition: {product.get('value_proposition', '')}\n\n"
                "Write Touch 1: a helpful, non-pitchy intro email that builds trust."
            ),
            temperature=0.7,
        )

        # Subscribe all leads and send Touch 1
        touch1_subject = touch1_copy.get("subject", f"A tip for you from {product['name']}")
        touch1_html = touch1_copy.get("html_body", "")

        from tools.kit_email import KitBroadcast
        kit_subscribers = [
            KitSubscriber(
                email=lead["email"],
                first_name=lead.get("first_name", ""),
                tags=[product_tag],
            )
            for lead in leads_data
            if lead.get("email")
        ]
        add_result = await self._kit.add_subscribers_bulk(kit_subscribers)

        # Send Touch 1 broadcast to the tag
        tags = await self._kit.list_tags()
        tag_obj = next((t for t in tags if t.get("name") == product_tag), None)
        tag_id = tag_obj["id"] if tag_obj else None

        broadcast = KitBroadcast(
            subject=touch1_subject,
            content_html=touch1_html,
            content_text=touch1_copy.get("text_body", ""),
            description=f"MTO Touch 1 for {product['name']}",
        )
        touch1_result = await self._kit.send_broadcast(broadcast, tag_id=tag_id)

        # Enrol leads into 3-step follow-up sequence (touches 2 & 3 at days 4 and 8)
        enrolled_count = 0
        for lead in leads_data:
            email = lead.get("email", "")
            if not email:
                continue
            try:
                # Use drip enrolment with only 3 emails (touch2 + touch3 + reminder)
                await self._drip.enroll_subscriber(
                    email=email,
                    first_name=lead.get("first_name", ""),
                    product_name=product["name"],
                    product_description=product.get("description", ""),
                    value_prop=product.get("value_proposition", ""),
                    cta_url=cta_url,
                    tag_name=f"mto-followup-{product.get('slug', product_id)}",
                    niche=product.get("niche", ""),
                )
                enrolled_count += 1
            except Exception as exc:
                log.warning("growth_agent.mto_enroll_failed", email=email, error=str(exc))

        await self.record_action(
            action_type="multi_touch_outreach",
            payload={"product_id": product_id, "leads": len(leads_data)},
            result={
                "added_to_kit": add_result["added"],
                "touch1_sent": touch1_result.get("success", False),
                "followup_enrolled": enrolled_count,
            },
            product_id=product_id,
            success=touch1_result.get("success", False),
        )
        await self.remember(
            f"Multi-touch outreach for {product['name']}: "
            f"{len(leads_data)} leads, Touch 1 sent={'yes' if touch1_result.get('success') else 'no'}, "
            f"follow-up enrolled={enrolled_count}.",
            product_id=product_id,
        )

        return AgentResult(
            success=touch1_result.get("success", False),
            agent=self.name,
            task_type="multi_touch_outreach",
            output={
                "leads_found": len(leads_data),
                "subscribers_added": add_result["added"],
                "touch1_subject": touch1_subject,
                "touch1_broadcast_id": touch1_result.get("broadcast_id"),
                "followup_enrolled": enrolled_count,
                "product_tag": product_tag,
            },
            error=touch1_result.get("error"),
            actions_taken=[
                "generate_leads",
                "generate_touch1_copy",
                "add_kit_subscribers",
                "send_touch1_broadcast",
                "enroll_drip_followup",
            ],
        )

    # ── Lead Scoring ───────────────────────────────────────────────────────
    async def _score_leads(self, task: dict[str, Any]) -> AgentResult:
        """
        Fetch Kit subscribers for a product tag, score by engagement signals,
        store scores in Redis, and return the top 20.

        Scoring:
          subscribed  = +1
          opened_email = +3 (each open event)
          clicked      = +5 (each click event)
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="score_leads",
                error="Product not found",
            )

        product_slug = product.get("slug", product_id)
        product_tag = f"acai-{product_slug}"

        # Step 1: Get tag ID from Kit
        tags = await self._kit.list_tags()
        tag_obj = next((t for t in tags if product_tag in t.get("name", "")), None)
        if not tag_obj:
            return AgentResult(
                success=False, agent=self.name, task_type="score_leads",
                error=f"Tag '{product_tag}' not found in Kit",
            )
        tag_id = tag_obj["id"]

        # Step 2: Fetch subscribers for this tag
        subscribers = await self._fetch_tag_subscribers(tag_id)
        if not subscribers:
            return AgentResult(
                success=True, agent=self.name, task_type="score_leads",
                output={"scored": 0, "top_leads": []},
                actions_taken=["fetch_kit_subscribers"],
            )

        # Step 3: Score each subscriber and store in Redis
        import redis.asyncio as aioredis
        redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
        scored_leads: list[dict[str, Any]] = []

        try:
            for sub in subscribers:
                email = sub.get("email_address") or sub.get("email", "")
                if not email:
                    continue

                score = 1  # Base: subscribed

                # Check email activity fields from Kit subscriber data
                # Kit v3 returns stats in subscriber details
                sub_detail = await self._fetch_subscriber_detail(sub.get("id"))
                if sub_detail:
                    stats = sub_detail.get("stats", {}) or {}
                    open_count = int(stats.get("open_tracking", 0) or 0)
                    click_count = int(stats.get("click_tracking", 0) or 0)
                    score += open_count * 3
                    score += click_count * 5

                scored_leads.append({
                    "email": email,
                    "first_name": sub.get("first_name", ""),
                    "score": score,
                    "subscriber_id": sub.get("id"),
                })

                # Store score in Redis hash
                redis_key = f"lead_score:{product_slug}:{email}"
                await redis.hset(redis_key, mapping={
                    "email": email,
                    "score": score,
                    "product_slug": product_slug,
                })
                await redis.expire(redis_key, 60 * 60 * 24 * 30)  # 30-day TTL

        finally:
            await redis.aclose()

        # Sort by score descending, return top 20
        scored_leads.sort(key=lambda x: x["score"], reverse=True)
        top_20 = scored_leads[:20]

        await self.record_action(
            action_type="score_leads",
            payload={"product_id": product_id, "tag": product_tag},
            result={
                "total_scored": len(scored_leads),
                "top_score": top_20[0]["score"] if top_20 else 0,
            },
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Scored {len(scored_leads)} leads for {product['name']}. "
            f"Top lead: {top_20[0]['email'] if top_20 else 'none'} (score={top_20[0]['score'] if top_20 else 0}).",
            product_id=product_id,
        )

        log.info(
            "growth_agent.leads_scored",
            product=product["name"],
            total=len(scored_leads),
            top_score=top_20[0]["score"] if top_20 else 0,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="score_leads",
            output={
                "total_scored": len(scored_leads),
                "top_leads": top_20,
                "product_tag": product_tag,
            },
            actions_taken=["fetch_kit_subscribers", "score_engagement", "store_scores_redis"],
        )

    async def _fetch_tag_subscribers(
        self, tag_id: int, page_size: int = 200
    ) -> list[dict[str, Any]]:
        """Fetch all subscribers under a Kit tag (paginated)."""
        if not self._kit._api_secret:
            return []

        subscribers: list[dict[str, Any]] = []
        page = 1

        async with httpx.AsyncClient(timeout=30) as client:
            while True:
                resp = await client.get(
                    f"{self._kit._base}/tags/{tag_id}/subscriptions",
                    params={
                        "api_secret": self._kit._api_secret,
                        "page": page,
                        "per_page": page_size,
                    },
                )
                if resp.status_code != 200:
                    log.warning(
                        "growth_agent.fetch_subscribers_failed",
                        tag_id=tag_id,
                        status=resp.status_code,
                    )
                    break

                data = resp.json()
                batch = data.get("subscriptions", [])
                for item in batch:
                    sub = item.get("subscriber", item)
                    subscribers.append(sub)

                total_pages = data.get("total_pages", 1)
                if page >= total_pages:
                    break
                page += 1

        return subscribers

    async def _fetch_subscriber_detail(
        self, subscriber_id: Any
    ) -> dict[str, Any]:
        """Fetch detailed subscriber info from Kit (includes email stats)."""
        if not subscriber_id or not self._kit._api_secret:
            return {}

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{self._kit._base}/subscribers/{subscriber_id}",
                params={"api_secret": self._kit._api_secret},
            )
            if resp.status_code == 200:
                return resp.json().get("subscriber", {})
        return {}
