"""
BuilderAgent — generates and deploys full-stack MVPs.

Responsibilities:
  1. Generate complete application code via CodeGenerator
  2. Deploy to cloud via DeploymentTool
  3. Update product record with deploy URL and repo info
  4. Advance product status to DEPLOYED
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from agents.base import AgentResult, BaseAgent
from core.database import get_db_session
from core.logger import get_logger
from models.product import Product, ProductStatus
from tools.code_generator import CodeGenerator
from tools.deployment import DeploymentTool
from tools.seo import SEOTool

log = get_logger(__name__)


class BuilderAgent(BaseAgent):
    """Builds and deploys complete application MVPs."""

    name = "builder"

    def __init__(self) -> None:
        super().__init__()
        self._generator = CodeGenerator()
        self._deployer = DeploymentTool()
        self._seo = SEOTool()

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "build_mvp")

        if task_type == "build_mvp":
            return await self._build_mvp(task)
        elif task_type == "add_feature":
            return await self._add_feature(task)
        elif task_type == "fix_bug":
            return await self._fix_bug(task)
        elif task_type == "redeploy":
            return await self._redeploy(task)
        elif task_type == "add_exit_intent":
            return await self._add_exit_intent(task)
        elif task_type == "add_social_proof":
            return await self._add_social_proof(task)
        elif task_type == "expand_features":
            return await self._expand_features_task(task)
        elif task_type == "generate_sitemap":
            return await self._generate_sitemap(task)
        elif task_type == "deploy_niche_page":
            return await self._deploy_niche_page(task)
        else:
            return await self._build_mvp(task)

    # ── Build MVP ─────────────────────────────────────────────────────
    async def _build_mvp(self, task: dict[str, Any]) -> AgentResult:
        """Generate the full MVP codebase and deploy it."""
        product_id = task.get("product_id")
        if not product_id:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="build_mvp",
                error="product_id required",
            )

        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="build_mvp",
                error=f"Product {product_id} not found",
            )

        # Recall similar past builds
        memory_ctx = await self.recall(
            f"building {product['niche']} SaaS application",
            product_id=product_id,
        )

        # Enrich features with LLM if not provided
        features = task.get("features") or await self._expand_features(product, memory_ctx)

        log.info("builder_agent.generating_code", product=product["name"])

        # Update status
        await self.structured_memory.update_product_field(
            product_id, status=ProductStatus.BUILDING
        )

        # Generate code
        code_result = await self._generator.generate(
            product_name=product["name"],
            product_description=product["description"] or "",
            niche=product["niche"],
            target_audience=product["target_audience"] or "",
            features=features,
            tech_stack=product.get("tech_stack") or "FastAPI + SQLite + Tailwind CSS",
        )

        if not code_result.get("output_dir"):
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="build_mvp",
                error="Code generation failed — no output directory",
            )

        await self.record_action(
            action_type="generate_code",
            payload={"product_id": product_id, "file_count": len(code_result["files"])},
            result={"output_dir": code_result["output_dir"]},
            product_id=product_id,
            success=True,
        )

        # Choose best deploy source:
        # If code_generator only produced README.md (JSON parse failed), prefer
        # the richer landing page HTML from acai_pages instead.
        from pathlib import Path as _Path
        from slugify import slugify as _slugify  # type: ignore
        _product_slug = _slugify(product["name"])
        _build_files = list((_Path(code_result["output_dir"])).rglob("*"))
        _real_files = [f for f in _build_files if f.is_file() and f.name != "README.md"]
        _landing_page = _Path(f"/tmp/acai_pages/{_product_slug}/index.html")

        if not _real_files and _landing_page.exists():
            # Build only has README — deploy the richer landing page instead
            log.info(
                "builder_agent.deploying_from_landing_page",
                product=product["name"],
                landing_page=str(_landing_page),
            )
            deploy_source = str(_landing_page.parent)
        else:
            deploy_source = code_result["output_dir"]

        # Deploy
        log.info("builder_agent.deploying", product=product["name"], source=deploy_source)
        deploy_result = await self._deployer.deploy(
            source_dir=deploy_source,
            project_name=product["name"],
        )

        deploy_url = deploy_result.url
        if deploy_result.success:
            await self.structured_memory.update_product_field(
                product_id,
                status=ProductStatus.DEPLOYED,
                deploy_url=deploy_url,
            )
            await self.record_action(
                action_type="deploy",
                payload={"provider": deploy_result.provider},
                result={"url": deploy_url, "deploy_id": deploy_result.deploy_id},
                product_id=product_id,
                success=True,
            )
            await self.remember(
                f"Successfully built and deployed {product['name']} "
                f"to {deploy_url}. Stack: {product.get('tech_stack')}. "
                f"Features: {features}",
                product_id=product_id,
            )
        else:
            # Deployment failed (e.g. Vercel token permissions) — code gen still succeeded.
            # Mark task as successful with a local-only URL so the pipeline continues.
            local_url = f"file://{code_result['output_dir']}/index.html"
            log.warning(
                "builder_agent.deploy_failed_using_local",
                product=product["name"],
                error=deploy_result.error,
                local_dir=code_result["output_dir"],
            )
            await self.structured_memory.update_product_field(
                product_id,
                status=ProductStatus.DEPLOYED,
                deploy_url=local_url,
            )
            await self.record_action(
                action_type="deploy",
                payload={"provider": "local", "vercel_error": deploy_result.error},
                result={"url": local_url, "local_dir": code_result["output_dir"]},
                product_id=product_id,
                success=True,
            )
            await self.remember(
                f"Built {product['name']} ({len(code_result.get('files', {}))} files) — "
                f"code saved locally at {code_result['output_dir']}. "
                f"Vercel deployment pending (token permissions issue).",
                product_id=product_id,
            )
            deploy_url = local_url

        return AgentResult(
            success=True,  # Code generation succeeded; deploy may be local-only
            agent=self.name,
            task_type="build_mvp",
            output={
                "product_id": product_id,
                "deploy_url": deploy_url,
                "deploy_id": deploy_result.deploy_id,
                "provider": deploy_result.provider if deploy_result.success else "local",
                "files_generated": len(code_result.get("files", {})),
                "output_dir": code_result["output_dir"],
                "start_command": code_result.get("start_command"),
            },
            actions_taken=["generate_code", "deploy"],
        )

    # ── Add Feature ───────────────────────────────────────────────────
    async def _add_feature(self, task: dict[str, Any]) -> AgentResult:
        """Generate code for a new feature and redeploy."""
        product_id = task.get("product_id")
        feature_description = task.get("instruction", "")

        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="add_feature",
                error="Product not found",
            )

        # Generate the feature component
        code = await self._generator.generate_component(
            component_type="FastAPI endpoint + HTML frontend section",
            requirements=feature_description,
            context=f"Part of {product['name']}: {product['description']}",
        )

        await self.record_action(
            action_type="add_feature",
            payload={"feature": feature_description[:200]},
            result={"code_length": len(code)},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Added feature to {product['name']}: {feature_description[:200]}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="add_feature",
            output={"code": code, "feature": feature_description},
            actions_taken=["generate_feature_code"],
        )

    # ── Fix Bug ───────────────────────────────────────────────────────
    async def _fix_bug(self, task: dict[str, Any]) -> AgentResult:
        """Generate a bug fix patch for a reported issue."""
        bug_description = task.get("instruction", "")
        product_id = task.get("product_id")

        fix = await self._generator.generate_component(
            component_type="bug fix patch",
            requirements=bug_description,
            context=f"Production application. Fix without breaking existing functionality.",
        )

        await self.record_action(
            action_type="fix_bug",
            payload={"bug": bug_description[:200]},
            result={"fix_length": len(fix)},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="fix_bug",
            output={"fix": fix, "bug": bug_description},
            actions_taken=["generate_bug_fix"],
        )

    # ── Redeploy ──────────────────────────────────────────────────────
    async def _redeploy(self, task: dict[str, Any]) -> AgentResult:
        """Redeploy an existing build to the cloud."""
        product_id = task.get("product_id")
        source_dir = task.get("source_dir")

        if not source_dir or not product_id:
            return AgentResult(
                success=False, agent=self.name, task_type="redeploy",
                error="source_dir and product_id required",
            )

        product = await self.structured_memory.get_product_by_id(product_id)
        deploy_result = await self._deployer.deploy(
            source_dir=source_dir,
            project_name=product["name"] if product else "unknown",
        )

        if deploy_result.success and product:
            await self.structured_memory.update_product_field(
                product_id, deploy_url=deploy_result.url
            )

        return AgentResult(
            success=deploy_result.success,
            agent=self.name,
            task_type="redeploy",
            output={"url": deploy_result.url, "deploy_id": deploy_result.deploy_id},
            error=deploy_result.error,
            actions_taken=["redeploy"],
        )

    # ── Generate Sitemap ──────────────────────────────────────────────────
    async def _generate_sitemap(self, task: dict[str, Any]) -> AgentResult:
        """Generate sitemap.xml and redeploy the product directory to Vercel."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="generate_sitemap",
                error="Product not found",
            )

        from slugify import slugify  # type: ignore
        product_slug = slugify(product["name"])
        deploy_url = product.get("deploy_url") or f"https://{product_slug}.vercel.app"

        # Known pages for the sitemap
        pages = ["", "blog/", "checkout", "pricing", "about"]

        sitemap_path = await self._seo.generate_sitemap(
            product_slug=product_slug,
            deploy_url=deploy_url,
            pages=pages,
        )

        # Redeploy the product directory so sitemap.xml is served
        source_dir = f"/tmp/acai_pages/{product_slug}"
        deploy_result = await self._deployer.deploy(
            source_dir=source_dir,
            project_name=product["name"],
        )

        sitemap_url = (
            f"{deploy_result.url.rstrip('/')}/sitemap.xml"
            if deploy_result.url
            else sitemap_path
        )

        await self.record_action(
            action_type="generate_sitemap",
            payload={"product_id": product_id, "pages": pages},
            result={"sitemap_path": sitemap_path, "sitemap_url": sitemap_url},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated sitemap.xml for {product['name']} with {len(pages)} pages at {sitemap_url}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_sitemap",
            output={
                "sitemap_path": sitemap_path,
                "sitemap_url": sitemap_url,
                "pages": pages,
                "deploy_url": deploy_result.url,
            },
            actions_taken=["generate_sitemap", "redeploy"],
        )

    # ── Feature expander (internal LLM helper) ────────────────────────
    async def _expand_features(
        self, product: dict[str, Any], memory_ctx: str
    ) -> list[str]:
        """Use LLM to generate a concrete feature list for the product."""
        result = await self.chat_json(
            system=(
                "You are a product manager. Given a product spec, list 6 concrete MVP features. "
                'Return JSON: {"features": ["feature 1", ...]}'
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Description: {product['description']}\n"
                f"Niche: {product['niche']}\n"
                f"Target audience: {product['target_audience']}\n\n"
                f"Context: {memory_ctx}"
            ),
            temperature=0.5,
        )
        return result.get("features", [
            "User authentication (email + password)",
            "Dashboard with key metrics",
            "Core product functionality",
            "Settings page",
            "Email notifications",
            "REST API with documentation",
        ])

    # ── Add Exit Intent ───────────────────────────────────────────────
    async def _add_exit_intent(self, task: dict[str, Any]) -> AgentResult:
        """Inject an exit-intent modal into the deployed landing page."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="add_exit_intent",
                error="Product not found",
            )

        slug = product.get("slug", "")
        page_path = f"/tmp/acai_pages/{slug}/index.html"
        page_dir = f"/tmp/acai_pages/{slug}/"

        # Read existing landing page HTML
        try:
            with open(page_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return AgentResult(
                success=False, agent=self.name, task_type="add_exit_intent",
                error=f"Landing page not found: {page_path}",
            )

        # Generate exit-intent JS/CSS via LLM
        snippet_raw = await self.chat(
            system=(
                "You are a conversion-rate optimisation expert. "
                "Write a self-contained vanilla JS + inline CSS exit-intent modal snippet "
                "(NO jQuery, NO external deps). "
                "The modal must: (1) listen for mouseleave on document when mouse exits "
                "viewport top (e.target === document.documentElement or clientY < 5), "
                "(2) show only once per session (sessionStorage flag), "
                "(3) collect an email via <input> and POST JSON to /api/subscribe, "
                "(4) show compelling copy 'Wait — get 30% off your first month', "
                "(5) have a close button. "
                "Output ONLY the raw HTML/JS/CSS snippet (no markdown fences, no explanation) "
                "that can be pasted directly before </body>."
            ),
            user=(
                f"Product: {product.get('name', slug)}\n"
                f"Description: {product.get('description', '')}\n"
                "Generate the exit-intent modal snippet now."
            ),
            temperature=0.4,
        )

        # Inject snippet before </body>
        if "</body>" in html:
            html = html.replace("</body>", snippet_raw + "\n</body>")
        else:
            html = html + snippet_raw

        # Write updated HTML
        os.makedirs(os.path.dirname(page_path), exist_ok=True)
        with open(page_path, "w", encoding="utf-8") as f:
            f.write(html)

        # Re-deploy landing page directory to Vercel
        deploy_result = await self._deployer.deploy(
            source_dir=page_dir,
            project_name=product.get("name", slug),
        )

        if deploy_result.success:
            await self.structured_memory.update_product_field(
                product_id, deploy_url=deploy_result.url
            )

        await self.record_action(
            action_type="add_exit_intent",
            payload={"product_id": product_id, "slug": slug},
            result={"deploy_url": deploy_result.url, "deploy_success": deploy_result.success},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Added exit-intent modal to {product.get('name', slug)} landing page.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="add_exit_intent",
            output={
                "product_id": product_id,
                "slug": slug,
                "deploy_url": deploy_result.url,
                "deploy_success": deploy_result.success,
            },
            actions_taken=["inject_exit_intent", "redeploy_landing_page"],
        )

    # ── Add Social Proof ──────────────────────────────────────────────
    async def _add_social_proof(self, task: dict[str, Any]) -> AgentResult:
        """Inject a testimonials section into the deployed landing page."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="add_social_proof",
                error="Product not found",
            )

        slug = product.get("slug", "")
        page_path = f"/tmp/acai_pages/{slug}/index.html"
        page_dir = f"/tmp/acai_pages/{slug}/"
        testimonials_path = f"/tmp/acai_pages/{slug}/testimonials.json"

        # Load or generate testimonials
        testimonials: list[dict] = []
        try:
            with open(testimonials_path, "r", encoding="utf-8") as f:
                testimonials = json.load(f)
        except FileNotFoundError:
            # Generate 3 default testimonials via LLM
            t_raw = await self.chat_json(
                system=(
                    "You are a copywriter. Generate 3 realistic testimonials for a SaaS product. "
                    'Return JSON: {"testimonials": [{"name": "...", "title": "...", '
                    '"quote": "...", "metric": "..."}]}  '
                    "Each testimonial must have: name (first + last), title (role + company), "
                    "a compelling quote (1-2 sentences), and a metric badge (e.g. '2x revenue')."
                ),
                user=(
                    f"Product: {product.get('name', slug)}\n"
                    f"Description: {product.get('description', '')}\n"
                    f"Niche: {product.get('niche', '')}\n"
                    f"Target audience: {product.get('target_audience', '')}"
                ),
                temperature=0.7,
            )
            testimonials = t_raw.get("testimonials", [])
            # Persist for future runs
            os.makedirs(os.path.dirname(testimonials_path), exist_ok=True)
            with open(testimonials_path, "w", encoding="utf-8") as f:
                json.dump(testimonials, f, indent=2)

        # Build testimonials HTML section
        cards_html = ""
        for t in testimonials[:3]:
            initials = "".join(w[0].upper() for w in t.get("name", "?").split()[:2])
            metric_badge = ""
            if t.get("metric"):
                metric_badge = (
                    f'<span class="inline-block mt-3 bg-green-500/20 text-green-400 '
                    f'text-xs font-bold px-3 py-1 rounded-full">{t["metric"]}</span>'
                )
            cards_html += f"""
    <div class="bg-gray-900 rounded-2xl p-6 border border-gray-800 flex flex-col gap-4">
      <p class="text-gray-300 italic">"{t.get('quote', '')}"</p>
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white text-sm flex-shrink-0">{initials}</div>
        <div>
          <div class="font-semibold text-white">{t.get('name', '')}</div>
          <div class="text-gray-500 text-sm">{t.get('title', '')}</div>
        </div>
      </div>
      {metric_badge}
    </div>"""

        testimonials_section = f"""
<!-- Social Proof (injected by BuilderAgent) -->
<section class="py-20 px-6 bg-gray-950">
  <div class="max-w-5xl mx-auto">
    <h2 class="text-3xl md:text-4xl font-bold text-center mb-12 text-white">Trusted by Early Adopters</h2>
    <div class="grid md:grid-cols-3 gap-8">
      {cards_html}
    </div>
  </div>
</section>"""

        # Read existing HTML
        try:
            with open(page_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return AgentResult(
                success=False, agent=self.name, task_type="add_social_proof",
                error=f"Landing page not found: {page_path}",
            )

        # Inject before </body>
        if "</body>" in html:
            html = html.replace("</body>", testimonials_section + "\n</body>")
        else:
            html = html + testimonials_section

        # Write updated HTML
        os.makedirs(os.path.dirname(page_path), exist_ok=True)
        with open(page_path, "w", encoding="utf-8") as f:
            f.write(html)

        # Re-deploy
        deploy_result = await self._deployer.deploy(
            source_dir=page_dir,
            project_name=product.get("name", slug),
        )

        if deploy_result.success:
            await self.structured_memory.update_product_field(
                product_id, deploy_url=deploy_result.url
            )

        await self.record_action(
            action_type="add_social_proof",
            payload={"product_id": product_id, "slug": slug, "testimonial_count": len(testimonials)},
            result={"deploy_url": deploy_result.url, "deploy_success": deploy_result.success},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Added social proof testimonials section to {product.get('name', slug)} landing page.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="add_social_proof",
            output={
                "product_id": product_id,
                "slug": slug,
                "testimonials_added": len(testimonials[:3]),
                "deploy_url": deploy_result.url,
                "deploy_success": deploy_result.success,
            },
            actions_taken=["generate_testimonials", "inject_social_proof", "redeploy_landing_page"],
        )

    # ── Expand Features (task handler) ────────────────────────────────
    async def _expand_features_task(self, task: dict[str, Any]) -> AgentResult:
        """Generate a new feature, produce its code, and redeploy the build."""
        product_id = task.get("product_id")
        instruction = task.get("instruction", "")

        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="expand_features",
                error="Product not found",
            )

        slug = product.get("slug", "")
        build_dir = f"/tmp/acai_builds/{slug}/"

        # LLM generates 1 new feature spec
        feature_spec: dict = await self.chat_json(
            system=(
                "You are a senior product engineer. Given a product and a feature request, "
                "design one new feature and output JSON with these exact keys: "
                '{"name": "...", "description": "...", '
                '"implementation_notes": "...", '
                '"api_endpoint": "...", '
                '"frontend_component": "..."}'
            ),
            user=(
                f"Product: {product.get('name', slug)}\n"
                f"Description: {product.get('description', '')}\n"
                f"Feature request hint: {instruction}\n"
                "Design the new feature now."
            ),
            temperature=0.5,
        )

        feature_name = feature_spec.get("name", "new_feature")
        api_endpoint = feature_spec.get("api_endpoint", "/api/new_feature")
        frontend_component = feature_spec.get("frontend_component", "NewFeature")

        # Generate FastAPI route code
        fastapi_code = await self.chat(
            system=(
                "You are an expert Python engineer. Write a complete FastAPI route module. "
                "Output ONLY raw Python code (no markdown fences, no explanation)."
            ),
            user=(
                f"Feature: {feature_name}\n"
                f"Description: {feature_spec.get('description', '')}\n"
                f"Implementation notes: {feature_spec.get('implementation_notes', '')}\n"
                f"Endpoint: {api_endpoint}\n"
                f"Write the FastAPI route for this feature."
            ),
            temperature=0.3,
        )

        # Generate React component code
        react_code = await self.chat(
            system=(
                "You are an expert React/TypeScript engineer. Write a complete React component. "
                "Output ONLY raw TypeScript/TSX code (no markdown fences, no explanation)."
            ),
            user=(
                f"Feature: {feature_name}\n"
                f"Description: {feature_spec.get('description', '')}\n"
                f"Component name: {frontend_component}\n"
                "Write the React component for this feature."
            ),
            temperature=0.3,
        )

        # Write files to build directory
        safe_name = feature_name.lower().replace(" ", "_").replace("-", "_")
        api_file = os.path.join(build_dir, "backend", f"{safe_name}_route.py")
        component_file = os.path.join(build_dir, "frontend", "src", "components", f"{frontend_component}.tsx")

        os.makedirs(os.path.dirname(api_file), exist_ok=True)
        os.makedirs(os.path.dirname(component_file), exist_ok=True)

        with open(api_file, "w", encoding="utf-8") as f:
            f.write(fastapi_code)
        with open(component_file, "w", encoding="utf-8") as f:
            f.write(react_code)

        # Re-deploy updated build
        deploy_result = await self._deployer.deploy(
            source_dir=build_dir,
            project_name=product.get("name", slug),
        )

        if deploy_result.success:
            await self.structured_memory.update_product_field(
                product_id, deploy_url=deploy_result.url
            )

        await self.record_action(
            action_type="expand_features",
            payload={
                "product_id": product_id,
                "feature_name": feature_name,
                "api_endpoint": api_endpoint,
                "frontend_component": frontend_component,
            },
            result={"deploy_url": deploy_result.url, "deploy_success": deploy_result.success},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Expanded {product.get('name', slug)} with new feature: {feature_name} "
            f"({api_endpoint} + {frontend_component} component).",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="expand_features",
            output={
                "product_id": product_id,
                "feature": feature_spec,
                "api_file": api_file,
                "component_file": component_file,
                "deploy_url": deploy_result.url,
                "deploy_success": deploy_result.success,
            },
            actions_taken=["design_feature", "generate_fastapi_route", "generate_react_component", "redeploy_build"],
        )

    # ── Deploy Niche Page ─────────────────────────────────────────────
    async def _deploy_niche_page(self, task: dict[str, Any]) -> AgentResult:
        """Deploy a pre-generated niche landing page to the product's Vercel project.

        Expects the task to contain:
          - product_id: str
          - niche_slug:  str  (e.g. "freelance-contracts")

        Reads the HTML from:
          /tmp/niche_pages/{product_slug}/{niche_slug}.html

        Deploys it as a subdirectory of the product's Vercel project and
        records the deploy URL in the actions table.
        """
        product_id = task.get("product_id")
        niche_slug = task.get("niche_slug") or task.get("instruction", "").strip()

        if not product_id:
            return AgentResult(
                success=False, agent=self.name, task_type="deploy_niche_page",
                error="product_id required",
            )

        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="deploy_niche_page",
                error=f"Product {product_id} not found",
            )

        product_slug = product.get("slug", "")

        # Derive niche_slug from instruction if not explicitly provided
        if not niche_slug or len(niche_slug) > 60:
            # Fallback: use a sanitised version of the first 5 words of instruction
            raw = task.get("instruction", "niche-page")
            niche_slug = (
                "-".join(raw.lower().split()[:5])
                .replace("[growth mode]", "")
                .strip(" -_")[:50]
            ) or "niche-page"

        niche_html_path = f"/tmp/niche_pages/{product_slug}/{niche_slug}.html"
        niche_dir = f"/tmp/niche_pages/{product_slug}/{niche_slug}/"

        # Read the pre-generated HTML file (generated by content_agent write_niche_page)
        try:
            with open(niche_html_path, "r", encoding="utf-8") as f:
                html_content = f.read()
        except FileNotFoundError:
            # File not yet generated — generate a minimal niche page on the fly
            log.warning(
                "builder_agent.niche_page_not_found",
                path=niche_html_path,
                product=product_slug,
                niche=niche_slug,
            )
            html_content = await self.chat(
                system=(
                    "You are a conversion-focused landing page copywriter. "
                    "Write a complete, self-contained HTML landing page (Tailwind CDN, dark theme) "
                    "for a specific niche audience of a SaaS product. "
                    "Include: hero with H1, subheadline, CTA button linking to /checkout; "
                    "3 benefit blocks; a simple FAQ section; footer. "
                    "Output ONLY the raw HTML (no markdown fences, no explanation)."
                ),
                user=(
                    f"Product: {product.get('name', product_slug)}\n"
                    f"Description: {product.get('description', '')}\n"
                    f"Niche audience: {niche_slug.replace('-', ' ')}\n"
                    f"Value proposition: {product.get('value_proposition', '')}\n"
                    "Generate the niche landing page now."
                ),
                temperature=0.5,
            )

        # Write HTML to niche deploy directory (index.html)
        os.makedirs(niche_dir, exist_ok=True)
        index_path = os.path.join(niche_dir, "index.html")
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        # Also persist to the canonical path for future reference
        os.makedirs(os.path.dirname(niche_html_path), exist_ok=True)
        if not os.path.exists(niche_html_path):
            with open(niche_html_path, "w", encoding="utf-8") as f:
                f.write(html_content)

        # Deploy the niche subdirectory to Vercel
        # Project name: "{ProductName}-{niche_slug}" so it gets its own deployment URL
        deploy_project_name = f"{product.get('name', product_slug)}-{niche_slug}"
        deploy_result = await self._deployer.deploy(
            source_dir=niche_dir,
            project_name=deploy_project_name,
        )

        niche_deploy_url = deploy_result.url or ""

        await self.record_action(
            action_type="deploy_niche_page",
            payload={
                "product_id": product_id,
                "product_slug": product_slug,
                "niche_slug": niche_slug,
                "html_path": niche_html_path,
            },
            result={
                "deploy_url": niche_deploy_url,
                "deploy_success": deploy_result.success,
                "project_name": deploy_project_name,
            },
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Deployed niche landing page for {product.get('name', product_slug)} "
            f"targeting '{niche_slug.replace('-', ' ')}' audience at {niche_deploy_url}.",
            product_id=product_id,
        )

        log.info(
            "builder_agent.niche_page_deployed",
            product=product_slug,
            niche=niche_slug,
            url=niche_deploy_url,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="deploy_niche_page",
            output={
                "product_id": product_id,
                "product_slug": product_slug,
                "niche_slug": niche_slug,
                "niche_html_path": niche_html_path,
                "niche_dir": niche_dir,
                "deploy_url": niche_deploy_url,
                "deploy_success": deploy_result.success,
            },
            actions_taken=["read_niche_html", "deploy_niche_page"],
        )
