"""
DataAgent — analytics, reporting, and feedback loops.

Responsibilities:
  1. Collect and aggregate metrics across products
  2. Generate performance reports
  3. Identify growth opportunities from data patterns
  4. Feed insights back into the execution loop
  5. Detect anomalies (sudden drop in traffic, churn spikes)
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from sqlalchemy import update as sql_update

from agents.base import AgentResult, BaseAgent
from core.config import settings
from core.database import get_db_session
from core.logger import get_logger
from core.redis_client import get_redis
from models.metric import MetricType
from models.product import Product
from tools.analytics import AnalyticsTool
from tools.deployment import DeploymentTool
from tools.kit_email import KitBroadcast, KitEmailTool
from tools.lead_scoring import LeadScoringTool

log = get_logger(__name__)


class DataAgent(BaseAgent):
    """Analyses performance data and generates actionable insights."""

    name = "data"

    def __init__(self) -> None:
        super().__init__()
        self._analytics = AnalyticsTool()
        self._kit = KitEmailTool()
        self._deployer = DeploymentTool()

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "generate_report")

        if task_type == "generate_report":
            return await self._generate_report(task)
        elif task_type == "collect_metrics":
            return await self._collect_metrics(task)
        elif task_type == "detect_anomalies":
            return await self._detect_anomalies(task)
        elif task_type == "generate_insights":
            return await self._generate_insights(task)
        elif task_type == "system_report":
            return await self._system_report(task)
        elif task_type == "score_leads":
            return await self._score_leads_batch(task)
        elif task_type == "generate_revenue_dashboard":
            return await self._generate_revenue_dashboard(task)
        elif task_type == "check_price_trigger":
            return await self._check_price_trigger(task)
        else:
            return await self._generate_report(task)

    # ── Report Generation ─────────────────────────────────────────────
    async def _generate_report(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        days = task.get("days", 30)

        if product_id:
            kpis = await self._analytics.get_product_kpis(product_id, days=days)
            funnel = await self._analytics.compute_funnel(product_id)

            # Fetch per-product 10K progress
            product = await self.structured_memory.get_product_by_id(product_id)
            slug = product.get("slug", "") if product else ""
            kit_subs = await self._get_kit_subscriber_count(slug)
            signups = product.get("signups", 0) if product else 0
            total_leads = max(signups, kit_subs)
            user_target = 10000
            pct_to_goal = round(total_leads / user_target * 100, 2)

            growth_snapshot = {
                "slug": slug,
                "signups_db": signups,
                "kit_subscribers": kit_subs,
                "total_leads": total_leads,
                "user_target": user_target,
                "pct_to_10k_goal": pct_to_goal,
                "leads_needed": max(0, user_target - total_leads),
            }

            insights = await self._analytics.generate_insights(
                analytics_data={"kpis": kpis, "funnel": funnel, "growth": growth_snapshot},
                context=(
                    f"Product: {slug} | Leads: {total_leads:,}/{user_target:,} "
                    f"({pct_to_goal}% to 10K goal)"
                ),
            )
            report = {
                "product_id": product_id,
                "period_days": days,
                "kpis": kpis,
                "funnel": funnel,
                "growth_snapshot": growth_snapshot,
                "insights": insights,
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }
        else:
            # System-wide report
            system_data = await self._analytics.get_system_analytics(days=days)
            insights = await self._analytics.generate_insights(
                analytics_data=system_data,
                context="System-wide performance report",
            )
            report = {
                "scope": "system",
                "period_days": days,
                "system_analytics": system_data,
                "insights": insights,
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }

        await self.record_action(
            action_type="generate_report",
            payload={"product_id": product_id, "days": days},
            result={"insights_count": len(insights)},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated {'product' if product_id else 'system'} report. "
            f"Key insight: {insights[0] if insights else 'none'}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_report",
            output=report,
            actions_taken=["compute_kpis", "compute_funnel", "generate_insights"],
        )

    # ── Metric Collection ─────────────────────────────────────────────
    async def _collect_metrics(self, task: dict[str, Any]) -> AgentResult:
        """
        Collect real metrics for a product:
        - Visitor count from deployed app /metrics endpoint (if live)
        - Kit subscriber count by product tag (real email leads)
        - Progress toward 10,000-user goal
        Records everything into the database.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="collect_metrics",
                error="Product not found",
            )

        slug = product.get("slug", "")
        user_target = 10000  # All portfolio products target 10K users

        # Pull latest visitor count from deploy URL if available
        visitors_delta = await self._fetch_visitor_count(product)
        signups_delta = int(visitors_delta * 0.04)  # ~4% signup rate estimate
        revenue_delta = float(product.get("mrr", 0)) / 30  # daily MRR slice

        # Fetch Kit subscriber count for this product's tag (real leads)
        kit_subscribers = await self._get_kit_subscriber_count(slug)

        # Record each metric
        if visitors_delta > 0:
            await self._analytics.record_metric(
                MetricType.VISITORS, visitors_delta, product_id=product_id,
                source="data_agent"
            )
        if signups_delta > 0:
            await self._analytics.record_metric(
                MetricType.SIGNUPS, signups_delta, product_id=product_id,
                source="data_agent"
            )
        if revenue_delta > 0:
            await self._analytics.record_metric(
                MetricType.REVENUE, revenue_delta, product_id=product_id,
                source="data_agent"
            )

        # Update product aggregate counters
        new_signups = product["signups"] + signups_delta
        await self.structured_memory.update_product_field(
            product_id,
            visitors=product["visitors"] + visitors_delta,
            signups=new_signups,
        )

        # Compute 10K progress
        total_leads = max(new_signups, kit_subscribers)
        pct_to_goal = round(total_leads / user_target * 100, 2)

        metrics_recorded = {
            "visitors": visitors_delta,
            "signups": signups_delta,
            "revenue": round(revenue_delta, 2),
            "kit_subscribers": kit_subscribers,
            "total_leads": total_leads,
            "user_target": user_target,
            "pct_to_10k_goal": pct_to_goal,
        }

        log.info(
            "data_agent.metrics_collected",
            product=slug,
            total_leads=total_leads,
            target=user_target,
            pct=pct_to_goal,
        )

        await self.record_action(
            action_type="collect_metrics",
            payload={"product_id": product_id, "slug": slug},
            result=metrics_recorded,
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="collect_metrics",
            output=metrics_recorded,
            actions_taken=["fetch_visitor_count", "fetch_kit_subscribers", "record_metrics"],
        )

    # ── Anomaly Detection ─────────────────────────────────────────────
    async def _detect_anomalies(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        days = task.get("days", 7)

        # Get metric histories
        visitor_history = await self.structured_memory.get_metric_history(
            MetricType.VISITORS, product_id=product_id, days=days
        )
        revenue_history = await self.structured_memory.get_metric_history(
            MetricType.REVENUE, product_id=product_id, days=days
        )

        if not visitor_history and not revenue_history:
            return AgentResult(
                success=True, agent=self.name, task_type="detect_anomalies",
                output={"anomalies": [], "message": "Insufficient data for anomaly detection"},
                actions_taken=[],
            )

        anomalies_result: dict[str, Any] = await self.chat_json(
            system=(
                "You are a data analyst specialising in anomaly detection. "
                "Identify statistical anomalies in time-series data. "
                "Return JSON: {\"anomalies\": [{\"metric\": \"...\", \"type\": \"...\", "
                "\"severity\": \"low|medium|high\", \"description\": \"...\", "
                "\"recommended_action\": \"...\"}]}"
            ),
            user=(
                f"Visitor history ({days}d): {json.dumps(visitor_history)}\n\n"
                f"Revenue history ({days}d): {json.dumps(revenue_history)}\n\n"
                "Identify any sudden drops, spikes, or unusual patterns."
            ),
            temperature=0.2,
        )

        anomalies = anomalies_result.get("anomalies", [])
        high_severity = [a for a in anomalies if a.get("severity") == "high"]

        if high_severity:
            await self.remember(
                f"ANOMALY DETECTED for product {product_id}: "
                + "; ".join(a["description"] for a in high_severity),
                product_id=product_id,
            )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="detect_anomalies",
            output=anomalies_result,
            actions_taken=["analyse_metric_history", "detect_anomalies"],
        )

    # ── Insights ──────────────────────────────────────────────────────
    async def _generate_insights(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        kpis = await self._analytics.get_product_kpis(product_id, days=14)
        insights = await self._analytics.generate_insights(
            analytics_data=kpis,
            context=task.get("context", ""),
        )

        await self.remember(
            f"Generated insights for product {product_id}: {insights[:2]}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_insights",
            output={"insights": insights, "kpis": kpis},
            actions_taken=["generate_llm_insights"],
        )

    # ── System Report ─────────────────────────────────────────────────
    async def _system_report(self, task: dict[str, Any]) -> AgentResult:
        """Produce a comprehensive system-wide report for the operator."""
        system_analytics = await self._analytics.get_system_analytics(days=7)
        system_summary = await self.structured_memory.get_system_summary()

        report = await self.chat_json(
            system=(
                "You are a business intelligence analyst. Summarise system performance "
                "and produce an executive brief. "
                "Return JSON: {\"executive_summary\": \"...\", "
                "\"top_opportunities\": [...], \"top_risks\": [...], "
                "\"recommended_priorities\": [...], \"health_score\": 0-100}"
            ),
            user=(
                f"System analytics (7d):\n{json.dumps(system_analytics, indent=2)}\n\n"
                f"System summary:\n{json.dumps(system_summary, indent=2)}"
            ),
            temperature=0.3,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="system_report",
            output={
                "analytics": system_analytics,
                "summary": system_summary,
                "report": report,
            },
            actions_taken=["system_analytics", "executive_summary"],
        )

    # ── Score Leads Batch ────────────────────────────────────
    async def _score_leads_batch(self, task: dict[str, Any]) -> AgentResult:
        """
        Score all Kit subscribers for a product by their engagement behaviour
        and cache results in Redis.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="score_leads",
                error="Product not found",
            )

        slug = product.get("slug", "")

        lead_scoring_tool = LeadScoringTool()
        kit_tool = KitEmailTool()

        scoring_result = await lead_scoring_tool.score_all_kit_subscribers(
            product_slug=slug,
            kit_tool=kit_tool,
        )

        top_leads = scoring_result.get("top_leads", [])
        scored_count = scoring_result.get("scored", 0)

        await self.record_action(
            action_type="score_leads",
            payload={"product_id": product_id, "slug": slug},
            result={"scored": scored_count, "top_leads": top_leads[:10]},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Scored {scored_count} leads for {slug}. "
            f"Top lead: {top_leads[0] if top_leads else 'none'}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="score_leads",
            output={
                "product_id": product_id,
                "slug": slug,
                "scored": scored_count,
                "top_leads": top_leads[:10],
            },
            actions_taken=["fetch_kit_subscribers", "score_leads", "cache_scores"],
        )

    # ── Revenue Dashboard ─────────────────────────────────────────────
    async def _generate_revenue_dashboard(self, task: dict[str, Any]) -> AgentResult:
        """
        Generate a dark-theme HTML revenue dashboard and deploy to Vercel.
        Shows all portfolio products with MRR, daily revenue, signups, and % to $300/day goal.
        """
        products = await self.structured_memory.get_active_products()

        product_cards: list[str] = []
        total_mrr = 0.0
        total_signups = 0
        products_live = 0

        for p in products:
            mrr = float(p.get("mrr", 0) or 0)
            daily_rev = mrr / 30
            pct_to_300_day = min(round(daily_rev / 300 * 100, 1), 100)
            signups = int(p.get("signups", 0) or 0)
            status = p.get("status", "building")

            if status in ("deployed", "growing", "monetizing", "optimizing"):
                products_live += 1

            if status in ("building", "ideating"):
                status_badge = "<span class='badge building'>Building</span>"
            elif status in ("deployed", "growing"):
                status_badge = "<span class='badge growing'>Growing</span>"
            else:
                status_badge = "<span class='badge target'>Target</span>"

            total_mrr += mrr
            total_signups += signups

            deploy_url = p.get("deploy_url") or f"https://{p['slug']}.vercel.app"

            product_cards.append(
                f"<div class='card'>"
                f"<div class='card-header'>"
                f"<a href='{deploy_url}' target='_blank' class='product-name'>{p['name']}</a>"
                f"{status_badge}</div>"
                f"<div class='metrics'>"
                f"<div class='metric'><span class='mv'>${mrr:,.0f}</span><span class='ml'>MRR</span></div>"
                f"<div class='metric'><span class='mv'>${daily_rev:,.2f}</span><span class='ml'>Daily Rev</span></div>"
                f"<div class='metric'><span class='mv'>{signups:,}</span><span class='ml'>Signups</span></div>"
                f"<div class='metric'><span class='mv'>{pct_to_300_day}%</span><span class='ml'>to $300/day</span></div>"
                f"</div>"
                f"<div class='pb-wrap'><div class='pb' style='width:{pct_to_300_day}%'></div></div>"
                f"<div class='pb-label'>{pct_to_300_day}% to $300/day goal</div>"
                f"</div>"
            )

        total_daily_rev = total_mrr / 30
        pct_system = min(round(total_daily_rev / 300 * 100, 1), 100)
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        cards_html = "\n".join(product_cards)

        css = (
            "*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}"
            "body{background:#0a0a0a;color:#e8e8e8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;padding:32px 20px}"
            ".hd{text-align:center;margin-bottom:40px}"
            ".hd h1{font-size:28px;font-weight:800;color:#00ff88;margin-bottom:6px}"
            ".hd .ts{color:#555;font-size:13px}"
            ".sys{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;max-width:900px;margin:0 auto 40px}"
            ".sb{background:#111;border:1px solid #222;border-radius:10px;padding:20px;text-align:center}"
            ".sb .v{font-size:28px;font-weight:800;color:#00ff88}"
            ".sb .l{color:#666;font-size:11px;margin-top:4px;text-transform:uppercase;letter-spacing:.05em}"
            ".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;max-width:1200px;margin:0 auto}"
            ".card{background:#111;border:1px solid #222;border-radius:12px;padding:24px}"
            ".card-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px}"
            ".product-name{font-size:15px;font-weight:700;color:#fff;text-decoration:none}"
            ".product-name:hover{color:#00ff88}"
            ".badge{font-size:10px;padding:3px 9px;border-radius:12px;font-weight:600}"
            ".badge.building{background:rgba(255,60,60,.15);color:#ff4444;border:1px solid #ff4444}"
            ".badge.growing{background:rgba(255,200,0,.15);color:#ffc800;border:1px solid #ffc800}"
            ".badge.target{background:rgba(0,255,136,.15);color:#00ff88;border:1px solid #00ff88}"
            ".metrics{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px}"
            ".metric{text-align:center}"
            ".mv{display:block;font-size:20px;font-weight:800;color:#fff}"
            ".ml{display:block;font-size:10px;color:#555;text-transform:uppercase;letter-spacing:.05em;margin-top:2px}"
            ".pb-wrap{background:#1a1a1a;border-radius:4px;height:6px;overflow:hidden;margin-bottom:5px}"
            ".pb{height:100%;background:linear-gradient(90deg,#00ff88,#00cc6a);border-radius:4px}"
            ".pb-label{font-size:10px;color:#555}"
        )

        html = (
            "<!DOCTYPE html>\n<html lang='en'>\n<head>\n"
            "<meta charset='UTF-8'/>\n"
            "<meta name='viewport' content='width=device-width,initial-scale=1.0'/>\n"
            "<meta http-equiv='refresh' content='60'/>\n"
            "<title>ACAI Revenue Dashboard</title>\n"
            f"<style>{css}</style>\n"
            "</head>\n<body>\n"
            f"<div class='hd'><h1>ACAI Revenue Dashboard</h1>"
            f"<div class='ts'>Last updated: {now_str} &bull; Auto-refreshes every 60s</div></div>\n"
            f"<div class='sys'>"
            f"<div class='sb'><div class='v'>${total_mrr:,.0f}</div><div class='l'>Total MRR</div></div>"
            f"<div class='sb'><div class='v'>${total_daily_rev:,.2f}</div><div class='l'>Daily Rev</div></div>"
            f"<div class='sb'><div class='v'>{total_signups:,}</div><div class='l'>Total Leads</div></div>"
            f"<div class='sb'><div class='v'>{products_live}</div><div class='l'>Products Live</div></div>"
            f"<div class='sb'><div class='v'>{pct_system}%</div><div class='l'>to $300/day</div></div>"
            f"</div>\n"
            f"<div class='grid'>\n{cards_html}\n</div>\n"
            "</body>\n</html>"
        )

        dashboard_dir = "/tmp/acai_pages/dashboard"
        os.makedirs(dashboard_dir, exist_ok=True)
        with open(f"{dashboard_dir}/index.html", "w", encoding="utf-8") as fh:
            fh.write(html)

        deploy_result = await self._deployer.deploy(
            source_dir=dashboard_dir,
            project_name="acai-dashboard",
        )
        dashboard_url = deploy_result.url or "http://localhost/dashboard"

        await self.record_action(
            action_type="generate_revenue_dashboard",
            payload={"products_count": len(products)},
            result={"dashboard_url": dashboard_url, "total_mrr": total_mrr},
            success=True,
        )
        await self.remember(
            f"Generated revenue dashboard. Total MRR: ${total_mrr:,.0f}. URL: {dashboard_url}."
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_revenue_dashboard",
            output={
                "dashboard_url": dashboard_url,
                "total_mrr": total_mrr,
                "total_daily_rev": round(total_daily_rev, 2),
                "total_signups": total_signups,
                "products_live": products_live,
                "pct_to_300_day": pct_system,
            },
            actions_taken=["generate_dashboard_html", "deploy_dashboard"],
        )

    # ── Price Trigger ─────────────────────────────────────────────────
    async def _check_price_trigger(self, task: dict[str, Any]) -> AgentResult:
        """
        For each product with >= 100 signups not yet price-bumped:
        - Raise price_monthly by $7
        - Update in DB, set Redis flag (no expiry)
        - Send grandfathering broadcast to product subscribers
        """
        products = await self.structured_memory.get_active_products()
        redis = await get_redis()
        bumped: list[dict] = []

        for p in products:
            product_id = p["id"]
            signups = int(p.get("signups", 0) or 0)
            price_monthly = float(p.get("price_monthly", 0) or 0)

            if signups < 100:
                continue

            already_bumped = await redis.get(f"price_bumped:{product_id}")
            if already_bumped:
                continue

            old_price = price_monthly
            new_price = round(old_price + 7, 2)

            async with get_db_session() as session:
                await session.execute(
                    sql_update(Product)
                    .where(Product.id == product_id)
                    .values(price_monthly=new_price)
                )

            await redis.set(f"price_bumped:{product_id}", "1")

            slug = p["slug"]
            name = p["name"]
            tags = await self._kit.list_tags()
            tag_obj = next(
                (t for t in tags if f"acai-{slug}" in t.get("name", "")), None
            )
            tag_id = tag_obj["id"] if tag_obj else None

            broadcast = KitBroadcast(
                subject=(
                    f"We're raising prices "
                    f"\u2014 you're locked in at ${old_price:.0f}/mo forever"
                ),
                content_html=(
                    f"<p>Hi {{{{ subscriber.first_name | default: 'there' }}}},</p>"
                    f"<p>Great news for early {name} users.</p>"
                    f"<p>Due to strong demand, we're raising our price from "
                    f"<strong>${old_price:.0f}/mo</strong> to "
                    f"<strong>${new_price:.0f}/mo</strong> for new customers.</p>"
                    f"<p><strong>You are grandfathered in at ${old_price:.0f}/mo "
                    f"forever.</strong> Your price will never change as long as "
                    f"you stay subscribed.</p>"
                    f"<p>Thank you for being an early supporter of {name}.</p>"
                ),
                content_text=(
                    f"Hi there,\nWe're raising {name} from ${old_price:.0f}/mo "
                    f"to ${new_price:.0f}/mo for new customers.\n"
                    f"You're grandfathered at ${old_price:.0f}/mo forever.\n"
                ),
                description=f"Price increase + grandfathering for {name}",
            )

            send_result = await self._kit.send_broadcast(broadcast, tag_id=tag_id)

            bumped.append({
                "product_id": product_id,
                "slug": slug,
                "old_price": old_price,
                "new_price": new_price,
                "signups": signups,
                "broadcast_sent": send_result.get("success", False),
            })

            log.info(
                "data_agent.price_bumped",
                product=slug,
                old_price=old_price,
                new_price=new_price,
                signups=signups,
            )

        await self.record_action(
            action_type="check_price_trigger",
            payload={"products_checked": len(products)},
            result={"bumped_count": len(bumped), "bumped": bumped},
            success=True,
        )
        if bumped:
            await self.remember(
                f"Price bumped for {len(bumped)} products: "
                + ", ".join(
                    f"{b['slug']} ${b['old_price']:.0f}\u2192${b['new_price']:.0f}"
                    for b in bumped
                )
            )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="check_price_trigger",
            output={"bumped": bumped, "checked": len(products)},
            actions_taken=["check_price_triggers", "send_grandfathering_broadcasts"],
        )

    # ── Kit subscriber count ─────────────────────────────────────────
    async def _get_kit_subscriber_count(self, slug: str) -> int:
        """
        Fetch the number of Kit subscribers tagged with this product's slug.
        Returns 0 if the tag doesn't exist or the API call fails.
        This represents real email leads collected by GrowthAgent.
        """
        api_key = settings.KIT_API_KEY
        base = settings.KIT_API_BASE.rstrip("/")
        if not api_key or not slug:
            return 0
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                # List all tags and find the one matching this product slug
                resp = await client.get(
                    f"{base}/tags",
                    params={"api_key": api_key},
                )
                if resp.status_code != 200:
                    return 0
                tags = resp.json().get("tags", [])
                tag_id: Optional[int] = None
                for tag in tags:
                    if tag.get("name", "").lower() in (
                        slug.lower(), f"acai-{slug.lower()}", slug.lower().replace("-", "_")
                    ):
                        tag_id = tag["id"]
                        break
                if not tag_id:
                    return 0
                # Get subscriber count for this tag
                sub_resp = await client.get(
                    f"{base}/tags/{tag_id}/subscriptions",
                    params={"api_key": api_key},
                )
                if sub_resp.status_code != 200:
                    return 0
                data = sub_resp.json()
                # Kit returns total_subscriptions or a list
                return int(
                    data.get("total_subscriptions", 0)
                    or len(data.get("subscriptions", []))
                )
        except Exception as exc:
            log.debug("data_agent.kit_count_failed", slug=slug, error=str(exc))
            return 0

    # ── Visitor count fetch ───────────────────────────────────────────
    async def _fetch_visitor_count(self, product: dict) -> int:
        """
        Attempt to fetch real visitor count from the deployed app's /metrics endpoint.
        Falls back to 0 if unavailable.
        """
        deploy_url = product.get("deploy_url")
        if not deploy_url:
            return 0
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{deploy_url}/metrics")
                if resp.status_code == 200:
                    data = resp.json()
                    return int(data.get("visitors_today", 0))
        except Exception:
            pass
        return 0
