"""
BaseAgent — abstract parent class for all autonomous agents.

Provides:
  - Shared LLM client with AUTOMATIC MODEL ROTATION (quota-aware)
  - Memory access (vector + structured)
  - Action recording
  - Status management in Redis
  - Retry decorator
  - Standardised result type
"""

from __future__ import annotations

import asyncio
import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from openai import AsyncOpenAI
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from core.config import settings
from core.logger import get_logger
from core.redis_client import set_agent_status
from memory.structured_memory import StructuredMemory
from memory.vector_memory import VectorMemory
from models.action import ActionStatus

log = get_logger(__name__)

# ── Model rotation pool ────────────────────────────────────────────────────────
# Priority order: best/fastest first. When a model hits quota (429), it is
# temporarily blacklisted for 3600s (1 hour) then auto-recovered at reset.
#
# Providers:
#   mistral:* → Mistral API (api.mistral.ai) — no daily RPD cap, very fast
#   gemini:*  → Google Gemini endpoint — 1000 RPD free (resets midnight PDT)
#   gemma:*   → Google open-weight on Gemini endpoint — no RPD cap, fallback
_MODEL_POOL: list[str] = [
    "mistral:ministral-8b-latest",   # #1 — fast, smart, no quota cap
    "mistral:mistral-small-latest",  # #2 — very capable, no quota cap
    "mistral:open-mistral-nemo",     # #3 — open-weight, reliable fallback
    "gemini:gemini-2.0-flash-lite",  # #4 — 1000 RPD (best when available)
    "gemini:gemini-2.5-flash-lite",  # #5 — 1000 RPD
    "gemini:gemini-2.0-flash",       # #6 — more capable Gemini
    "gemma:gemma-3-27b-it",          # #7 — open-weight large
    "gemma:gemma-3-4b-it",           # #8 — emergency fallback
    "gemma:gemma-3-1b-it",           # #9 — last resort
]
_model_blacklist: dict[str, float] = {}    # model -> epoch time when blacklisted
_MODEL_BLACKLIST_TTL: float = 3600.0       # re-try blacklisted model after 1h
_model_rotation_lock: asyncio.Lock = asyncio.Lock()
_active_model: str = _MODEL_POOL[0]        # starts with top-priority model


def _parse_model_entry(entry: str) -> tuple[str, str]:
    """Split 'provider:model_name' into (provider, model_name)."""
    if ":" in entry:
        provider, model = entry.split(":", 1)
        return provider, model
    return "gemini", entry  # legacy fallback


async def _get_active_model() -> str:
    """Return the best available (non-blacklisted) model from the pool."""
    global _active_model
    async with _model_rotation_lock:
        now = time.time()
        # Recover models whose blacklist TTL has expired
        recovered = [m for m, t in list(_model_blacklist.items()) if now - t > _MODEL_BLACKLIST_TTL]
        for m in recovered:
            del _model_blacklist[m]
            log.info("model_rotation.recovered", model=m)

        # Find first non-blacklisted model in priority order
        for model in _MODEL_POOL:
            if model not in _model_blacklist:
                if model != _active_model:
                    log.info("model_rotation.switched", from_model=_active_model, to_model=model)
                    _active_model = model
                return model

        # All models are blacklisted — wait for the oldest to recover
        oldest_blacklist = min(_model_blacklist.values())
        wait_s = max(10, _MODEL_BLACKLIST_TTL - (now - oldest_blacklist)) + 5
        log.warning("model_rotation.all_exhausted", waiting_s=round(wait_s, 0))
    # Sleep outside the lock to avoid deadlock
    await asyncio.sleep(wait_s)
    async with _model_rotation_lock:
        oldest_model = min(_model_blacklist, key=_model_blacklist.get)
        del _model_blacklist[oldest_model]
        _active_model = oldest_model
        return oldest_model


async def _blacklist_model(model: str) -> None:
    """Mark a model as quota-exhausted for _MODEL_BLACKLIST_TTL seconds."""
    async with _model_rotation_lock:
        if model not in _model_blacklist:
            log.warning("model_rotation.blacklisted", model=model)
            _model_blacklist[model] = time.time()


# ── Global LLM rate limiter ───────────────────────────────────────────────────
# Serialise all LLM calls with a minimum 10-second gap to stay under RPM caps.
_llm_rate_lock: asyncio.Lock = asyncio.Lock()
_llm_last_call_at: float = 0.0
_LLM_MIN_INTERVAL: float = 10.0  # seconds between consecutive LLM calls


async def _throttle_llm() -> None:
    """Acquire the global rate-limit token before every LLM call."""
    global _llm_last_call_at
    async with _llm_rate_lock:
        now = time.monotonic()
        wait = _LLM_MIN_INTERVAL - (now - _llm_last_call_at)
        if wait > 0:
            log.debug("rate_limiter.waiting", wait_s=round(wait, 1))
            await asyncio.sleep(wait)
        _llm_last_call_at = time.monotonic()


@dataclass
class AgentResult:
    """Standardised return type for all agent execute() calls."""

    success: bool
    agent: str
    task_type: str
    output: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    duration_ms: int = 0
    actions_taken: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "agent": self.agent,
            "task_type": self.task_type,
            "output": self.output,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "actions_taken": self.actions_taken,
        }


class BaseAgent(ABC):
    """
    Abstract base for all autonomous agents.

    Subclasses must implement:
        execute(task: dict) -> AgentResult
    """

    name: str = "base"

    def __init__(self) -> None:
        # Gemini client (OpenAI-compatible)
        self._gemini_client = AsyncOpenAI(
            api_key=settings.OPENAI_API_KEY,
            base_url=settings.OPENAI_BASE_URL or None,
        )
        # Mistral client (also OpenAI-compatible)
        self._mistral_client = AsyncOpenAI(
            api_key=getattr(settings, "MISTRAL_API_KEY", ""),
            base_url="https://api.mistral.ai/v1",
        )
        self.model = _MODEL_POOL[0]  # tracks active model entry (provider:name)
        self.vector_memory = VectorMemory()
        self.structured_memory = StructuredMemory()
        self._log = get_logger(f"agent.{self.name}")

    def _get_client(self, model_entry: str) -> tuple[AsyncOpenAI, str]:
        """Return (client, bare_model_name) for a provider:model entry."""
        provider, model_name = _parse_model_entry(model_entry)
        if provider == "mistral":
            return self._mistral_client, model_name
        # gemini or gemma both use the Gemini endpoint
        return self._gemini_client, model_name

    @property
    def llm(self) -> AsyncOpenAI:
        """Compatibility alias — returns the primary LLM client."""
        if settings.MISTRAL_API_KEY:
            return self._mistral_client
        return self._gemini_client

    # ── Abstract interface ────────────────────────────────────────────
    @abstractmethod
    async def execute(self, task: dict[str, Any]) -> AgentResult:
        """
        Execute the given task and return an AgentResult.
        task dict must contain at minimum: task_type, instruction, product_id.
        """

    # ── LLM helpers ───────────────────────────────────────────────────

    @staticmethod
    def _extract_json_object(text: str) -> Any:
        """Robustly extract the first complete JSON value (object OR array) from text.

        Handles:
        - Markdown code fences (```json ... ```)
        - Leading/trailing prose
        - Multiple JSON values (takes only the first)
        - Properly matched braces/brackets via depth-counting
        Returns a dict, list, or raises ValueError.
        """
        # Strip markdown fences first
        text = text.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(
                line for line in lines if not line.strip().startswith("```")
            ).strip()

        # Find the first opening brace or bracket
        obj_start = text.find("{")
        arr_start = text.find("[")

        if obj_start == -1 and arr_start == -1:
            raise ValueError("No JSON value found in response")

        # Pick whichever comes first
        if obj_start == -1:
            start = arr_start
            open_ch, close_ch = "[", "]"
        elif arr_start == -1:
            start = obj_start
            open_ch, close_ch = "{", "}"
        elif obj_start < arr_start:
            start = obj_start
            open_ch, close_ch = "{", "}"
        else:
            start = arr_start
            open_ch, close_ch = "[", "]"

        # Walk from start, counting depth to find exact end
        depth = 0
        in_string = False
        escape_next = False
        for i, ch in enumerate(text[start:], start):
            if escape_next:
                escape_next = False
                continue
            if ch == "\\" and in_string:
                escape_next = True
                continue
            if ch == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    return json.loads(text[start : i + 1])

        raise ValueError("Incomplete JSON value — unmatched braces/brackets")

    # ── Provider compatibility ───────────────────────────────────────────
    @staticmethod
    def _build_messages(system: str, user: str, model_entry: str) -> list[dict]:
        """Build message list compatible with all providers.

        - Gemma models do NOT support the 'system' role — merge into user.
        - Mistral and Gemini both support system role natively.
        """
        _, model_name = _parse_model_entry(model_entry)
        if model_name.startswith("gemma-"):
            # Gemma only supports 'user'/'model' roles
            merged = f"[INSTRUCTIONS]\n{system}\n\n[REQUEST]\n{user}"
            return [{"role": "user", "content": merged}]
        return [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

    async def chat(
        self,
        system: str,
        user: str,
        temperature: float = 0.5,
        max_tokens: int = 2000,
        json_mode: bool = False,
    ) -> str:
        """Single-turn LLM call with automatic model rotation on quota errors."""
        base_kwargs: dict[str, Any] = {
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        # Note: json_mode response_format is only added for Gemini models

        # Try each available model in rotation order (up to full pool size)
        for _attempt in range(len(_MODEL_POOL) + 1):
            model_entry = await _get_active_model()  # e.g. 'mistral:ministral-8b-latest'
            client, model_name = self._get_client(model_entry)
            _, bare_name = _parse_model_entry(model_entry)
            kwargs = dict(base_kwargs)
            kwargs["model"] = model_name
            kwargs["messages"] = self._build_messages(system, user, model_entry)
            if json_mode and not bare_name.startswith("gemma-"):
                kwargs["response_format"] = {"type": "json_object"}
            await _throttle_llm()
            try:
                response = await client.chat.completions.create(**kwargs)
                self.model = model_entry  # track active model entry
                return response.choices[0].message.content.strip()
            except Exception as exc:
                status = getattr(getattr(exc, "response", None), "status_code", None)
                err_str = str(exc)
                if status == 429 or "RESOURCE_EXHAUSTED" in err_str or "quota" in err_str.lower():
                    log.warning("base_agent.quota_exhausted", model=model_entry)
                    await _blacklist_model(model_entry)
                    continue
                elif "Developer instruction is not enabled" in err_str or "INVALID_ARGUMENT" in err_str:
                    log.warning("base_agent.system_role_unsupported", model=model_entry)
                    await _blacklist_model(model_entry)
                    continue
                elif status in (503, 529, 500):
                    log.warning("base_agent.transient_error", model=model_entry, status=status)
                    await asyncio.sleep(20)
                    continue
                raise

        raise RuntimeError("LLM call failed — all models in pool exhausted")

    async def chat_json(
        self,
        system: str,
        user: str,
        temperature: float = 0.4,
        max_tokens: int = 2000,
    ) -> dict[str, Any]:
        """LLM call that returns a parsed JSON dict.

        Uses prompt engineering instead of response_format so it works with
        any model (including those that don't support the JSON mode parameter).
        """
        json_system = (
            system
            + "\n\nCRITICAL: Your entire response MUST be a single valid JSON "
            "object. No markdown fences, no code blocks, no explanation — "
            "only the raw JSON object starting with { and ending with }."
        )
        raw = await self.chat(
            system=json_system,
            user=user,
            temperature=temperature,
            max_tokens=max_tokens,
            json_mode=False,  # Prompt-based JSON; avoids response_format compat issues
        )

        try:
            return self._extract_json_object(raw)
        except (json.JSONDecodeError, ValueError):
            # One retry with a simpler, shorter prompt
            log.warning("base_agent.json_parse_retry", snippet=raw[:80])
            retry_model = await _get_active_model()
            retry_client, retry_model_name = self._get_client(retry_model)
            msgs = self._build_messages(
                "Output ONLY valid JSON. No text outside the JSON object.",
                f"Fix this broken JSON and return only the corrected version:\n{raw[:1500]}",
                retry_model,
            )
            await _throttle_llm()
            retry_resp = await retry_client.chat.completions.create(
                model=retry_model_name,
                messages=msgs,
                max_tokens=1500,
                temperature=0.1,
            )
            fixed = retry_resp.choices[0].message.content.strip()
            return self._extract_json_object(fixed)

    # ── Memory helpers ────────────────────────────────────────────────
    async def remember(
        self,
        content: str,
        product_id: Optional[str] = None,
        extra_meta: Optional[dict] = None,
    ) -> None:
        """Store an experience in vector memory."""
        try:
            await self.vector_memory.store_experience(
                agent_name=self.name,
                content=content,
                product_id=product_id,
                extra_meta=extra_meta,
            )
        except Exception as e:
            self._log.warning("agent.memory_store_failed", error=str(e))

    async def recall(
        self, query: str, product_id: Optional[str] = None, n: int = 3
    ) -> str:
        """Retrieve relevant past memories as a context block."""
        try:
            return await self.vector_memory.build_context_block(
                query=query,
                agent_name=self.name,
                product_id=product_id,
            )
        except Exception as e:
            self._log.warning("agent.memory_recall_failed", error=str(e))
            return ""

    # ── Action recording ──────────────────────────────────────────────
    async def record_action(
        self,
        action_type: str,
        payload: Optional[dict] = None,
        result: Optional[dict] = None,
        product_id: Optional[str] = None,
        task_id: Optional[str] = None,
        success: bool = True,
        error_detail: Optional[str] = None,
    ) -> str:
        """Persist an action to the database and vector memory."""
        action_id = await self.structured_memory.record_action(
            agent_type=self.name,
            action_type=action_type,
            payload=payload,
            result=result,
            product_id=product_id,
            task_id=task_id,
            status=ActionStatus.SUCCESS if success else ActionStatus.FAILURE,
            error_detail=error_detail,
        )
        # Also store in vector memory for semantic retrieval
        result_summary = json.dumps(result)[:200] if result else "no result"
        await self.vector_memory.store_action(
            agent_name=self.name,
            action_description=f"{action_type}: {json.dumps(payload)[:200] if payload else ''}",
            result_summary=result_summary,
            product_id=product_id,
            success=success,
        )
        return action_id

    # ── Status management ─────────────────────────────────────────────
    async def set_status(self, status: str) -> None:
        try:
            await set_agent_status(self.name, status)
        except Exception:
            pass  # Redis may not be available; non-fatal

    # ── Timed execution wrapper ───────────────────────────────────────
    async def run(self, task: dict[str, Any]) -> AgentResult:
        """
        Wrapper around execute() that:
        - Sets Redis status to 'running'
        - Times execution
        - Catches and logs exceptions
        - Resets Redis status
        """
        await self.set_status("running")
        start = time.monotonic()
        try:
            self._log.info(
                "agent.started",
                task_type=task.get("task_type", "unknown"),
                product_id=task.get("product_id"),
            )
            result = await self.execute(task)
            elapsed = int((time.monotonic() - start) * 1000)
            result.duration_ms = elapsed
            self._log.info(
                "agent.completed",
                task_type=task.get("task_type"),
                duration_ms=elapsed,
                success=result.success,
            )
            await self.set_status("idle")
            return result
        except Exception as exc:
            elapsed = int((time.monotonic() - start) * 1000)
            self._log.error(
                "agent.error",
                task_type=task.get("task_type"),
                error=str(exc),
                exc_info=True,
            )
            await self.set_status("error")
            return AgentResult(
                success=False,
                agent=self.name,
                task_type=task.get("task_type", "unknown"),
                error=str(exc),
                duration_ms=elapsed,
            )
