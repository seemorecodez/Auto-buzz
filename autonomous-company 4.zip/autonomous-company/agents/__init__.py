"""Agent registry."""
from agents.base import BaseAgent, AgentResult
from agents.meta_agent import MetaAgent
from agents.builder_agent import BuilderAgent
from agents.growth_agent import GrowthAgent
from agents.content_agent import ContentAgent
from agents.monetization_agent import MonetizationAgent
from agents.data_agent import DataAgent
from agents.operator_agent import OperatorAgent

AGENT_REGISTRY: dict[str, type[BaseAgent]] = {
    "meta": MetaAgent,
    "builder": BuilderAgent,
    "growth": GrowthAgent,
    "content": ContentAgent,
    "monetization": MonetizationAgent,
    "data": DataAgent,
    "operator": OperatorAgent,
}

__all__ = [
    "BaseAgent", "AgentResult",
    "MetaAgent", "BuilderAgent", "GrowthAgent", "ContentAgent",
    "MonetizationAgent", "DataAgent", "OperatorAgent",
    "AGENT_REGISTRY",
]
