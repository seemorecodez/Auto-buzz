"""
ContentAgent — content creation and distribution.

Responsibilities:
  1. Generate landing pages
  2. Write SEO blog posts
  3. Create social media content (Twitter/LinkedIn threads)
  4. Generate product documentation
  5. Write email newsletter copy
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agents.base import AgentResult, BaseAgent
from core.logger import get_logger
from tools.deployment import DeploymentTool
from tools.kit_email import KitBroadcast, KitEmailTool
from tools.landing_page import LandingPageTool
from tools.seo import SEOTool

log = get_logger(__name__)


class ContentAgent(BaseAgent):
    """Generates marketing content and landing pages."""

    name = "content"

    def __init__(self) -> None:
        super().__init__()
        self._landing = LandingPageTool()
        self._seo = SEOTool()
        self._deployer = DeploymentTool()
        self._kit = KitEmailTool()

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "generate_landing_page")

        if task_type == "generate_landing_page":
            return await self._generate_landing_page(task)
        elif task_type == "write_blog_post":
            return await self._write_blog_post(task)
        elif task_type == "write_social_content":
            return await self._write_social_content(task)
        elif task_type == "write_docs":
            return await self._write_docs(task)
        elif task_type == "write_newsletter":
            return await self._write_newsletter(task)
        elif task_type == "write_comparison_page":
            return await self._write_comparison_page(task)
        elif task_type == "write_testimonials":
            return await self._write_testimonials(task)
        elif task_type == "write_ph_kit":
            return await self._write_ph_kit(task)
        elif task_type == "write_ab_variant":
            return await self._write_ab_variant(task)
        elif task_type == "write_seo_blog_post":
            return await self._write_seo_blog_post(task)
        elif task_type == "write_changelog":
            return await self._write_changelog(task)
        else:
            return await self._generate_landing_page(task)

    # ── Landing Page ──────────────────────────────────────────────────
    async def _generate_landing_page(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="generate_landing_page",
                error="Product not found",
            )

        result = await self._landing.generate(
            product_name=product["name"],
            product_description=product["description"] or "",
            niche=product["niche"],
            target_audience=product["target_audience"] or "",
            value_proposition=product["value_proposition"] or "",
            price_monthly=product.get("price_monthly"),
        )

        # Store the landing page URL on the product
        await self.structured_memory.update_product_field(
            product_id,
            landing_page_url=f"file://{result['output_path']}",
        )
        await self.record_action(
            action_type="generate_landing_page",
            payload={"product_id": product_id},
            result={"output_path": result["output_path"]},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated landing page for {product['name']} at {result['output_path']}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="generate_landing_page",
            output={
                "output_path": result["output_path"],
                "output_dir": result["output_dir"],
                "headline": result["copy"].get("headline", ""),
            },
            actions_taken=["generate_landing_page_html"],
        )

    # ── Blog Post ─────────────────────────────────────────────────────
    async def _write_blog_post(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        topic = task.get("topic") or task.get("instruction", "")
        product = await self.structured_memory.get_product_by_id(product_id)

        product_context = ""
        if product:
            product_context = (
                f"Product: {product['name']}\n"
                f"Niche: {product['niche']}\n"
                f"Target audience: {product['target_audience']}"
            )

        post_data = await self.chat_json(
            system=(
                "You are an expert content marketer and SEO specialist. "
                "Write a complete, long-form blog post that ranks for target keywords "
                "and builds trust with the target audience. "
                "Return JSON: {\"title\": \"...\", \"slug\": \"...\", "
                "\"meta_description\": \"...\", \"keywords\": [...], "
                "\"content_markdown\": \"...\", \"word_count\": 1200}"
            ),
            user=(
                f"Topic: {topic}\n\n"
                f"{product_context}\n\n"
                "Write a 1,200-word blog post optimised for organic search. "
                "Include H2/H3 headings, a compelling intro, and a CTA at the end."
            ),
            temperature=0.7,
            max_tokens=4000,
        )

        await self.record_action(
            action_type="write_blog_post",
            payload={"topic": topic[:200], "product_id": product_id},
            result={"title": post_data.get("title", ""), "word_count": post_data.get("word_count", 0)},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Wrote blog post for {product['name'] if product else 'system'}: "
            f"'{post_data.get('title', '')}'",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_blog_post",
            output=post_data,
            actions_taken=["write_seo_blog_post"],
        )

    # ── Social Content ────────────────────────────────────────────────
    async def _write_social_content(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        platform = task.get("platform", "twitter")
        product = await self.structured_memory.get_product_by_id(product_id)

        product_info = json.dumps(product or {}, indent=2)

        content_data = await self.chat_json(
            system=(
                f"You are a viral {platform} content creator for SaaS founders. "
                "Write engaging posts that build an audience and drive traffic. "
                "Return JSON: {\"posts\": [{\"content\": \"...\", "
                "\"type\": \"thread|single\", \"hashtags\": [...]}]}"
            ),
            user=(
                f"Create 5 {platform} posts for this product:\n\n{product_info}\n\n"
                "Mix: 1 product announcement, 1 pain point post, "
                "1 educational, 1 social proof, 1 controversial take."
            ),
            temperature=0.8,
            max_tokens=2000,
        )

        await self.record_action(
            action_type="write_social_content",
            payload={"platform": platform, "product_id": product_id},
            result={"post_count": len(content_data.get("posts", []))},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_social_content",
            output=content_data,
            actions_taken=[f"write_{platform}_posts"],
        )

    # ── Documentation ─────────────────────────────────────────────────
    async def _write_docs(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_docs",
                error="Product not found",
            )

        docs = await self.chat(
            system=(
                "You are a technical writer. Write clear, comprehensive documentation "
                "for a SaaS product. Include: Overview, Quick Start, Features, API Reference, "
                "FAQ, and Support sections."
            ),
            user=(
                f"Write full documentation for {product['name']}.\n\n"
                f"Description: {product['description']}\n"
                f"Features listed: {product.get('value_proposition', '')}\n"
                f"Target users: {product['target_audience']}"
            ),
            temperature=0.3,
            max_tokens=4000,
        )

        await self.record_action(
            action_type="write_documentation",
            payload={"product_id": product_id},
            result={"doc_length": len(docs)},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_docs",
            output={"documentation": docs, "length": len(docs)},
            actions_taken=["write_product_docs"],
        )

    # ── Comparison Page ──────────────────────────────────────────────
    async def _write_comparison_page(self, task: dict[str, Any]) -> AgentResult:
        """Generate and deploy a competitor comparison page."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_comparison_page",
                error="Product not found",
            )

        from slugify import slugify  # type: ignore
        product_slug = slugify(product["name"])

        instruction = task.get("instruction", "")
        # Extract competitor name from instruction or use a generic default.
        # The instruction may be a full sentence like "write a comparison page eg ContractCraft vs DocuSign..."
        # Pull the explicit competitor from task["competitor"] first, then try to parse instruction.
        competitor_name = task.get("competitor", "").strip()
        if not competitor_name:
            # Try to extract a short name from the instruction — look for " vs " pattern
            import re as _re
            vs_match = _re.search(r"\bvs[\s.]+([A-Za-z][A-Za-z0-9 ]{1,30})", instruction, _re.IGNORECASE)
            if vs_match:
                competitor_name = vs_match.group(1).strip().rstrip(".,;:")
        if not competitor_name:
            # Map known niches to typical competitors
            _niche_competitors = {
                "Legal Tech": "DocuSign",
                "HR Tech": "Greenhouse",
                "Customer Experience": "Zendesk",
                "Startup Productivity": "Pitch",
                "SMB FinTech": "QuickBooks",
            }
            competitor_name = _niche_competitors.get(product.get("niche", ""), "Competitor")

        our_advantages = [
            product.get("value_proposition") or "Better performance",
            "Lower price",
            "Superior support",
            "Easier onboarding",
        ]

        deploy_url = product.get("deploy_url") or "#signup"
        cta_url = deploy_url if deploy_url.startswith("http") else "#signup"

        result = await self._seo.generate_comparison_page(
            product_name=product["name"],
            product_slug=product_slug,
            niche=product["niche"],
            competitor_name=competitor_name,
            our_advantages=our_advantages,
            cta_url=cta_url,
        )

        # Deploy the product directory (which now includes the comparison page)
        from tools.seo import _slugify
        competitor_slug = _slugify(competitor_name)
        source_dir = f"/tmp/acai_pages/{product_slug}"
        # Cap project name at 32 chars to avoid Vercel API errors
        vs_project_name = f"{product['name'][:14]}-vs-{competitor_name[:12]}"
        deploy_result = await self._deployer.deploy(
            source_dir=source_dir,
            project_name=vs_project_name,
        )

        comparison_url = deploy_result.url or result["path"]

        await self.record_action(
            action_type="write_comparison_page",
            payload={"product_id": product_id, "competitor": competitor_name},
            result={"path": result["path"], "url": comparison_url},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated comparison page '{result['title']}' vs {competitor_name} at {comparison_url}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_comparison_page",
            output={
                "comparison_url": comparison_url,
                "path": result["path"],
                "title": result["title"],
                "competitor": competitor_name,
            },
            actions_taken=["generate_comparison_page", "deploy"],
        )

    # ── Testimonials ──────────────────────────────────────────────────
    async def _write_testimonials(self, task: dict[str, Any]) -> AgentResult:
        """Generate realistic testimonials and an embeddable HTML snippet."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_testimonials",
                error="Product not found",
            )

        from slugify import slugify  # type: ignore
        product_slug = slugify(product["name"])

        testimonials_data = await self.chat_json(
            system=(
                "You are a UX researcher and copywriter. "
                "Generate realistic, believable testimonials from real-sounding users. "
                "Return JSON: {\"testimonials\": [{\"name\": \"...\", \"title\": \"...\", "
                "\"company\": \"...\", \"quote\": \"...\", \"result_metric\": \"...\"}, ...]}"
            ),
            user=(
                f"Generate 5 realistic testimonials for {product['name']}.\n"
                f"Niche: {product['niche']}\n"
                f"Target audience: {product['target_audience']}\n"
                f"Value proposition: {product.get('value_proposition', '')}\n\n"
                "Each testimonial must include a specific result metric (e.g. '42% more leads', "
                "'saved 10 hours/week'). Use diverse, realistic names and roles."
            ),
            temperature=0.8,
            max_tokens=2000,
        )

        testimonials = testimonials_data.get("testimonials", [])

        # Build HTML snippet
        cards_html = "".join(
            f'<div class="testimonial-card" style="background:#1e293b;border-radius:12px;'
            f'padding:1.5rem;margin-bottom:1rem;">'
            f'<p style="font-style:italic;color:#94a3b8;margin:0 0 0.75rem;">&ldquo;{t.get("quote","")}&rdquo;</p>'
            f'<strong style="color:#e2e8f0;">{t.get("name","")}</strong><br/>'
            f'<span style="color:#64748b;font-size:0.9rem;">{t.get("title","")} at {t.get("company","")}</span><br/>'
            f'<span style="color:#34d399;font-size:0.85rem;font-weight:600;">&#8599; {t.get("result_metric","")}</span>'
            f'</div>'
            for t in testimonials
        )
        html_snippet = (
            f'<section class="testimonials" style="max-width:800px;margin:0 auto;padding:2rem 1rem;">'
            f'<h2 style="text-align:center;margin-bottom:1.5rem;">What Our Users Say</h2>'
            f'{cards_html}'
            f'</section>'
        )

        # Persist
        out_dir = Path(f"/tmp/acai_pages/{product_slug}")
        out_dir.mkdir(parents=True, exist_ok=True)
        testimonials_path = out_dir / "testimonials.json"
        testimonials_path.write_text(
            json.dumps({"testimonials": testimonials, "html_snippet": html_snippet}, indent=2),
            encoding="utf-8",
        )

        await self.record_action(
            action_type="write_testimonials",
            payload={"product_id": product_id},
            result={"count": len(testimonials), "path": str(testimonials_path)},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated {len(testimonials)} testimonials for {product['name']}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_testimonials",
            output={
                "testimonials": testimonials,
                "html_snippet": html_snippet,
                "path": str(testimonials_path),
            },
            actions_taken=["generate_testimonials"],
        )

    # ── Product Hunt Kit ──────────────────────────────────────────────
    async def _write_ph_kit(self, task: dict[str, Any]) -> AgentResult:
        """Generate a complete Product Hunt launch kit."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_ph_kit",
                error="Product not found",
            )

        deploy_url = product.get("deploy_url") or ""

        kit = await self._seo.generate_ph_kit(
            product_name=product["name"],
            product_description=product.get("description") or "",
            tagline=product.get("value_proposition") or product["name"],
            value_prop=product.get("value_proposition") or "",
            target_audience=product.get("target_audience") or "",
            deploy_url=deploy_url,
        )

        await self.record_action(
            action_type="write_ph_kit",
            payload={"product_id": product_id},
            result={"tagline": kit.get("tagline", "")},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated Product Hunt kit for {product['name']}: '{kit.get('tagline', '')}'.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_ph_kit",
            output=kit,
            actions_taken=["generate_ph_kit"],
        )

    # ── A/B Variant ───────────────────────────────────────────────────
    async def _write_ab_variant(self, task: dict[str, Any]) -> AgentResult:
        """Generate an alternative landing page variant (ROI vs pain-point focus) and deploy it."""
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_ab_variant",
                error="Product not found",
            )

        from slugify import slugify  # type: ignore
        product_slug = slugify(product["name"])

        variant_data = await self.chat_json(
            system=(
                "You are an expert conversion rate optimiser. "
                "Generate an alternative landing page variant using an ROI-focused approach "
                "(contrasting with the default pain-point-focused approach). "
                "Return JSON: {\"headline\": \"...\", \"subheadline\": \"...\", "
                "\"cta_label\": \"...\", \"hero_body\": \"...\", "
                "\"benefits\": [{\"icon\": \"...\", \"title\": \"...\", \"stat\": \"...\"}], "
                "\"social_proof\": \"...\"}"
            ),
            user=(
                f"Product: {product['name']}\n"
                f"Description: {product.get('description', '')}\n"
                f"Niche: {product['niche']}\n"
                f"Target audience: {product.get('target_audience', '')}\n"
                f"Value proposition: {product.get('value_proposition', '')}\n\n"
                "Create an ROI-focused variant: lead with specific numbers, ROI metrics, "
                "and quantified benefits. 3-5 benefit items with stats."
            ),
            temperature=0.75,
            max_tokens=2000,
        )

        headline = variant_data.get("headline", f"Grow Faster with {product['name']}")
        subheadline = variant_data.get("subheadline", "")
        cta_label = variant_data.get("cta_label", "Calculate My ROI")
        hero_body = variant_data.get("hero_body", "")
        benefits = variant_data.get("benefits", [])
        social_proof = variant_data.get("social_proof", "")
        deploy_url = product.get("deploy_url") or "#signup"
        cta_url = deploy_url if deploy_url.startswith("http") else "#signup"

        benefits_html = "".join(
            f'<div class="benefit">'
            f'<span class="icon">{b.get("icon", "📈")}</span>'
            f'<h3>{b.get("title", "")}</h3>'
            f'<p class="stat">{b.get("stat", "")}</p>'
            f'</div>'
            for b in benefits
        )

        import datetime as _dt
        year = _dt.datetime.now().year

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>{headline} | {product['name']}</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{ font-family: 'Inter', sans-serif; background: #0f172a; color: #f8fafc; margin: 0; }}
    .hero {{
      background: linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%);
      padding: 6rem 1.5rem 5rem;
      text-align: center;
    }}
    .hero h1 {{ font-size: 3rem; font-weight: 900; margin: 0 0 1rem; line-height: 1.15; }}
    .hero p {{ font-size: 1.25rem; opacity: 0.9; max-width: 620px; margin: 0 auto 0.75rem; }}
    .hero .body {{ font-size: 1rem; opacity: 0.75; max-width: 560px; margin: 0 auto 2rem; }}
    .cta-btn {{
      display: inline-block;
      background: #fff;
      color: #0ea5e9;
      font-weight: 800;
      font-size: 1.15rem;
      padding: 1rem 2.75rem;
      border-radius: 10px;
      text-decoration: none;
      margin-bottom: 1rem;
    }}
    .proof {{ margin-top: 1.5rem; opacity: 0.7; font-size: 0.9rem; }}
    .benefits {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      max-width: 900px;
      margin: 4rem auto;
      padding: 0 1.5rem;
    }}
    .benefit {{
      background: #1e293b;
      border-radius: 12px;
      padding: 1.5rem;
      text-align: center;
    }}
    .benefit .icon {{ font-size: 2rem; display: block; margin-bottom: 0.5rem; }}
    .benefit h3 {{ margin: 0 0 0.4rem; color: #e2e8f0; }}
    .benefit .stat {{ color: #38bdf8; font-weight: 700; font-size: 1.1rem; margin: 0; }}
    footer {{ text-align: center; padding: 2rem; color: #475569; font-size: 0.85rem; }}
  </style>
</head>
<body>
  <div class="hero">
    <h1>{headline}</h1>
    <p>{subheadline}</p>
    <p class="body">{hero_body}</p>
    <a href="{cta_url}" class="cta-btn">{cta_label}</a>
    <p class="proof">{social_proof}</p>
  </div>
  <div class="benefits">{benefits_html}</div>
  <footer>&copy; {year} {product['name']}. All rights reserved.</footer>
</body>
</html>"""

        out_dir = Path(f"/tmp/acai_pages/{product_slug}")
        out_dir.mkdir(parents=True, exist_ok=True)
        variant_path = out_dir / "index_b.html"
        variant_path.write_text(html, encoding="utf-8")

        # Deploy as separate Vercel project
        deploy_result = await self._deployer.deploy(
            source_dir=str(out_dir),
            project_name=f"{product['name']}-variant-b",
        )
        variant_url = deploy_result.url or str(variant_path)

        await self.record_action(
            action_type="write_ab_variant",
            payload={"product_id": product_id, "variant": "B"},
            result={"path": str(variant_path), "url": variant_url},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Generated A/B variant B for {product['name']} at {variant_url}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_ab_variant",
            output={
                "variant_url": variant_url,
                "path": str(variant_path),
                "headline": headline,
            },
            actions_taken=["generate_ab_variant", "deploy_variant_b"],
        )

    # ── SEO Blog Post (with JSON-LD + deploy) ─────────────────────────
    async def _write_seo_blog_post(self, task: dict[str, Any]) -> AgentResult:
        """Generate a full HTML blog post with JSON-LD schema and deploy it."""
        product_id = task.get("product_id")
        keyword_hint = task.get("instruction") or task.get("topic", "")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False, agent=self.name, task_type="write_seo_blog_post",
                error="Product not found",
            )

        from slugify import slugify  # type: ignore
        product_slug = slugify(product["name"])

        # Generate blog post HTML
        post = await self._seo.generate_blog_post(
            product_name=product["name"],
            niche=product["niche"],
            target_audience=product.get("target_audience") or "",
            keyword_hint=keyword_hint,
        )

        # Generate JSON-LD and inject into the blog post
        deploy_url = product.get("deploy_url") or ""
        json_ld = await self._seo.generate_json_ld(
            product_name=product["name"],
            description=product.get("description") or "",
            url=deploy_url,
            price_monthly=product.get("price_monthly"),
        )

        html_path = Path(post["html_path"])
        original_html = html_path.read_text(encoding="utf-8")
        # Inject JSON-LD before </head>
        enriched_html = original_html.replace("</head>", f"{json_ld}\n</head>", 1)
        html_path.write_text(enriched_html, encoding="utf-8")

        # Deploy the entire blog directory
        blog_dir = str(html_path.parent)
        deploy_result = await self._deployer.deploy(
            source_dir=blog_dir,
            project_name=f"{product['name']}-blog",
        )
        blog_url = deploy_result.url or post["html_path"]

        await self.record_action(
            action_type="write_seo_blog_post",
            payload={"product_id": product_id, "keyword_hint": keyword_hint[:200]},
            result={"title": post["title"], "word_count": post["word_count"], "url": blog_url},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Published SEO blog post '{post['title']}' for {product['name']} at {blog_url}.",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_seo_blog_post",
            output={
                "title": post["title"],
                "slug": post["slug"],
                "word_count": post["word_count"],
                "html_path": post["html_path"],
                "blog_url": blog_url,
            },
            actions_taken=["generate_blog_post", "inject_json_ld", "deploy_blog"],
        )

    # ── Newsletter ────────────────────────────────────────────────────
    async def _write_newsletter(self, task: dict[str, Any]) -> AgentResult:
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)

        newsletter_data = await self.chat_json(
            system=(
                "You are a newsletter writer for SaaS products. "
                "Write a compelling product update / launch newsletter. "
                "Return JSON: {\"subject\": \"...\", \"preview_text\": \"...\", "
                "\"html_content\": \"...\", \"text_content\": \"...\"}"
            ),
            user=(
                f"Write a launch newsletter for {product['name'] if product else 'our product'}.\n"
                f"Product: {json.dumps(product or {}, indent=2)}"
            ),
            temperature=0.7,
            max_tokens=3000,
        )

        await self.record_action(
            action_type="write_newsletter",
            payload={"product_id": product_id},
            result={"subject": newsletter_data.get("subject", "")},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="write_newsletter",
            output=newsletter_data,
            actions_taken=["write_newsletter_email"],
        )

    # ── Weekly Changelog ────────────────────────────────────────────────
    async def _write_changelog(self, task: dict[str, Any]) -> AgentResult:
        """
        Generate a weekly changelog / product update email and send it as a
        Kit broadcast to all product subscribers.
        """
        product_id = task.get("product_id")
        instruction = task.get("instruction", "")
        product = await self.structured_memory.get_product_by_id(product_id)

        # Recall recent actions from vector memory for the past 7 days
        memory_ctx = await self.recall(
            "recent actions features shipped improvements this week",
            product_id=product_id,
        )

        product_name = product["name"] if product else "Product Update"
        deploy_url = (
            (product.get("deploy_url") if product else None)
            or "https://example.com"
        )

        # Generate changelog email via LLM
        changelog_data = await self.chat_json(
            system=(
                "You are a product marketer writing a weekly changelog email. "
                "Write an engaging 'What we shipped this week' update. "
                'Return JSON: {"subject": "...", "content_html": "...", "content_text": "...", '
                '"features": ["...", "..."], "coming_next": ["...", "..."]}'
            ),
            user=(
                f"Product: {product_name}\n"
                f"Recent actions and context:\n{memory_ctx}\n\n"
                f"Additional instruction: {instruction}\n\n"
                "Write a weekly changelog email with:\n"
                "- Engaging subject line (e.g. 'What we shipped this week — [product]')\n"
                "- HTML body with 'What we shipped this week' section (2-4 feature highlights)\n"
                "- 'What's coming next' section (2-3 upcoming features)\n"
                f"- CTA button linking to {deploy_url}\n"
                "- Personal, conversational tone (no corporate speak)"
            ),
            temperature=0.7,
            max_tokens=3000,
        )

        subject = changelog_data.get(
            "subject", f"What we shipped this week \u2014 {product_name}"
        )
        content_html = changelog_data.get("content_html", "")
        content_text = changelog_data.get("content_text", "")

        broadcast = KitBroadcast(
            subject=subject,
            content_html=content_html,
            content_text=content_text,
            description=f"Weekly changelog for {product_name}",
        )

        # Get tag for product subscribers
        tags = await self._kit.list_tags()
        slug = product["slug"] if product else ""
        tag_obj = next(
            (t for t in tags if slug and f"acai-{slug}" in t.get("name", "")), None
        )
        tag_id = tag_obj["id"] if tag_obj else None

        send_result = await self._kit.send_broadcast(broadcast, tag_id=tag_id)
        sent_to_count = 1 if send_result.get("success") else 0

        await self.record_action(
            action_type="write_changelog",
            payload={"product_id": product_id, "subject": subject},
            result={
                "broadcast_id": send_result.get("broadcast_id"),
                "sent_to_count": sent_to_count,
            },
            product_id=product_id,
            success=send_result.get("success", False),
        )
        await self.remember(
            f"Sent weekly changelog for {product_name}: '{subject}'",
            product_id=product_id,
        )

        return AgentResult(
            success=send_result.get("success", False),
            agent=self.name,
            task_type="write_changelog",
            output={
                "subject": subject,
                "sent_to_count": sent_to_count,
                "broadcast_id": send_result.get("broadcast_id"),
                "features": changelog_data.get("features", []),
                "coming_next": changelog_data.get("coming_next", []),
            },
            error=send_result.get("error"),
            actions_taken=["generate_changelog_email", "send_kit_broadcast"],
        )
