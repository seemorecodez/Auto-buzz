"""
MetaAgent — brain of the system.

Responsibilities:
  1. Analyse market gaps and ideate new products
  2. Decompose product goals into agent tasks
  3. Orchestrate and prioritise the task queue
  4. Monitor overall system health and decide what to tackle next
  5. Decide when to pause, pivot, or archive a product
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from sqlalchemy import select

from agents.base import AgentResult, BaseAgent
from core.database import get_db_session
from core.logger import get_logger
from core.redis_client import get_redis
from models.product import Product, ProductStatus
from models.task import AgentType, Task, TaskStatus

log = get_logger(__name__)

MARKET_ANALYSIS_SYSTEM = """
You are a serial entrepreneur and product strategist.
Analyse the current digital market and identify a profitable SaaS niche.
Return ONLY a JSON object with this schema:
{
  "niche": "...",
  "product_name": "...",
  "slug": "...",
  "tagline": "...",
  "description": "...",
  "target_audience": "...",
  "value_proposition": "...",
  "core_features": ["...", "...", "...", "...", "..."],
  "go_to_market_strategy": "...",
  "estimated_price_monthly": 29,
  "estimated_price_annual": 249,
  "tech_stack": "FastAPI + SQLite + Tailwind CSS",
  "why_now": "...",
  "competitive_moat": "..."
}
"""

# ── Hardcoded Product Portfolio ──────────────────────────────────────────────
# 5 high-conviction products in $10B+ up-and-coming markets.
# The system will build ALL FIVE, then shift 100% of effort to growing each
# to 10,000 users. No new products will ever be created beyond these.
PRODUCT_PORTFOLIO: list[dict] = [
    {
        "product_name": "ContractCraft",
        "slug": "contractcraft",
        "niche": "Legal Tech",
        "market_size": "$22B US legal tech market, growing 10%/yr",
        "description": "AI-powered contract drafting for freelancers and SMBs. "
                       "Generate professional contracts in seconds with AI — no lawyer required.",
        "tagline": "Lawyer-quality contracts, minus the lawyer.",
        "target_audience": "Freelancers, consultants, small businesses",
        "value_proposition": "Generate professional contracts in seconds with AI",
        "go_to_market_strategy": "Email outreach to freelancer communities, LinkedIn targeting "
                                "solo consultants, and SEO content around common contract types.",
        "tech_stack": "Static HTML + Mistral AI",
        "price_monthly": 29,
        "price_annual": 290,
        "initial_status": "monetizing",
        "deploy_url": "https://contractcraft-g3t1l5ft4-f88t4ztvbg-8187s-projects.vercel.app",
        "growth_channels": ["freelancer forums", "LinkedIn", "Fiverr community", "Upwork community"],
        "user_target": 10000,
    },
    {
        "product_name": "BuildFlow",
        "slug": "buildflow",
        "niche": "Construction SaaS",
        "market_size": "$15B construction management software market, growing 12%/yr",
        "description": "AI project management and estimating for contractors. "
                       "Run your entire contracting business from one AI-powered app.",
        "tagline": "Your AI-powered job site office.",
        "target_audience": "Independent contractors, small construction companies",
        "value_proposition": "Run your entire contracting business from one AI-powered app",
        "go_to_market_strategy": "Facebook contractor groups, Home Depot pro community, "
                                "YouTube contractor influencer partnerships, Google Ads.",
        "tech_stack": "Static HTML + Mistral AI",
        "price_monthly": 39,
        "price_annual": 390,
        "initial_status": "building",
        "deploy_url": "",
        "growth_channels": ["contractor Facebook groups", "Home Depot pro", "YouTube contractors", "Google Ads"],
        "user_target": 10000,
    },
    {
        "product_name": "CreatorLedger",
        "slug": "creatorledger",
        "niche": "Creator Economy",
        "market_size": "$250B creator economy market, 50M+ active creators globally",
        "description": "Revenue dashboard that unifies all creator income streams. "
                       "See all your creator income in one place.",
        "tagline": "One dashboard for every dollar you earn creating.",
        "target_audience": "YouTubers, Substack writers, podcasters, course creators",
        "value_proposition": "See all your creator income in one place",
        "go_to_market_strategy": "Twitter/X creator community, Substack ecosystem, "
                                "YouTube creator forums, Product Hunt launch.",
        "tech_stack": "Static HTML + Mistral AI",
        "price_monthly": 19,
        "price_annual": 190,
        "initial_status": "building",
        "deploy_url": "",
        "growth_channels": ["Twitter creators", "Substack", "YouTube creator forums", "Product Hunt"],
        "user_target": 10000,
    },
    {
        "product_name": "PitchForge",
        "slug": "pitchforge",
        "niche": "Startup Productivity",
        "market_size": "$15B business productivity software market; 500K+ new startups/yr",
        "description": "AI pitch deck and investor materials generator for startups. "
                       "Generate investor-ready pitch decks in minutes.",
        "tagline": "From idea to investor deck in 10 minutes.",
        "target_audience": "Pre-seed and seed-stage startup founders",
        "value_proposition": "Generate investor-ready pitch decks in minutes",
        "go_to_market_strategy": "Startup accelerator partnerships, Product Hunt, Twitter/X founder "
                                "communities, content on fundraising tips.",
        "tech_stack": "Static HTML + Mistral AI",
        "price_monthly": 24,
        "price_annual": 240,
        "initial_status": "building",
        "deploy_url": "",
        "growth_channels": ["startup accelerators", "Product Hunt", "Twitter founder community", "AngelList"],
        "user_target": 10000,
    },
    {
        "product_name": "AuditMind",
        "slug": "auditmind",
        "niche": "SMB FinTech",
        "market_size": "$50B+ accounting and bookkeeping software market for SMBs",
        "description": "AI bookkeeping and financial audit assistant for small businesses. "
                       "Your AI bookkeeper without the bookkeeper price tag.",
        "tagline": "Your finances, understood in seconds.",
        "target_audience": "Small business owners, solo operators, side hustlers",
        "value_proposition": "Your AI bookkeeper without the bookkeeper price tag",
        "go_to_market_strategy": "QuickBooks and FreshBooks user communities, accounting subreddits, "
                                "outreach to bookkeepers and tax preparers as channel partners.",
        "tech_stack": "Static HTML + Mistral AI",
        "price_monthly": 15,
        "price_annual": 150,
        "initial_status": "building",
        "deploy_url": "",
        "growth_channels": ["accounting communities", "QuickBooks forums", "r/freelance", "r/smallbusiness"],
        "user_target": 10000,
    },
]

# Build-phase task templates: for products in BUILDING / IDEATING status
# Queue these to generate landing pages, build MVPs, and set up payments
BUILD_TASKS_PER_PRODUCT: list[dict] = [
    # -- Core Build ----------------------------------------------------------------
    {"task_type": "generate_landing_page",  "agent_type": "content",      "priority": 10},
    {"task_type": "build_mvp",              "agent_type": "builder",      "priority": 9},
    # -- Payments & Monetization ---------------------------------------------------
    {"task_type": "setup_wallet",           "agent_type": "monetization", "priority": 9},
    {"task_type": "create_checkout_page",   "agent_type": "monetization", "priority": 8},
    {"task_type": "setup_free_trial",       "agent_type": "monetization", "priority": 7},
]

# Growth-mode task templates: for products in MONETIZING / DEPLOYED / GROWING status
# Every loop: queue GROWTH_TASKS_PER_PRODUCT for each product with fewer than 3 pending tasks
GROWTH_TASKS_PER_PRODUCT: list[dict] = [
    # -- Revenue -------------------------------------------------------------------
    {"task_type": "generate_leads",           "agent_type": "growth",       "priority": 9},
    {"task_type": "run_outreach",             "agent_type": "growth",       "priority": 9},
    {"task_type": "send_drip_sequence",       "agent_type": "growth",       "priority": 9},
    {"task_type": "multi_touch_outreach",     "agent_type": "growth",       "priority": 8},
    {"task_type": "create_checkout_page",     "agent_type": "monetization", "priority": 9},
    {"task_type": "add_ltd_tier",             "agent_type": "monetization", "priority": 7},
    # -- SEO & Content Traffic -----------------------------------------------------
    {"task_type": "write_seo_blog_post",      "agent_type": "content",      "priority": 8},
    {"task_type": "write_comparison_page",    "agent_type": "content",      "priority": 7},
    {"task_type": "write_niche_page",         "agent_type": "content",      "priority": 7},
    {"task_type": "write_ph_kit",             "agent_type": "content",      "priority": 6},
    {"task_type": "generate_sitemap",         "agent_type": "builder",      "priority": 6},
    {"task_type": "generate_social_content",  "agent_type": "content",      "priority": 7},
    # -- Conversion ----------------------------------------------------------------
    {"task_type": "add_exit_intent",          "agent_type": "builder",      "priority": 8},
    {"task_type": "add_social_proof",         "agent_type": "builder",      "priority": 8},
    {"task_type": "run_ab_test",              "agent_type": "content",      "priority": 7},
    {"task_type": "expand_features",          "agent_type": "builder",      "priority": 6},
    {"task_type": "score_leads",              "agent_type": "data",         "priority": 7},
    # -- Scale & Retention ---------------------------------------------------------
    {"task_type": "update_changelog",         "agent_type": "content",      "priority": 6},
    {"task_type": "cross_sell",               "agent_type": "growth",       "priority": 7},
    {"task_type": "setup_affiliate",          "agent_type": "growth",       "priority": 6},
    {"task_type": "collect_metrics",          "agent_type": "data",         "priority": 5},
    {"task_type": "generate_revenue_dashboard","agent_type": "data",        "priority": 6},
    {"task_type": "write_testimonials",       "agent_type": "content",      "priority": 5},
]

TASK_DECOMPOSITION_SYSTEM = """
You are a product operations manager.
Given a product spec and its current status, return 2-4 tasks to execute next.

You MUST only use the following agent_type + task_type combinations (no others):

builder:
  - build_mvp               (generate full codebase and deploy)
  - add_feature / add_exit_intent / add_social_proof / expand_features / generate_sitemap
  - deploy_niche_page       (deploy a programmatic niche landing page to Vercel)

content:
  - generate_landing_page / write_blog_post / write_social_content / generate_social_content
  - write_seo_blog_post / write_comparison_page / write_niche_page / write_testimonials
  - write_ph_kit / run_ab_test / update_changelog / write_newsletter

growth:
  - generate_leads / run_outreach / send_broadcast / analyse_growth
  - send_drip_sequence / multi_touch_outreach / score_leads
  - cross_sell / setup_affiliate / launch_affiliate_program

monetization:
  - design_pricing / setup_payments / check_payments / setup_wallet / setup_free_trial
  - create_checkout_page / add_ltd_tier

data:
  - collect_metrics / generate_insights / system_report
  - score_leads / generate_revenue_dashboard / check_price_trigger

operator:
  - health_check / retry_failed_tasks

Return ONLY a JSON object with a "tasks" key:
{
  "tasks": [
    {
      "agent_type": "builder",
      "task_type": "build_mvp",
      "instruction": "Build the full MVP for ...",
      "priority": 9
    }
  ]
}

Priority scale: 10=critical, 7-9=high, 4-6=medium, 1-3=low.
For a product in IDEATING or BUILDING status, prioritise: generate_landing_page -> build_mvp -> setup_wallet -> create_checkout_page.
For MONETIZING products, prioritise: write_seo_blog_post, generate_leads, run_outreach, write_niche_page.
NEVER return a bare array. Always wrap in {"tasks": [...]}.
"""


class MetaAgent(BaseAgent):
    """Orchestrates the entire autonomous company pipeline."""

    name = "meta"

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "orchestrate")

        if task_type == "ideate_product":
            return await self._ideate_product(task)
        elif task_type == "decompose_tasks":
            return await self._decompose_tasks(task)
        elif task_type == "orchestrate":
            return await self._orchestrate(task)
        elif task_type == "evaluate_product":
            return await self._evaluate_product(task)
        else:
            return await self._orchestrate(task)

    # ── Product Ideation ──────────────────────────────────────────────
    async def _ideate_product(self, task: dict[str, Any]) -> AgentResult:
        """
        Pick the next portfolio product not yet in the DB and create its record.
        No LLM ideation — all 5 specs are hardcoded in PRODUCT_PORTFOLIO.
        """
        # Query ALL slugs (including archived) to avoid re-creating any product
        async with get_db_session() as session:
            result = await session.execute(select(Product.slug))
            all_slugs_in_db = {row[0] for row in result.fetchall()}

        next_spec = next(
            (p for p in PRODUCT_PORTFOLIO if p["slug"] not in all_slugs_in_db), None
        )
        if not next_spec:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="ideate_product",
                error="All 5 portfolio products already exist in DB",
            )

        portfolio_index = PRODUCT_PORTFOLIO.index(next_spec) + 1

        async with get_db_session() as session:
            product = Product(
                id=str(uuid.uuid4()),
                name=next_spec["product_name"],
                slug=next_spec["slug"],
                niche=next_spec["niche"],
                description=next_spec["description"],
                tagline=next_spec["tagline"],
                target_audience=next_spec["target_audience"],
                value_proposition=next_spec["value_proposition"],
                go_to_market_strategy=next_spec["go_to_market_strategy"],
                tech_stack=next_spec["tech_stack"],
                price_monthly=float(next_spec["price_monthly"]),
                price_annual=float(next_spec["price_annual"]),
                status=ProductStatus.IDEATING,
            )
            session.add(product)
            await session.flush()
            product_id = product.id

        await self.record_action(
            action_type="ideate_product",
            payload={"niche": next_spec["niche"], "slug": next_spec["slug"]},
            result={"product_id": product_id, "name": next_spec["product_name"]},
            product_id=product_id,
            success=True,
        )
        await self.remember(
            f"Added portfolio product #{portfolio_index}/5: "
            f"{next_spec['product_name']} in niche '{next_spec['niche']}'. "
            f"Market: {next_spec['market_size']}. "
            f"Target: {next_spec['user_target']:,} users at ${next_spec['price_monthly']}/mo.",
            product_id=product_id,
        )
        log.info(
            "meta_agent.portfolio_product_added",
            number=portfolio_index,
            product_id=product_id,
            name=next_spec["product_name"],
            slug=next_spec["slug"],
        )
        return AgentResult(
            success=True,
            agent=self.name,
            task_type="ideate_product",
            output={"product_id": product_id, **next_spec},
            actions_taken=["created_portfolio_product_from_spec"],
        )

    # ── Task Decomposition ────────────────────────────────────────────
    async def _decompose_tasks(self, task: dict[str, Any]) -> AgentResult:
        """
        Given a product_id, generate and enqueue the next batch of tasks.
        """
        product_id = task.get("product_id")
        if not product_id:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="decompose_tasks",
                error="product_id required",
            )

        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="decompose_tasks",
                error=f"Product {product_id} not found",
            )

        memory_ctx = await self.recall(
            f"tasks and actions for product {product['name']}",
            product_id=product_id,
        )

        user_prompt = (
            f"Product spec:\n{json.dumps(product, indent=2)}\n\n"
            f"Memory context:\n{memory_ctx}\n\n"
            f"Current status: {product['status']}\n\n"
            "What are the next 3-5 tasks needed to advance this product? "
            "Consider its current status and what's already been done."
        )

        result: dict[str, Any] = await self.chat_json(
            system=TASK_DECOMPOSITION_SYSTEM,
            user=user_prompt,
            temperature=0.5,
        )
        # Handle both {"tasks": [...]} and bare [...] (some models ignore wrapping)
        if isinstance(result, list):
            tasks_to_create = result
        else:
            tasks_to_create = result.get("tasks", [])

        # Write tasks to database
        created_task_ids: list[str] = []
        async with get_db_session() as session:
            for t in tasks_to_create:
                new_task = Task(
                    id=str(uuid.uuid4()),
                    product_id=product_id,
                    agent_type=AgentType(
                        t["agent_type"].lower().replace(" agent", "").strip()
                    ),
                    task_type=t["task_type"],
                    instruction=t["instruction"],
                    priority=t.get("priority", 5),
                    status=TaskStatus.PENDING,
                )
                session.add(new_task)
                created_task_ids.append(new_task.id)

        await self.record_action(
            action_type="decompose_tasks",
            payload={"product_id": product_id},
            result={"tasks_created": len(created_task_ids)},
            product_id=product_id,
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="decompose_tasks",
            output={
                "product_id": product_id,
                "tasks_created": len(created_task_ids),
                "task_ids": created_task_ids,
            },
            actions_taken=[f"created_{len(created_task_ids)}_tasks"],
        )

    # ── Orchestration ──────────────────────────────────────────────────
    async def _orchestrate(self, task: dict[str, Any]) -> AgentResult:
        """
        Main orchestration loop tick.

        Phase 1 — BUILDING: Create portfolio products one by one; decompose tasks.
        Phase 2 — GROWTH MODE: All 5 portfolio products exist → queue
                   user-acquisition tasks only and track progress toward 10K users.
        """
        products = await self.structured_memory.get_active_products()

        # Check ALL DB slugs (including archived) so we never re-create a product
        async with get_db_session() as session:
            result = await session.execute(select(Product.slug))
            all_slugs_in_db = {row[0] for row in result.fetchall()}

        portfolio_slugs = {p["slug"] for p in PRODUCT_PORTFOLIO}
        remaining_slugs = portfolio_slugs - all_slugs_in_db

        actions_taken: list[str] = []

        if remaining_slugs:
            # ── BUILDING PHASE ──────────────────────────────────────────────
            # Only add the next product if none is currently being ideated/built
            currently_building = [
                p for p in products if p["status"] in ("ideating", "building")
            ]
            if not currently_building:
                ideate_result = await self._ideate_product(
                    {"task_type": "ideate_product"}
                )
                if ideate_result.success:
                    name = ideate_result.output.get("product_name", "")
                    actions_taken.append(f"added_portfolio_product:{name}")
                    await self._decompose_tasks(
                        {
                            "task_type": "decompose_tasks",
                            "product_id": ideate_result.output["product_id"],
                        }
                    )
                    actions_taken.append("decomposed_initial_tasks")

            # Decompose tasks for products that need them
            pending_map = {
                t["product_id"]: True
                for t in await self.structured_memory.get_pending_tasks()
            }
            for product in products:
                if product["id"] not in pending_map:
                    if product["status"] == "ideating":
                        # Stuck ideating with no tasks — queue build_mvp immediately
                        log.info(
                            "meta_agent.rescued_stuck_ideating",
                            product=product["slug"],
                        )
                        await self._decompose_tasks(
                            {
                                "task_type": "decompose_tasks",
                                "product_id": product["id"],
                            }
                        )
                        actions_taken.append(f"rescued_ideating:{product['slug']}")
                    elif product["status"] not in ("archived", "paused"):
                        # Active/building/monetizing product with no pending tasks
                        await self._decompose_tasks(
                            {
                                "task_type": "decompose_tasks",
                                "product_id": product["id"],
                            }
                        )
                        actions_taken.append(f"decomposed_tasks:{product['slug']}")

            built_count = len(portfolio_slugs) - len(remaining_slugs)
            log.info(
                "meta_agent.building_phase",
                built=built_count,
                remaining=len(remaining_slugs),
                next_up=sorted(remaining_slugs)[0] if remaining_slugs else None,
            )
            summary = await self.structured_memory.get_system_summary()
            return AgentResult(
                success=True,
                agent=self.name,
                task_type="orchestrate",
                output={
                    "phase": "building",
                    "portfolio_built": built_count,
                    "portfolio_total": len(portfolio_slugs),
                    "portfolio_remaining": len(remaining_slugs),
                    "remaining_slugs": sorted(remaining_slugs),
                    "summary": summary,
                },
                actions_taken=actions_taken,
            )

        else:
            # ── GROWTH MODE ─────────────────────────────────────────────────
            log.info(
                "meta_agent.growth_mode_activated",
                products_count=len(products),
            )
            return await self._growth_mode_orchestrate(products)

    # ── Growth Mode ───────────────────────────────────────────────────
    async def _growth_mode_orchestrate(
        self, products: list[dict[str, Any]]
    ) -> AgentResult:
        """
        GROWTH MODE — all 5 portfolio products are live.

        Every loop: queue GROWTH_TASKS_PER_PRODUCT for each product with
                    fewer than 3 pending tasks.
        Every 8th loop: substitute a generate_insights task so the AI
                        reviews strategy and recommends growth adjustments.
        Logs real-time progress toward the 10,000-user target per product.
        """
        actions_taken: list[str] = []

        # Count pending tasks per product
        all_pending = await self.structured_memory.get_pending_tasks(limit=200)
        pending_by_product: dict[str, int] = {}
        for t in all_pending:
            pid = t["product_id"]
            pending_by_product[pid] = pending_by_product.get(pid, 0) + 1

        # Portfolio spec lookup by slug
        portfolio_map = {p["slug"]: p for p in PRODUCT_PORTFOLIO}

        # Persistent loop counter via Redis (degrade gracefully if Redis is down)
        loop_count = 0
        try:
            redis = await get_redis()
            loop_count = int(await redis.incr("acai:growth_mode_loop_count") or 1)
        except Exception:
            pass

        progress: list[dict] = []

        # Determine task templates per product status:
        # BUILDING / IDEATING products     -> BUILD_TASKS_PER_PRODUCT
        # MONETIZING / DEPLOYED / GROWING  -> GROWTH_TASKS_PER_PRODUCT
        BUILD_STATUSES = {"building", "ideating"}

        for product in products:
            pid = product["id"]
            slug = product["slug"]
            product_status = product.get("status", "building")
            spec = portfolio_map.get(slug, {})
            user_target = spec.get("user_target", 10000)
            current_signups = product.get("signups", 0)
            pct = round(current_signups / user_target * 100, 1) if user_target else 0
            channels = ", ".join(spec.get("growth_channels", []))

            progress.append(
                {
                    "product": product["name"],
                    "slug": slug,
                    "status": product_status,
                    "signups": current_signups,
                    "target": user_target,
                    "pct_to_goal": pct,
                    "price_monthly": spec.get("price_monthly", 0),
                }
            )
            log.info(
                "meta_agent.growth_progress",
                product=slug,
                status=product_status,
                signups=current_signups,
                target=user_target,
                pct=pct,
            )

            # Select task template list based on product status
            if product_status in BUILD_STATUSES:
                task_templates = BUILD_TASKS_PER_PRODUCT
                phase_label = "BUILD"
            else:
                task_templates = GROWTH_TASKS_PER_PRODUCT
                phase_label = "GROWTH"

            # Queue tasks if this product has < 3 pending tasks
            if pending_by_product.get(pid, 0) < 3:
                async with get_db_session() as session:
                    for template in task_templates:
                        # Every 8th loop: upgrade collect_metrics -> generate_insights
                        if (
                            loop_count % 8 == 0
                            and template["task_type"] == "collect_metrics"
                        ):
                            t_type = "generate_insights"
                            a_type = "data"
                            instruction = (
                                f"Analyse {product['name']} growth performance and "
                                f"recommend the top 3 acquisition actions to accelerate "
                                f"toward {user_target:,} users. "
                                f"Current signups: {current_signups:,} ({pct}% of goal). "
                                f"Market: {spec.get('market_size', '')}."
                            )
                            priority = 8
                        else:
                            t_type = template["task_type"]
                            a_type = template["agent_type"]
                            instruction = (
                                f"[{phase_label} MODE] {product['name']} — "
                                f"{t_type.replace('_', ' ')}. "
                                f"Status: {product_status}. "
                                f"Goal: {user_target:,} users | "
                                f"Progress: {current_signups:,} signups ({pct}%). "
                                f"Channels: {channels}. "
                                f"Market: {spec.get('market_size', '')}."
                            )
                            priority = template["priority"]

                        new_task = Task(
                            id=str(uuid.uuid4()),
                            product_id=pid,
                            agent_type=AgentType(a_type),
                            task_type=t_type,
                            instruction=instruction,
                            priority=priority,
                            status=TaskStatus.PENDING,
                        )
                        session.add(new_task)

                actions_taken.append(f"queued_{phase_label.lower()}_tasks:{slug}")

        # Every 32nd loop: queue price trigger check
        if loop_count % 32 == 0:
            async with get_db_session() as session:
                price_task = Task(
                    id=str(uuid.uuid4()),
                    product_id=None,
                    agent_type=AgentType("data"),
                    task_type="check_price_trigger",
                    instruction=(
                        "Check all products for price bump eligibility (>= 100 signups). "
                        "Raise price by $7 and send grandfathering broadcast where applicable."
                    ),
                    priority=9,
                    status=TaskStatus.PENDING,
                )
                session.add(price_task)
            actions_taken.append("queued_check_price_trigger")
        # Every 8th loop (but not 32nd): queue revenue dashboard generation
        elif loop_count % 8 == 0:
            async with get_db_session() as session:
                dashboard_task = Task(
                    id=str(uuid.uuid4()),
                    product_id=None,
                    agent_type=AgentType("data"),
                    task_type="generate_revenue_dashboard",
                    instruction=(
                        "Generate the ACAI revenue dashboard showing all products' MRR, "
                        "daily revenue, signups, and % to $300/day goal. Deploy to Vercel."
                    ),
                    priority=7,
                    status=TaskStatus.PENDING,
                )
                session.add(dashboard_task)
            actions_taken.append("queued_generate_revenue_dashboard")

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="orchestrate",
            output={
                "phase": "growth_mode",
                "loop_count": loop_count,
                "products_count": len(products),
                "progress": progress,
            },
            actions_taken=actions_taken,
        )

    # ── Product Evaluation ────────────────────────────────────────────
    async def _evaluate_product(self, task: dict[str, Any]) -> AgentResult:
        """
        Evaluate whether a product should continue, pivot, or be archived.
        """
        product_id = task.get("product_id")
        product = await self.structured_memory.get_product_by_id(product_id)
        if not product:
            return AgentResult(
                success=False,
                agent=self.name,
                task_type="evaluate_product",
                error="product not found",
            )

        evaluation: dict[str, Any] = await self.chat_json(
            system=(
                "You are a startup advisor evaluating product-market fit. "
                "Based on the product metrics, decide: continue | pivot | archive. "
                'Return JSON: {"decision": "...", "reasoning": "...", "next_actions": [...]}'
            ),
            user=(
                f"Product: {json.dumps(product, indent=2)}\n\n"
                "Should we continue growing this, pivot the approach, "
                "or archive it and move on? Be decisive."
            ),
            temperature=0.3,
        )

        decision = evaluation.get("decision", "continue")
        if decision == "archive":
            await self.structured_memory.update_product_field(
                product_id, status=ProductStatus.ARCHIVED
            )
        elif decision == "pivot":
            await self.structured_memory.update_product_field(
                product_id, status=ProductStatus.IDEATING
            )

        await self.remember(
            f"Evaluated product {product['name']}: decision={decision}. "
            f"Reasoning: {evaluation.get('reasoning', '')}",
            product_id=product_id,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="evaluate_product",
            output=evaluation,
            actions_taken=[f"decision:{decision}"],
        )
