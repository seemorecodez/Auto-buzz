"""
OperatorAgent — system reliability, self-healing, and retries.

Responsibilities:
  1. Monitor task queue health
  2. Retry failed tasks with exponential backoff
  3. Detect and resolve stuck/hung tasks
  4. Monitor deployed products (health checks)
  5. Generate system health reports
  6. Clean up stale data
"""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from sqlalchemy import select, update

from agents.base import AgentResult, BaseAgent
from core.config import settings
from core.database import get_db_session
from core.logger import get_logger
from core.redis_client import get_agent_statuses, get_redis
from models.metric import Metric, MetricType
from models.product import Product, ProductStatus
from models.task import AgentType, Task, TaskStatus

log = get_logger(__name__)


class OperatorAgent(BaseAgent):
    """Maintains system health and manages failure recovery."""

    name = "operator"

    async def execute(self, task: dict[str, Any]) -> AgentResult:
        task_type = task.get("task_type", "health_check")

        if task_type == "health_check":
            return await self._health_check(task)
        elif task_type == "retry_failed_tasks":
            return await self._retry_failed_tasks(task)
        elif task_type == "cleanup_stale":
            return await self._cleanup_stale(task)
        elif task_type == "monitor_deployments":
            return await self._monitor_deployments(task)
        elif task_type == "system_health_report":
            return await self._system_health_report(task)
        else:
            return await self._health_check(task)

    # ── Health Check ──────────────────────────────────────────────────
    async def _health_check(self, task: dict[str, Any]) -> AgentResult:
        """
        Perform a full system health check:
        - Database connectivity
        - Redis connectivity
        - Agent statuses
        - Task queue depth
        - Deployed product pings
        """
        checks: dict[str, Any] = {}
        issues: list[str] = []

        # 1. Database
        try:
            summary = await self.structured_memory.get_system_summary()
            checks["database"] = {"status": "ok", "products": summary["product_counts"]}
        except Exception as e:
            checks["database"] = {"status": "error", "error": str(e)}
            issues.append(f"Database error: {e}")

        # 2. Redis
        try:
            r = await get_redis()
            await r.ping()
            q_len = await r.llen("acai:task_queue")
            agent_statuses = await get_agent_statuses()
            checks["redis"] = {
                "status": "ok",
                "queue_depth": q_len,
                "agent_statuses": agent_statuses,
            }
        except Exception as e:
            checks["redis"] = {"status": "error", "error": str(e)}
            issues.append(f"Redis error: {e}")

        # 3. Task queue health
        try:
            async with get_db_session() as session:
                pending = await session.scalar(
                    __import__("sqlalchemy", fromlist=["select"]).select(
                        __import__("sqlalchemy.sql.functions", fromlist=["count"]).count(Task.id)
                    ).where(Task.status == TaskStatus.PENDING)
                )
                failed = await session.scalar(
                    __import__("sqlalchemy", fromlist=["select"]).select(
                        __import__("sqlalchemy.sql.functions", fromlist=["count"]).count(Task.id)
                    ).where(Task.status == TaskStatus.FAILED)
                )
            checks["task_queue"] = {
                "pending": int(pending or 0),
                "failed": int(failed or 0),
                "status": "ok" if (failed or 0) < 10 else "degraded",
            }
            if (failed or 0) >= 10:
                issues.append(f"High task failure count: {failed}")
        except Exception as e:
            checks["task_queue"] = {"status": "error", "error": str(e)}
            issues.append(f"Task queue check failed: {e}")

        # 4. Deployed products
        ping_results = await self._ping_deployments()
        checks["deployments"] = ping_results
        down_products = [p for p in ping_results if not p.get("alive")]
        if down_products:
            issues.extend([f"Product {p['name']} is down" for p in down_products])

        # Record health metric
        health_score = 100 - (len(issues) * 15)
        health_score = max(0, min(100, health_score))
        try:
            await self.structured_memory.record_metric(
                MetricType.UPTIME_PERCENT,
                float(health_score),
                source="operator_agent",
            )
        except Exception:
            pass

        await self.record_action(
            action_type="health_check",
            payload={},
            result={"health_score": health_score, "issues": issues},
            success=health_score >= 50,  # degraded is ok; critical (<50) is failure
        )

        overall_status = "healthy" if not issues else ("degraded" if len(issues) <= 2 else "critical")
        log.info(
            "operator.health_check_complete",
            status=overall_status,
            issues=len(issues),
            health_score=health_score,
        )

        return AgentResult(
            success=health_score >= 50,  # degraded is ok; critical (<50) is failure
            agent=self.name,
            task_type="health_check",
            output={
                "overall_status": overall_status,
                "health_score": health_score,
                "checks": checks,
                "issues": issues,
                "checked_at": datetime.now(timezone.utc).isoformat(),
            },
            actions_taken=["db_check", "redis_check", "queue_check", "deployment_pings"],
        )

    # ── Retry Failed Tasks ────────────────────────────────────────────
    async def _retry_failed_tasks(self, task: dict[str, Any]) -> AgentResult:
        """
        Find all retryable failed tasks and re-queue them.
        """
        retryable = await self.structured_memory.get_failed_retryable_tasks(
            max_retries=settings.MAX_RETRIES
        )

        retried: list[str] = []
        async with get_db_session() as session:
            for t in retryable:
                result = await session.execute(
                    select(Task).where(Task.id == t["id"])
                )
                db_task = result.scalar_one_or_none()
                if db_task:
                    db_task.status = TaskStatus.PENDING
                    db_task.retry_count += 1
                    db_task.error = None
                    session.add(db_task)
                    retried.append(t["id"])

        log.info("operator.retried_tasks", count=len(retried))
        await self.record_action(
            action_type="retry_failed_tasks",
            payload={"task_count": len(retryable)},
            result={"retried": len(retried)},
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="retry_failed_tasks",
            output={"retried_count": len(retried), "task_ids": retried},
            actions_taken=[f"retried_{len(retried)}_tasks"],
        )

    # ── Cleanup Stale Data ────────────────────────────────────────────
    async def _cleanup_stale(self, task: dict[str, Any]) -> AgentResult:
        """
        Clean up tasks stuck in IN_PROGRESS for too long (>30 min),
        and archive old metrics beyond the retention period.
        """
        cutoff_in_progress = datetime.now(timezone.utc) - timedelta(minutes=30)
        cutoff_metrics = datetime.now(timezone.utc) - timedelta(days=90)

        reset_count = 0
        deleted_metrics = 0

        async with get_db_session() as session:
            # Reset hung IN_PROGRESS tasks to PENDING
            result = await session.execute(
                select(Task).where(
                    Task.status == TaskStatus.IN_PROGRESS,
                    Task.updated_at < cutoff_in_progress,
                )
            )
            hung_tasks = result.scalars().all()
            for t in hung_tasks:
                t.status = TaskStatus.PENDING
                t.error = "Reset by OperatorAgent (stuck in IN_PROGRESS)"
                session.add(t)
                reset_count += 1

            # Delete very old metrics
            old_metrics_result = await session.execute(
                select(Metric).where(Metric.created_at < cutoff_metrics)
            )
            old_metrics = old_metrics_result.scalars().all()
            for m in old_metrics:
                await session.delete(m)
                deleted_metrics += 1

        log.info(
            "operator.cleanup_complete",
            reset_tasks=reset_count,
            deleted_metrics=deleted_metrics,
        )
        await self.record_action(
            action_type="cleanup_stale",
            payload={},
            result={"reset_tasks": reset_count, "deleted_metrics": deleted_metrics},
            success=True,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="cleanup_stale",
            output={
                "hung_tasks_reset": reset_count,
                "old_metrics_deleted": deleted_metrics,
            },
            actions_taken=["reset_hung_tasks", "delete_old_metrics"],
        )

    # ── Monitor Deployments ───────────────────────────────────────────
    async def _monitor_deployments(self, task: dict[str, Any]) -> AgentResult:
        results = await self._ping_deployments()
        down = [r for r in results if not r.get("alive")]

        if down:
            await self.remember(
                f"Products DOWN: {[p['name'] for p in down]}. "
                "Deployment monitoring alert triggered.",
            )

        await self.record_action(
            action_type="monitor_deployments",
            payload={},
            result={"total": len(results), "down": len(down)},
            success=len(down) == 0,
        )

        return AgentResult(
            success=len(down) == 0,
            agent=self.name,
            task_type="monitor_deployments",
            output={"deployments": results, "down_count": len(down)},
            error=f"{len(down)} product(s) unreachable" if down else None,
            actions_taken=["ping_all_deployments"],
        )

    # ── System Health Report ──────────────────────────────────────────
    async def _system_health_report(self, task: dict[str, Any]) -> AgentResult:
        health_result = await self._health_check(task)
        retry_result = await self._retry_failed_tasks(task)
        cleanup_result = await self._cleanup_stale(task)

        report = await self.chat_json(
            system=(
                "You are a site reliability engineer. Produce a concise system health report. "
                "Return JSON: {\"status\": \"healthy|degraded|critical\", "
                "\"summary\": \"...\", \"actions_taken\": [...], "
                "\"recommendations\": [...]}"
            ),
            user=(
                f"Health check: {json.dumps(health_result.output, indent=2)}\n"
                f"Retried tasks: {retry_result.output.get('retried_count', 0)}\n"
                f"Cleanup: {json.dumps(cleanup_result.output, indent=2)}"
            ),
            temperature=0.2,
        )

        return AgentResult(
            success=True,
            agent=self.name,
            task_type="system_health_report",
            output={
                "health": health_result.output,
                "retries": retry_result.output,
                "cleanup": cleanup_result.output,
                "report": report,
            },
            actions_taken=["full_health_check", "retry_failed", "cleanup"],
        )

    # ── Deployment Ping ───────────────────────────────────────────────
    async def _ping_deployments(self) -> list[dict[str, Any]]:
        """Ping all deployed product health endpoints concurrently."""
        products = await self.structured_memory.get_active_products()
        deployed = [
            p for p in products
            if p.get("deploy_url") and p["status"] == ProductStatus.DEPLOYED.value
        ]

        async def ping(product: dict) -> dict[str, Any]:
            url = product["deploy_url"].rstrip("/") + "/health"
            try:
                async with httpx.AsyncClient(timeout=8) as client:
                    resp = await client.get(url)
                    alive = resp.status_code < 500
            except Exception as e:
                alive = False
            return {
                "name": product["name"],
                "url": url,
                "alive": alive,
                "product_id": product["id"],
            }

        if not deployed:
            return []

        results = await asyncio.gather(*[ping(p) for p in deployed], return_exceptions=True)
        return [r for r in results if isinstance(r, dict)]
