"""
Orchestrator — routes tasks to the correct agent and tracks execution.

Responsibilities:
  1. Dequeue tasks from the pending list
  2. Instantiate the appropriate agent
  3. Run the task and capture results
  4. Update task status in the database
  5. Feed results back into the memory system
"""

from __future__ import annotations

import json
import time
from typing import Any

from agents import AGENT_REGISTRY, AgentResult
from agents.base import BaseAgent
from core.database import get_db_session
from core.logger import get_logger
from memory.structured_memory import StructuredMemory
from models.task import AgentType, Task, TaskStatus

log = get_logger(__name__)


class Orchestrator:
    """Routes tasks to agents and manages execution lifecycle."""

    def __init__(self) -> None:
        self._memory = StructuredMemory()
        self._agent_cache: dict[str, BaseAgent] = {}

    def _get_agent(self, agent_type: str) -> BaseAgent:
        """Return a cached agent instance for the given type."""
        if agent_type not in self._agent_cache:
            agent_class = AGENT_REGISTRY.get(agent_type)
            if not agent_class:
                raise ValueError(f"Unknown agent type: {agent_type}")
            self._agent_cache[agent_type] = agent_class()
        return self._agent_cache[agent_type]

    async def run_task(self, task_dict: dict[str, Any]) -> AgentResult:
        """
        Execute a task dict (not necessarily a DB-backed task).
        Used for direct execution from the execution loop.
        """
        agent_type = task_dict.get("agent_type", "meta")
        agent = self._get_agent(agent_type)
        return await agent.run(task_dict)

    async def execute_pending_tasks(
        self,
        limit: int = 10,
        agent_type_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Pull pending tasks from the database, execute them, and record results.
        Returns a list of result summaries.
        """
        agent_type_enum = (
            AgentType(agent_type_filter) if agent_type_filter else None
        )
        pending = await self._memory.get_pending_tasks(
            agent_type=agent_type_enum, limit=limit
        )

        if not pending:
            log.info("orchestrator.no_pending_tasks")
            return []

        log.info("orchestrator.executing_tasks", count=len(pending))
        results: list[dict[str, Any]] = []

        for task_meta in pending:
            task_id = task_meta["id"]
            result = await self._execute_db_task(task_id, task_meta)
            results.append(result)

        return results

    async def _execute_db_task(
        self, task_id: str, task_meta: dict[str, Any]
    ) -> dict[str, Any]:
        """Execute a single DB-backed task and update its status."""
        start = time.monotonic()

        # Mark as IN_PROGRESS
        await self._memory.mark_task_status(task_id, TaskStatus.IN_PROGRESS)

        agent_type = task_meta["agent_type"]
        try:
            agent = self._get_agent(agent_type)
        except ValueError as e:
            await self._memory.mark_task_status(
                task_id, TaskStatus.FAILED, error=str(e)
            )
            return {
                "task_id": task_id,
                "success": False,
                "error": str(e),
            }

        # Build the task payload
        context: dict[str, Any] = {}
        if task_meta.get("context"):
            try:
                context = json.loads(task_meta["context"])
            except (json.JSONDecodeError, TypeError):
                context = {}

        task_payload = {
            "task_type": task_meta["task_type"],
            "instruction": task_meta["instruction"],
            "product_id": task_meta.get("product_id"),
            **context,
        }

        # Execute
        result: AgentResult = await agent.run(task_payload)
        elapsed_ms = int((time.monotonic() - start) * 1000)

        # Update DB
        new_status = TaskStatus.COMPLETED if result.success else TaskStatus.FAILED
        await self._memory.mark_task_status(
            task_id,
            new_status,
            result=json.dumps(result.output) if result.output else None,
            error=result.error,
            duration_ms=elapsed_ms,
        )

        log.info(
            "orchestrator.task_complete",
            task_id=task_id[:8],
            agent=agent_type,
            success=result.success,
            duration_ms=elapsed_ms,
        )

        return {
            "task_id": task_id,
            "agent_type": agent_type,
            "task_type": task_meta["task_type"],
            "success": result.success,
            "duration_ms": elapsed_ms,
            "error": result.error,
            "actions_taken": result.actions_taken,
        }
