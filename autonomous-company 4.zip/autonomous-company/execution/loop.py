"""
ExecutionLoop — the heartbeat of the autonomous company system.

Runs on a configurable interval (default: 5 minutes).
Each tick:
  1. OperatorAgent runs health check + retries
  2. MetaAgent orchestrates (ideation + task decomposition)
  3. Pending tasks are dispatched to their agents
  4. DataAgent collects metrics
  5. Loop sleeps until the next interval

The loop is designed to be resilient: any individual step failure is
logged and skipped without crashing the loop.
"""

from __future__ import annotations

import asyncio
import signal
import sys
from datetime import datetime, timezone
from typing import Optional

from core.config import settings
from core.logger import get_logger
from execution.orchestrator import Orchestrator

log = get_logger(__name__)

_LOOP_INSTANCE: Optional["ExecutionLoop"] = None


def get_loop() -> Optional["ExecutionLoop"]:
    """Return the global ExecutionLoop singleton."""
    return _LOOP_INSTANCE


class ExecutionLoop:
    """
    Autonomous execution loop.

    Usage::

        loop = ExecutionLoop()
        await loop.start()   # blocks forever
        await loop.stop()    # graceful shutdown
    """

    def __init__(self, interval: int = settings.LOOP_INTERVAL_SECONDS) -> None:
        global _LOOP_INSTANCE
        _LOOP_INSTANCE = self

        self.interval = interval
        self._running = False
        self._iteration = 0
        self._orchestrator = Orchestrator()
        self._stop_event = asyncio.Event()

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def iteration(self) -> int:
        return self._iteration

    # ── Lifecycle ─────────────────────────────────────────────────────
    async def start(self) -> None:
        """Start the execution loop. Blocks until stop() is called."""
        self._running = True
        self._stop_event.clear()
        log.info(
            "execution_loop.started",
            interval_seconds=self.interval,
        )

        # Register signal handlers for graceful shutdown
        if sys.platform != "win32":
            loop = asyncio.get_event_loop()
            loop.add_signal_handler(signal.SIGINT, self._handle_signal)
            loop.add_signal_handler(signal.SIGTERM, self._handle_signal)

        while self._running:
            tick_start = datetime.now(timezone.utc)
            self._iteration += 1

            log.info(
                "execution_loop.tick_start",
                iteration=self._iteration,
                timestamp=tick_start.isoformat(),
            )

            try:
                await self._tick()
            except Exception as exc:
                log.error(
                    "execution_loop.tick_error",
                    iteration=self._iteration,
                    error=str(exc),
                    exc_info=True,
                )

            elapsed = (datetime.now(timezone.utc) - tick_start).total_seconds()
            sleep_time = max(0.0, self.interval - elapsed)

            log.info(
                "execution_loop.tick_done",
                iteration=self._iteration,
                elapsed_s=round(elapsed, 2),
                next_in_s=round(sleep_time, 2),
            )

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=sleep_time
                )
                if self._stop_event.is_set():
                    break
            except asyncio.TimeoutError:
                pass  # Normal sleep expiry

        log.info("execution_loop.stopped", total_iterations=self._iteration)

    async def stop(self) -> None:
        """Signal the loop to stop after the current tick completes."""
        self._running = False
        self._stop_event.set()
        log.info("execution_loop.stop_requested")

    def _handle_signal(self) -> None:
        asyncio.create_task(self.stop())

    # ── Single tick ────────────────────────────────────────────────────
    async def _tick(self) -> None:
        """
        One full loop iteration.
        Steps run sequentially; each step catches its own errors.
        """
        # ── Step 1: Operator health check ───────────────────────────
        await self._step_safe(
            "operator_health_check",
            self._orchestrator.run_task,
            {
                "agent_type": "operator",
                "task_type": "health_check",
                "instruction": "Perform system health check and retry failed tasks",
            },
        )

        # ── Step 2: Operator retries ────────────────────────────────
        await self._step_safe(
            "retry_failed_tasks",
            self._orchestrator.run_task,
            {
                "agent_type": "operator",
                "task_type": "retry_failed_tasks",
                "instruction": "Retry all eligible failed tasks",
            },
        )

        # ── Step 3: Meta orchestration ──────────────────────────────
        await self._step_safe(
            "meta_orchestrate",
            self._orchestrator.run_task,
            {
                "agent_type": "meta",
                "task_type": "orchestrate",
                "instruction": "Orchestrate the system: ideate, decompose tasks, plan next steps",
            },
        )

        # ── Step 4: Execute pending tasks ───────────────────────────
        await self._step_safe(
            "execute_pending_tasks",
            self._orchestrator.execute_pending_tasks,
            limit=15,
        )

        # ── Step 5: Data collection ─────────────────────────────────
        await self._step_safe(
            "system_report",
            self._orchestrator.run_task,
            {
                "agent_type": "data",
                "task_type": "system_report",
                "instruction": "Collect metrics and generate system analytics report",
            },
        )

        # ── Step 6: Cleanup ─────────────────────────────────────────
        # Every 12 iterations (~1 hour with 5-minute interval)
        if self._iteration % 12 == 0:
            await self._step_safe(
                "cleanup_stale",
                self._orchestrator.run_task,
                {
                    "agent_type": "operator",
                    "task_type": "cleanup_stale",
                    "instruction": "Clean up stale tasks and old metrics",
                },
            )

    # ── Safe step wrapper ─────────────────────────────────────────────
    async def _step_safe(self, step_name: str, fn, *args, **kwargs) -> None:
        """Run a single step, catching and logging any exceptions."""
        try:
            log.info("execution_loop.step_start", step=step_name)
            result = await fn(*args, **kwargs)
            log.info("execution_loop.step_done", step=step_name)
            return result
        except Exception as exc:
            log.error(
                "execution_loop.step_error",
                step=step_name,
                error=str(exc),
                exc_info=True,
            )

    # ── Manual trigger ─────────────────────────────────────────────────
    async def run_once(self) -> dict:
        """Run a single tick immediately. Used by the API for manual triggers."""
        log.info("execution_loop.manual_run_once")
        tick_start = datetime.now(timezone.utc)
        self._iteration += 1

        errors: list[str] = []
        results: list[dict] = []

        async def capture_step(step_name: str, fn, *args, **kwargs):
            try:
                result = await fn(*args, **kwargs)
                results.append({"step": step_name, "success": True})
                return result
            except Exception as exc:
                errors.append(f"{step_name}: {exc}")
                results.append({"step": step_name, "success": False, "error": str(exc)})

        await capture_step(
            "operator_health", self._orchestrator.run_task,
            {"agent_type": "operator", "task_type": "health_check",
             "instruction": "Health check"},
        )
        await capture_step(
            "meta_orchestrate", self._orchestrator.run_task,
            {"agent_type": "meta", "task_type": "orchestrate",
             "instruction": "Orchestrate and decompose tasks"},
        )
        await capture_step(
            "execute_tasks", self._orchestrator.execute_pending_tasks,
            limit=10,
        )

        elapsed = (datetime.now(timezone.utc) - tick_start).total_seconds()
        return {
            "iteration": self._iteration,
            "elapsed_s": round(elapsed, 2),
            "steps": results,
            "errors": errors,
        }


# ── Entrypoint ────────────────────────────────────────────────────────────────
async def run_loop() -> None:
    """Standalone entrypoint for running the loop as a separate process."""
    from core.database import init_db

    await init_db()
    loop = ExecutionLoop()
    await loop.start()


if __name__ == "__main__":
    asyncio.run(run_loop())
