"""
Async Redis client — singleton pattern with lazy initialization.
Handles task queues, pub/sub, and distributed locks.
"""

from __future__ import annotations

import json
from typing import Any, Optional

import redis.asyncio as aioredis
from redis.asyncio import Redis

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)

_redis_client: Optional[Redis] = None


async def get_redis() -> Redis:
    """Return the singleton async Redis client, creating it if needed."""
    global _redis_client
    if _redis_client is None:
        _redis_client = aioredis.from_url(
            settings.REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
            max_connections=50,
            socket_connect_timeout=5,
            socket_timeout=5,
            retry_on_timeout=True,
        )
        # Verify connectivity
        await _redis_client.ping()
        log.info("redis.connected", url=settings.REDIS_URL)
    return _redis_client


async def close_redis() -> None:
    """Close the Redis connection pool."""
    global _redis_client
    if _redis_client:
        await _redis_client.aclose()
        _redis_client = None
        log.info("redis.connection_closed")


# ── Queue helpers ────────────────────────────────────────────────────────────
TASK_QUEUE_KEY = "acai:task_queue"
RESULT_HASH_KEY = "acai:task_results"
AGENT_STATUS_KEY = "acai:agent_status"
METRICS_STREAM_KEY = "acai:metrics_stream"


async def enqueue_task(task_payload: dict[str, Any]) -> int:
    """Push a JSON-encoded task onto the left end of the queue."""
    r = await get_redis()
    serialized = json.dumps(task_payload)
    length = await r.lpush(TASK_QUEUE_KEY, serialized)
    log.info(
        "redis.task_enqueued",
        task_id=task_payload.get("task_id"),
        queue_length=length,
    )
    return length


async def dequeue_task(timeout: int = 5) -> Optional[dict[str, Any]]:
    """
    Block-pop a task from the right end (FIFO).
    Returns None if no task arrives within *timeout* seconds.
    """
    r = await get_redis()
    result = await r.brpop(TASK_QUEUE_KEY, timeout=timeout)
    if result is None:
        return None
    _, raw = result
    payload = json.loads(raw)
    log.info("redis.task_dequeued", task_id=payload.get("task_id"))
    return payload


async def store_task_result(task_id: str, result: dict[str, Any]) -> None:
    """Persist a task result in the result hash (TTL: 24 h)."""
    r = await get_redis()
    await r.hset(RESULT_HASH_KEY, task_id, json.dumps(result))
    await r.expire(RESULT_HASH_KEY, 86_400)


async def get_task_result(task_id: str) -> Optional[dict[str, Any]]:
    """Retrieve a stored task result by task_id."""
    r = await get_redis()
    raw = await r.hget(RESULT_HASH_KEY, task_id)
    if raw is None:
        return None
    return json.loads(raw)


async def set_agent_status(agent_name: str, status: str) -> None:
    """Record an agent's current status (idle / running / error)."""
    r = await get_redis()
    await r.hset(AGENT_STATUS_KEY, agent_name, status)


async def get_agent_statuses() -> dict[str, str]:
    """Return all agent statuses as a dictionary."""
    r = await get_redis()
    return await r.hgetall(AGENT_STATUS_KEY)


async def publish_metric(metric: dict[str, Any]) -> None:
    """Append a metric event to the Redis stream."""
    r = await get_redis()
    fields = {k: str(v) for k, v in metric.items()}
    await r.xadd(METRICS_STREAM_KEY, fields, maxlen=10_000, approximate=True)


async def acquire_lock(key: str, ttl: int = 30) -> bool:
    """
    Attempt to acquire a distributed lock.
    Returns True if the lock was acquired, False otherwise.
    """
    r = await get_redis()
    lock_key = f"acai:lock:{key}"
    acquired = await r.set(lock_key, "1", nx=True, ex=ttl)
    return bool(acquired)


async def release_lock(key: str) -> None:
    """Release a previously acquired distributed lock."""
    r = await get_redis()
    await r.delete(f"acai:lock:{key}")
