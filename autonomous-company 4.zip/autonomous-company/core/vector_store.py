"""
ChromaDB vector store wrapper.
Provides semantic search over agent memory, past actions, and strategies.

Runs in embedded (persistent) mode — no separate ChromaDB server required.
All data is persisted to CHROMA_PERSIST_DIR (default: /tmp/acai_chroma).
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
from typing import Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)

_client: Optional[chromadb.PersistentClient] = None

CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "/tmp/acai_chroma")


async def get_chroma() -> chromadb.PersistentClient:
    """Return the singleton ChromaDB embedded client (no server needed)."""
    global _client
    if _client is None:
        os.makedirs(CHROMA_PERSIST_DIR, exist_ok=True)
        _client = chromadb.PersistentClient(
            path=CHROMA_PERSIST_DIR,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        log.info("chromadb.embedded", path=CHROMA_PERSIST_DIR)
    return _client


# ── Collection names ─────────────────────────────────────────────────────────
MEMORY_COLLECTION = "agent_memory"
STRATEGY_COLLECTION = "strategies"
ACTION_COLLECTION = "past_actions"


async def _get_or_create_collection(
    name: str,
) -> chromadb.Collection:
    """Return a collection using ChromaDB's built-in local embedding function."""
    client = await get_chroma()
    # Uses the local all-MiniLM-L6-v2 model — no API key required
    return await asyncio.to_thread(
        client.get_or_create_collection,
        name,
        metadata={"hnsw:space": "cosine"},
    )


async def embed_texts(texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings locally via ChromaDB's sentence-transformer model.
    Falls back to OpenAI embeddings if EMBEDDING_MODEL is not 'local'.
    """
    if settings.EMBEDDING_MODEL == "local":
        # Use ChromaDB's default local embedding function (all-MiniLM-L6-v2)
        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
        ef = DefaultEmbeddingFunction()
        return await asyncio.to_thread(ef, texts)

    # Non-local: call OpenAI-compatible embeddings endpoint
    from openai import AsyncOpenAI
    client = AsyncOpenAI(
        api_key=settings.OPENAI_API_KEY,
        base_url=settings.OPENAI_BASE_URL or None,
    )
    response = await client.embeddings.create(
        model=settings.EMBEDDING_MODEL,
        input=texts,
    )
    return [item.embedding for item in response.data]


def _make_id(text: str) -> str:
    """Deterministic document ID from content hash."""
    return hashlib.sha256(text.encode()).hexdigest()[:16]


# ── Public API ───────────────────────────────────────────────────────────────
async def upsert_memory(
    collection_name: str,
    documents: list[str],
    metadatas: list[dict[str, Any]],
    ids: Optional[list[str]] = None,
) -> None:
    """Embed and upsert documents into the specified collection."""
    if not documents:
        return

    collection = await _get_or_create_collection(collection_name)
    doc_ids = ids or [_make_id(d) for d in documents]

    # Sanitise metadata: ChromaDB only accepts str/int/float/bool values
    clean_meta = []
    for m in metadatas:
        clean_meta.append(
            {
                k: (json.dumps(v) if isinstance(v, (dict, list)) else v)
                for k, v in m.items()
            }
        )

    if settings.EMBEDDING_MODEL == "local":
        # Let ChromaDB embed locally — no API call needed
        await asyncio.to_thread(
            collection.upsert,
            ids=doc_ids,
            documents=documents,
            metadatas=clean_meta,
        )
    else:
        embeddings = await embed_texts(documents)
        await asyncio.to_thread(
            collection.upsert,
            ids=doc_ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=clean_meta,
        )
    log.info(
        "vector_store.upserted",
        collection=collection_name,
        count=len(documents),
    )


async def query_memory(
    collection_name: str,
    query_text: str,
    n_results: int = 5,
    where: Optional[dict] = None,
) -> list[dict[str, Any]]:
    """
    Semantic search over a collection.
    Returns a list of {document, metadata, distance} dicts.
    """
    collection = await _get_or_create_collection(collection_name)

    if settings.EMBEDDING_MODEL == "local":
        # ChromaDB queries by text directly using its local model
        kwargs: dict[str, Any] = {
            "query_texts": [query_text],
            "n_results": n_results,
            "include": ["documents", "metadatas", "distances"],
        }
    else:
        query_embedding = await embed_texts([query_text])
        kwargs = {
            "query_embeddings": query_embedding,
            "n_results": n_results,
            "include": ["documents", "metadatas", "distances"],
        }

    if where:
        kwargs["where"] = where

    results = await asyncio.to_thread(collection.query, **kwargs)

    output: list[dict[str, Any]] = []
    if not results["documents"]:
        return output

    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        output.append({"document": doc, "metadata": meta, "distance": dist})

    return output


async def delete_from_collection(collection_name: str, ids: list[str]) -> None:
    """Remove documents by ID."""
    collection = await _get_or_create_collection(collection_name)
    await asyncio.to_thread(collection.delete, ids=ids)
    log.info("vector_store.deleted", collection=collection_name, ids=ids)
