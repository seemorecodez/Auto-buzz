"""
core/llm.py — Shared LLM client factory.

All tools and agents should use get_llm_client() instead of creating
their own AsyncOpenAI instances. This ensures Mistral is always tried
first (no RPD quota cap), with Gemini as automatic fallback.
"""
from __future__ import annotations

import os
from openai import AsyncOpenAI
from core.config import settings


# ── Cached clients ─────────────────────────────────────────────────────────────
_mistral_client: AsyncOpenAI | None = None
_gemini_client: AsyncOpenAI | None = None


def get_mistral_client() -> AsyncOpenAI:
    """Return the Mistral client (primary — no daily quota cap)."""
    global _mistral_client
    if _mistral_client is None:
        _mistral_client = AsyncOpenAI(
            api_key=settings.MISTRAL_API_KEY,
            base_url="https://api.mistral.ai/v1",
        )
    return _mistral_client


def get_gemini_client() -> AsyncOpenAI:
    """Return the Gemini client (fallback — 1000 RPD free quota)."""
    global _gemini_client
    if _gemini_client is None:
        _gemini_client = AsyncOpenAI(
            api_key=settings.OPENAI_API_KEY,
            base_url=settings.OPENAI_BASE_URL or None,
        )
    return _gemini_client


def get_llm_client() -> AsyncOpenAI:
    """Return the best available LLM client.
    
    Prefers Mistral (no quota cap). Falls back to Gemini if Mistral key missing.
    """
    if settings.MISTRAL_API_KEY:
        return get_mistral_client()
    return get_gemini_client()


def get_primary_model() -> str:
    """Return the model name to use with get_llm_client()."""
    if settings.MISTRAL_API_KEY:
        return "ministral-8b-latest"
    return settings.OPENAI_MODEL


def get_fallback_model() -> str:
    """Secondary model if primary fails."""
    if settings.MISTRAL_API_KEY:
        return "mistral-small-latest"
    return "gemma-3-27b-it"
