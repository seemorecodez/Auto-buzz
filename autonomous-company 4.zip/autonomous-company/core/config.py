"""
Central configuration — reads from environment / .env file.
All settings are validated at startup via Pydantic.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True,
    )

    # ── PostgreSQL ──────────────────────────────────────────────────
    POSTGRES_HOST: str = "postgres"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "autonomous_company"
    POSTGRES_USER: str = "acai"
    POSTGRES_PASSWORD: str = "acai_password"

    @property
    def DATABASE_URL(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    @property
    def SYNC_DATABASE_URL(self) -> str:
        return (
            f"postgresql+psycopg2://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    # ── Redis ───────────────────────────────────────────────────────
    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379

    @property
    def REDIS_URL(self) -> str:
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/0"

    @property
    def CELERY_BROKER_URL(self) -> str:
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/1"

    @property
    def CELERY_RESULT_BACKEND(self) -> str:
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/2"

    # ── ChromaDB ────────────────────────────────────────────────────
    CHROMA_HOST: str = "chromadb"
    CHROMA_PORT: int = 8001

    # ── LLM (primary: Gemini via OpenAI-compatible endpoint) ────────────────
    OPENAI_API_KEY: str = "sk-placeholder"
    OPENAI_BASE_URL: Optional[str] = None   # None = use provider default
    OPENAI_MODEL: str = "gemini-2.0-flash-lite"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    # ── Mistral AI (secondary LLM — no RPD quota cap) ─────────────────────
    MISTRAL_API_KEY: str = ""

    # ── API Server ──────────────────────────────────────────────────
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    SECRET_KEY: str = "change-this-to-a-random-32-char-string"

    # ── Deployment ──────────────────────────────────────────────────
    DEPLOY_PROVIDER: str = "vercel"
    VERCEL_TOKEN: Optional[str] = None
    RAILWAY_TOKEN: Optional[str] = None
    FLY_API_TOKEN: Optional[str] = None

    # ── Kit (ConvertKit) Email ──────────────────────────────────────
    KIT_API_KEY: Optional[str] = None
    KIT_API_SECRET: Optional[str] = None
    KIT_API_BASE: str = "https://api.convertkit.com/v3"
    FROM_NAME: str = "Autonomous Company AI"

    # ── Cryptocurrency Payments (replaces Stripe) ────────────────────
    CRYPTO_NETWORK: str = "mainnet"     # mainnet | sepolia (testnet)
    CRYPTO_MASTER_MNEMONIC: Optional[str] = None
    ETHERSCAN_API_KEY: Optional[str] = None

    # ── Growth APIs ─────────────────────────────────────────────────
    HUNTER_API_KEY: Optional[str] = None
    APOLLO_API_KEY: Optional[str] = None
    TWITTER_BEARER_TOKEN: Optional[str] = None

    # ── Execution Loop ──────────────────────────────────────────────
    LOOP_INTERVAL_SECONDS: int = 900
    MAX_RETRIES: int = 3
    MAX_PRODUCTS: int = 5


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings: Settings = get_settings()
