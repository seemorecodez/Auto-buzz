"""Core infrastructure package."""
