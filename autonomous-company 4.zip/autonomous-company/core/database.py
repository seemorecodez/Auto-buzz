"""
Async SQLAlchemy engine, session factory, and dependency injection.
Uses asyncpg driver for PostgreSQL.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

from core.config import settings
from core.logger import get_logger

log = get_logger(__name__)

# ── Engine ───────────────────────────────────────────────────────────────────
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    pool_timeout=30,
    pool_recycle=1800,
)

# ── Session factory ──────────────────────────────────────────────────────────
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


# ── Context-manager helper ───────────────────────────────────────────────────
@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Provides an async session with automatic commit/rollback.

    Usage::

        async with get_db_session() as session:
            session.add(obj)
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── FastAPI dependency ───────────────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency — yields a database session per request."""
    async with get_db_session() as session:
        yield session


# ── Startup / Shutdown ───────────────────────────────────────────────────────
async def init_db() -> None:
    """Import all models and create tables (used in dev; prod uses Alembic)."""
    # Import here to ensure all models are registered with Base.metadata
    from models.base import Base  # noqa: F401
    import models.product  # noqa: F401
    import models.task  # noqa: F401
    import models.metric  # noqa: F401
    import models.action  # noqa: F401

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("database.tables_created")


async def close_db() -> None:
    """Dispose the engine connection pool on shutdown."""
    await engine.dispose()
    log.info("database.connection_pool_disposed")
