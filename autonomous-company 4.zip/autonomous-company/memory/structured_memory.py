"""
StructuredMemory — read/write agent state and history from PostgreSQL.

Complements VectorMemory with precise structured queries:
- Fetch product performance timelines
- Retrieve task success rates per agent
- Surface actionable signals for the execution loop
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db_session
from core.logger import get_logger
from models.action import Action, ActionStatus
from models.metric import Metric, MetricType
from models.product import Product, ProductStatus
from models.task import AgentType, Task, TaskStatus

log = get_logger(__name__)


class StructuredMemory:
    """
    Provides structured queries over PostgreSQL for agent decision-making.
    Each method opens its own session via context manager.
    """

    # ── Products ──────────────────────────────────────────────────────
    async def get_active_products(self) -> list[dict[str, Any]]:
        """Return all products that are not archived or paused."""
        async with get_db_session() as session:
            result = await session.execute(
                select(Product).where(
                    Product.status.notin_(
                        [ProductStatus.ARCHIVED, ProductStatus.PAUSED]
                    )
                )
            )
            products = result.scalars().all()
            return [self._product_to_dict(p) for p in products]

    async def get_product_by_id(self, product_id: str) -> Optional[dict[str, Any]]:
        async with get_db_session() as session:
            result = await session.execute(
                select(Product).where(Product.id == product_id)
            )
            p = result.scalar_one_or_none()
            return self._product_to_dict(p) if p else None

    async def get_product_by_slug(self, slug: str) -> Optional[dict[str, Any]]:
        async with get_db_session() as session:
            result = await session.execute(
                select(Product).where(Product.slug == slug)
            )
            p = result.scalar_one_or_none()
            return self._product_to_dict(p) if p else None

    async def update_product_field(
        self, product_id: str, **kwargs: Any
    ) -> None:
        """Update arbitrary product fields by keyword arguments."""
        async with get_db_session() as session:
            result = await session.execute(
                select(Product).where(Product.id == product_id)
            )
            product = result.scalar_one_or_none()
            if product:
                for k, v in kwargs.items():
                    setattr(product, k, v)
                product.updated_at = datetime.now(timezone.utc)
                session.add(product)

    # ── Tasks ─────────────────────────────────────────────────────────
    async def get_pending_tasks(
        self, agent_type: Optional[AgentType] = None, limit: int = 20
    ) -> list[dict[str, Any]]:
        async with get_db_session() as session:
            q = select(Task).where(
                Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED])
            )
            if agent_type:
                q = q.where(Task.agent_type == agent_type)
            q = q.order_by(Task.priority.desc(), Task.created_at.asc()).limit(limit)
            result = await session.execute(q)
            tasks = result.scalars().all()
            return [self._task_to_dict(t) for t in tasks]

    async def get_failed_retryable_tasks(
        self, max_retries: int = 3
    ) -> list[dict[str, Any]]:
        """Return failed tasks that have not exceeded max_retries."""
        async with get_db_session() as session:
            result = await session.execute(
                select(Task).where(
                    Task.status == TaskStatus.FAILED,
                    Task.retry_count < max_retries,
                )
            )
            tasks = result.scalars().all()
            return [self._task_to_dict(t) for t in tasks]

    async def mark_task_status(
        self,
        task_id: str,
        status: TaskStatus,
        result: Optional[str] = None,
        error: Optional[str] = None,
        duration_ms: Optional[int] = None,
    ) -> None:
        async with get_db_session() as session:
            q = await session.execute(select(Task).where(Task.id == task_id))
            task = q.scalar_one_or_none()
            if task:
                task.status = status
                if result is not None:
                    task.result = result
                if error is not None:
                    task.error = error
                if duration_ms is not None:
                    task.duration_ms = duration_ms
                task.updated_at = datetime.now(timezone.utc)
                session.add(task)

    # ── Metrics ───────────────────────────────────────────────────────
    async def record_metric(
        self,
        metric_type: MetricType,
        value: float,
        product_id: Optional[str] = None,
        source: str = "system",
        notes: Optional[str] = None,
    ) -> None:
        async with get_db_session() as session:
            metric = Metric(
                product_id=product_id,
                metric_type=metric_type,
                value=value,
                source=source,
                notes=notes,
            )
            session.add(metric)

    async def get_metric_history(
        self,
        metric_type: MetricType,
        product_id: Optional[str] = None,
        days: int = 30,
    ) -> list[dict[str, Any]]:
        """Return metric time series for the past N days."""
        since = datetime.now(timezone.utc) - timedelta(days=days)
        async with get_db_session() as session:
            q = select(Metric).where(
                Metric.metric_type == metric_type,
                Metric.created_at >= since,
            )
            if product_id:
                q = q.where(Metric.product_id == product_id)
            q = q.order_by(Metric.created_at.asc())
            result = await session.execute(q)
            metrics = result.scalars().all()
            return [
                {
                    "value": m.value,
                    "recorded_at": m.created_at.isoformat(),
                    "source": m.source,
                }
                for m in metrics
            ]

    async def get_latest_metric(
        self,
        metric_type: MetricType,
        product_id: Optional[str] = None,
    ) -> Optional[float]:
        async with get_db_session() as session:
            q = (
                select(Metric)
                .where(Metric.metric_type == metric_type)
                .order_by(Metric.created_at.desc())
                .limit(1)
            )
            if product_id:
                q = q.where(Metric.product_id == product_id)
            result = await session.execute(q)
            m = result.scalar_one_or_none()
            return m.value if m else None

    # ── Actions ───────────────────────────────────────────────────────
    async def record_action(
        self,
        agent_type: str,
        action_type: str,
        payload: Optional[dict] = None,
        result: Optional[dict] = None,
        product_id: Optional[str] = None,
        task_id: Optional[str] = None,
        status: ActionStatus = ActionStatus.SUCCESS,
        external_id: Optional[str] = None,
        error_detail: Optional[str] = None,
    ) -> str:
        """Persist an action record and return its ID."""
        import json
        async with get_db_session() as session:
            action = Action(
                agent_type=agent_type,
                action_type=action_type,
                payload=json.dumps(payload) if payload else None,
                result=json.dumps(result) if result else None,
                product_id=product_id,
                task_id=task_id,
                status=status,
                external_id=external_id,
                error_detail=error_detail,
            )
            session.add(action)
            await session.flush()
            return action.id

    async def get_agent_success_rate(
        self, agent_type: str, days: int = 7
    ) -> float:
        """Calculate success rate for an agent over the past N days."""
        since = datetime.now(timezone.utc) - timedelta(days=days)
        async with get_db_session() as session:
            total = await session.scalar(
                select(func.count(Action.id)).where(
                    Action.agent_type == agent_type,
                    Action.created_at >= since,
                )
            )
            if not total:
                return 1.0
            success = await session.scalar(
                select(func.count(Action.id)).where(
                    Action.agent_type == agent_type,
                    Action.status == ActionStatus.SUCCESS,
                    Action.created_at >= since,
                )
            )
            return round((success or 0) / total, 4)

    # ── System summary ────────────────────────────────────────────────
    async def get_system_summary(self) -> dict[str, Any]:
        """Return a high-level system summary for the MetaAgent."""
        async with get_db_session() as session:
            product_counts: dict[str, int] = {}
            for status in ProductStatus:
                count = await session.scalar(
                    select(func.count(Product.id)).where(
                        Product.status == status
                    )
                )
                product_counts[status.value] = count or 0

            total_revenue = await session.scalar(
                select(func.sum(Product.total_revenue))
            )
            total_customers = await session.scalar(
                select(func.sum(Product.paid_customers))
            )
            pending_tasks = await session.scalar(
                select(func.count(Task.id)).where(
                    Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED])
                )
            )
            failed_tasks = await session.scalar(
                select(func.count(Task.id)).where(
                    Task.status == TaskStatus.FAILED
                )
            )

        return {
            "product_counts": product_counts,
            "total_revenue_usd": float(total_revenue or 0),
            "total_paid_customers": int(total_customers or 0),
            "pending_tasks": int(pending_tasks or 0),
            "failed_tasks": int(failed_tasks or 0),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # ── Serialisers ───────────────────────────────────────────────────
    @staticmethod
    def _product_to_dict(p: Product) -> dict[str, Any]:
        return {
            "id": p.id,
            "name": p.name,
            "slug": p.slug,
            "niche": p.niche,
            "description": p.description,
            "tagline": p.tagline,
            "status": p.status.value,
            "landing_page_url": p.landing_page_url,
            "repo_url": p.repo_url,
            "deploy_url": p.deploy_url,
            "stripe_product_id": p.stripe_product_id,
            "stripe_price_id": p.stripe_price_id,
            "mrr": p.mrr,
            "arr": p.arr,
            "total_revenue": p.total_revenue,
            "price_monthly": p.price_monthly,
            "price_annual": p.price_annual,
            "visitors": p.visitors,
            "signups": p.signups,
            "paid_customers": p.paid_customers,
            "churn_rate": p.churn_rate,
            "target_audience": p.target_audience,
            "value_proposition": p.value_proposition,
            "go_to_market_strategy": p.go_to_market_strategy,
            "tech_stack": p.tech_stack,
            "created_at": p.created_at.isoformat() if p.created_at else None,
            "updated_at": p.updated_at.isoformat() if p.updated_at else None,
        }

    @staticmethod
    def _task_to_dict(t: Task) -> dict[str, Any]:
        return {
            "id": t.id,
            "product_id": t.product_id,
            "agent_type": t.agent_type.value,
            "task_type": t.task_type,
            "priority": t.priority,
            "instruction": t.instruction,
            "context": t.context,
            "result": t.result,
            "error": t.error,
            "status": t.status.value,
            "retry_count": t.retry_count,
            "duration_ms": t.duration_ms,
            "created_at": t.created_at.isoformat() if t.created_at else None,
        }
