"""
VectorMemory — semantic storage and retrieval using ChromaDB.

Agents write experiences, strategies, and observations here.
Retrieval feeds into future LLM prompts to give agents long-term context.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

from core.logger import get_logger
from core.vector_store import (
    ACTION_COLLECTION,
    MEMORY_COLLECTION,
    STRATEGY_COLLECTION,
    query_memory,
    upsert_memory,
)

log = get_logger(__name__)


class VectorMemory:
    """
    High-level interface for agent memory operations.
    All agents share the same underlying ChromaDB instance but can
    scope queries by agent_name or product_id.
    """

    # ── Store ─────────────────────────────────────────────────────────
    async def store_experience(
        self,
        agent_name: str,
        content: str,
        product_id: Optional[str] = None,
        extra_meta: Optional[dict[str, Any]] = None,
    ) -> None:
        """
        Persist an agent's observation or outcome as a memory document.
        """
        meta: dict[str, Any] = {
            "agent": agent_name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if product_id:
            meta["product_id"] = product_id
        if extra_meta:
            meta.update(extra_meta)

        await upsert_memory(
            collection_name=MEMORY_COLLECTION,
            documents=[content],
            metadatas=[meta],
        )
        log.info(
            "vector_memory.experience_stored",
            agent=agent_name,
            product_id=product_id,
        )

    async def store_strategy(
        self,
        agent_name: str,
        strategy_text: str,
        product_id: str,
        performance_score: float = 0.0,
    ) -> None:
        """Persist a strategy decision so future agents can learn from it."""
        meta: dict[str, Any] = {
            "agent": agent_name,
            "product_id": product_id,
            "performance_score": performance_score,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        await upsert_memory(
            collection_name=STRATEGY_COLLECTION,
            documents=[strategy_text],
            metadatas=[meta],
        )
        log.info(
            "vector_memory.strategy_stored",
            agent=agent_name,
            product_id=product_id,
            score=performance_score,
        )

    async def store_action(
        self,
        agent_name: str,
        action_description: str,
        result_summary: str,
        product_id: Optional[str] = None,
        success: bool = True,
    ) -> None:
        """Record what an agent did and what happened."""
        doc = f"ACTION: {action_description}\nRESULT: {result_summary}"
        meta: dict[str, Any] = {
            "agent": agent_name,
            "success": success,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if product_id:
            meta["product_id"] = product_id

        await upsert_memory(
            collection_name=ACTION_COLLECTION,
            documents=[doc],
            metadatas=[meta],
        )

    # ── Retrieve ──────────────────────────────────────────────────────
    async def recall_experiences(
        self,
        query: str,
        agent_name: Optional[str] = None,
        product_id: Optional[str] = None,
        n: int = 5,
    ) -> list[str]:
        """
        Recall the most semantically relevant past experiences.
        Returns plain text documents sorted by relevance.
        """
        where: Optional[dict] = None
        filters = {}
        if agent_name:
            filters["agent"] = agent_name
        if product_id:
            filters["product_id"] = product_id
        if filters:
            where = filters if len(filters) == 1 else {"$and": [{k: v} for k, v in filters.items()]}

        results = await query_memory(
            collection_name=MEMORY_COLLECTION,
            query_text=query,
            n_results=n,
            where=where,
        )
        return [r["document"] for r in results]

    async def recall_strategies(
        self,
        query: str,
        product_id: Optional[str] = None,
        n: int = 3,
    ) -> list[dict[str, Any]]:
        """Recall relevant strategies with their performance scores."""
        where = {"product_id": product_id} if product_id else None
        results = await query_memory(
            collection_name=STRATEGY_COLLECTION,
            query_text=query,
            n_results=n,
            where=where,
        )
        return results  # [{document, metadata, distance}, ...]

    async def recall_similar_actions(
        self,
        query: str,
        n: int = 5,
    ) -> list[dict[str, Any]]:
        """Find past actions similar to the current goal."""
        return await query_memory(
            collection_name=ACTION_COLLECTION,
            query_text=query,
            n_results=n,
        )

    async def build_context_block(
        self,
        query: str,
        agent_name: str,
        product_id: Optional[str] = None,
        max_chars: int = 3000,
    ) -> str:
        """
        Build a condensed memory context block to inject into LLM prompts.
        Pulls from all three collections and formats into a readable block.
        """
        experiences = await self.recall_experiences(
            query, agent_name=agent_name, product_id=product_id, n=3
        )
        strategies = await self.recall_strategies(query, product_id=product_id, n=2)
        actions = await self.recall_similar_actions(query, n=3)

        lines: list[str] = ["=== AGENT MEMORY ==="]

        if experiences:
            lines.append("\n-- Past Experiences --")
            for exp in experiences:
                lines.append(f"• {exp[:300]}")

        if strategies:
            lines.append("\n-- Relevant Strategies --")
            for s in strategies:
                score = s["metadata"].get("performance_score", "?")
                lines.append(f"• [score={score}] {s['document'][:300]}")

        if actions:
            lines.append("\n-- Similar Past Actions --")
            for a in actions:
                success = a["metadata"].get("success", "?")
                lines.append(f"• [success={success}] {a['document'][:300]}")

        lines.append("=== END MEMORY ===")
        block = "\n".join(lines)
        return block[:max_chars]
