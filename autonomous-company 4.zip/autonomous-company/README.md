# Autonomous Company AI

A production-grade multi-agent system that autonomously builds, launches, and scales revenue-generating digital products with minimal human input.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     FastAPI Control Server :8000                │
│          /agents  /products  /metrics  /system                  │
└──────────────────────┬──────────────────────────────────────────┘
                       │
              ┌────────▼────────┐
              │   ExecutionLoop  │  (async, runs every 5 min)
              │   Orchestrator   │
              └────────┬────────┘
                       │ dispatches tasks
        ┌──────────────┼──────────────────────────┐
        │              │              │            │
   ┌────▼───┐  ┌───────▼──┐  ┌───────▼──┐  ┌─────▼────┐
   │  Meta  │  │ Builder  │  │  Growth  │  │ Content  │
   │ Agent  │  │  Agent   │  │  Agent   │  │  Agent   │
   └────────┘  └──────────┘  └──────────┘  └──────────┘
   Orchestrate  Code + Deploy  Leads + Email  Copy + Pages

        ┌──────────────┬──────────────────────────┐
        │              │              │
   ┌────▼───────┐ ┌────▼───┐  ┌──────▼────┐
   │Monetization│ │  Data  │  │ Operator  │
   │   Agent    │ │ Agent  │  │  Agent    │
   └────────────┘ └────────┘  └───────────┘
   Stripe/Pricing  Analytics   Health/Retry

        ┌────────────────────────────────────────┐
        │            Infrastructure               │
        │  PostgreSQL │ Redis │ ChromaDB          │
        │  (data)     │(queue)│ (vector memory)   │
        └────────────────────────────────────────┘
```

---

## Quick Start

### Prerequisites

- Docker & Docker Compose
- Python 3.11+
- An [OpenAI API key](https://platform.openai.com/api-keys)

### 1. Clone and configure

```bash
git clone <your-repo>
cd autonomous-company

# Run the setup script
chmod +x scripts/setup.sh
./scripts/setup.sh
```

### 2. Set your OpenAI key

```bash
# Edit .env
nano .env

# Required:
OPENAI_API_KEY=sk-your-real-key-here

# Optional but recommended:
STRIPE_SECRET_KEY=sk_test_...     # For real payment links
SMTP_HOST=smtp.gmail.com          # For real email outreach
SMTP_USER=you@gmail.com
SMTP_PASSWORD=your-app-password
VERCEL_TOKEN=...                  # For real cloud deployment
```

### 3. Launch the stack

```bash
docker-compose up -d
```

This starts:
| Service | Port | Purpose |
|---|---|---|
| api | 8000 | FastAPI control server |
| worker | — | Celery agent workers (×2) |
| beat | — | Celery periodic scheduler |
| postgres | 5432 | Structured data |
| redis | 6379 | Task queue & cache |
| chromadb | 8001 | Vector memory |
| flower | 5555 | Celery task monitor |

### 4. Run the example launch

```bash
# With docker
docker-compose exec api python scripts/run_example.py

# Or locally (requires .env to be set)
source venv/bin/activate
python scripts/run_example.py
```

---

## API Reference

Once running, full interactive docs are at **http://localhost:8000/docs**

### Core endpoints

#### System
```
GET  /system/health           — health check
GET  /system/loop/status      — execution loop status
POST /system/loop/start       — start autonomous loop
POST /system/loop/stop        — stop autonomous loop
POST /system/loop/run-once    — trigger one loop iteration
GET  /system/queue            — task queue stats
POST /system/queue/drain      — execute all pending tasks now
```

#### Agents
```
GET  /agents                         — list all agents
GET  /agents/status                  — agent statuses (from Redis)
POST /agents/{agent_type}/execute    — trigger any agent directly
```

Example: trigger MetaAgent to ideate a product
```bash
curl -X POST http://localhost:8000/agents/meta/execute \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "ideate_product",
    "instruction": "Find a profitable SaaS niche in developer tools"
  }'
```

#### Products
```
GET    /products              — list all products
POST   /products              — create product manually
GET    /products/{id}         — product details
PATCH  /products/{id}         — update fields
DELETE /products/{id}         — archive product
POST   /products/{id}/launch  — trigger full launch pipeline
```

Example: manually create and launch a product
```bash
# Create
curl -X POST http://localhost:8000/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "InvoiceZap",
    "niche": "freelance invoicing",
    "description": "AI-powered invoicing for freelancers",
    "target_audience": "freelance designers and developers",
    "value_proposition": "Send professional invoices in 30 seconds",
    "price_monthly": 19
  }'

# Launch (replace PRODUCT_ID with the returned id)
curl -X POST http://localhost:8000/products/PRODUCT_ID/launch
```

#### Metrics
```
GET /metrics/system                              — system-wide analytics
GET /metrics/{product_id}                        — product KPIs
GET /metrics/{product_id}/funnel                 — conversion funnel
GET /metrics/{product_id}/history/{metric_type}  — time series
GET /metrics/{product_id}/insights               — AI-generated insights
```

---

## Agent Reference

### MetaAgent
- **Ideates** new products via market analysis (GPT-4o)
- **Decomposes** product goals into concrete agent tasks
- **Orchestrates** the entire pipeline each loop tick
- **Evaluates** products: continue / pivot / archive

### BuilderAgent
- **Generates** complete FastAPI + SQLite + Tailwind CSS applications
- **Deploys** to Vercel / Railway / Fly.io / local
- All code is written to `/tmp/acai_builds/<slug>/`

### GrowthAgent
- **Finds leads** via Apollo.io / Hunter.io / AI fallback
- **Generates** personalised cold email copy (GPT-4o)
- **Sends** campaigns via SMTP with rate limiting

### ContentAgent
- **Landing pages**: full HTML with Tailwind CSS
- **Blog posts**: 1,200-word SEO articles
- **Social content**: Twitter/LinkedIn post batches
- **Documentation**: full product docs

### MonetizationAgent
- **Designs** 3-tier pricing (freemium → pro → scale)
- **Creates** Stripe products, prices, and payment links
- **Optimises** conversion funnels with A/B test suggestions

### DataAgent
- **Collects** metrics (visitors, signups, revenue)
- **Computes** conversion funnels and KPIs
- **Detects** anomalies in time-series data
- **Generates** AI-driven insight reports

### OperatorAgent
- **Health checks**: DB, Redis, deployment pings
- **Retries** failed tasks (max 3 attempts)
- **Resets** hung IN_PROGRESS tasks (>30 min)
- **Cleans** stale data (old metrics, cancelled tasks)

---

## Memory System

### Vector Memory (ChromaDB)
Every agent action and observation is embedded and stored in three collections:
- `agent_memory` — general experiences
- `strategies` — decisions and outcomes
- `past_actions` — what was done and what happened

Agents query memory before each task to avoid repeating mistakes and build on past success.

### Structured Memory (PostgreSQL)
- Products with full financial and growth metrics
- Task queue with priority and retry tracking
- Time-series metrics with 90-day retention
- Full action audit trail with payloads and results

---

## Execution Loop

The loop runs every **5 minutes** (configurable via `LOOP_INTERVAL_SECONDS`):

```
Tick N:
  1. OperatorAgent → health check
  2. OperatorAgent → retry failed tasks
  3. MetaAgent     → orchestrate (ideate + decompose)
  4. Orchestrator  → execute up to 15 pending tasks
  5. DataAgent     → collect metrics and system report
  6. (Every 12 ticks) OperatorAgent → cleanup stale data
```

---

## Configuration Reference

Key `.env` variables:

| Variable | Required | Description |
|---|---|---|
| `OPENAI_API_KEY` | ✅ | GPT-4o + embeddings |
| `POSTGRES_PASSWORD` | ✅ | Database password |
| `STRIPE_SECRET_KEY` | Optional | Real payment links |
| `VERCEL_TOKEN` | Optional | Vercel deployment |
| `RAILWAY_TOKEN` | Optional | Railway deployment |
| `FLY_API_TOKEN` | Optional | Fly.io deployment |
| `SMTP_HOST` | Optional | Real email outreach |
| `APOLLO_API_KEY` | Optional | Real lead generation |
| `HUNTER_API_KEY` | Optional | Alternative leads |
| `LOOP_INTERVAL_SECONDS` | Optional | Loop frequency (default: 300) |
| `MAX_RETRIES` | Optional | Task retry limit (default: 3) |

---

## Development

### Local setup (no Docker)

```bash
# 1. Start infrastructure only
docker-compose up -d postgres redis chromadb

# 2. Activate venv
source venv/bin/activate

# 3. Run migrations
alembic upgrade head

# 4. Start API server
uvicorn api.main:app --reload --port 8000

# 5. Start Celery worker (separate terminal)
celery -A tasks.celery_app:celery_app worker --loglevel=info

# 6. Start Celery beat (separate terminal)
celery -A tasks.celery_app:celery_app beat --loglevel=info
```

### Run tests

```bash
pytest tests/ -v
```

### Add a new agent

1. Create `agents/my_agent.py` extending `BaseAgent`
2. Implement the `execute(task)` method
3. Register in `agents/__init__.py` → `AGENT_REGISTRY`
4. Add the new `AgentType` enum value to `models/task.py`
5. Create a new Alembic migration if needed

---

## Production Checklist

- [ ] Change `SECRET_KEY` in `.env` to a random 32+ char string
- [ ] Use real `OPENAI_API_KEY`
- [ ] Configure `SMTP_*` for email outreach
- [ ] Add `STRIPE_SECRET_KEY` for real payment links
- [ ] Add a deployment token (Vercel / Railway / Fly)
- [ ] Set `POSTGRES_PASSWORD` to something strong
- [ ] Put the API behind a reverse proxy (nginx / Traefik)
- [ ] Enable TLS/HTTPS
- [ ] Set up log aggregation (e.g. Datadog, Loki)
- [ ] Configure backup for PostgreSQL volume

---

## File Structure

```
autonomous-company/
├── api/                    FastAPI server
│   ├── main.py            App factory + lifespan
│   ├── deps.py            Dependency injection
│   └── routes/
│       ├── agents.py      Agent trigger endpoints
│       ├── products.py    Product CRUD + launch
│       ├── metrics.py     Analytics endpoints
│       └── system.py      Loop control + health
├── agents/                Seven autonomous agents
│   ├── base.py            BaseAgent with LLM + memory
│   ├── meta_agent.py      Orchestration + ideation
│   ├── builder_agent.py   Code gen + deployment
│   ├── growth_agent.py    Leads + outreach
│   ├── content_agent.py   Landing pages + copy
│   ├── monetization_agent.py Pricing + Stripe
│   ├── data_agent.py      Analytics + reporting
│   └── operator_agent.py  Health + retries
├── core/                  Infrastructure
│   ├── config.py          Pydantic settings
│   ├── database.py        Async SQLAlchemy
│   ├── redis_client.py    Async Redis
│   ├── vector_store.py    ChromaDB wrapper
│   └── logger.py          Structured JSON logging
├── memory/                Memory subsystem
│   ├── vector_memory.py   Semantic memory (ChromaDB)
│   └── structured_memory.py SQL-backed memory
├── models/                SQLAlchemy ORM models
│   ├── product.py         Product lifecycle
│   ├── task.py            Agent tasks
│   ├── metric.py          Time-series KPIs
│   └── action.py          Audit trail
├── tools/                 Agent capabilities
│   ├── code_generator.py  GPT-4o code generation
│   ├── deployment.py      Vercel/Railway/Fly
│   ├── landing_page.py    HTML page generation
│   ├── outreach.py        Lead gen + SMTP
│   └── analytics.py       KPI computation
├── execution/             Execution engine
│   ├── loop.py            Main execution loop
│   └── orchestrator.py    Task router
├── tasks/                 Celery
│   ├── celery_app.py      App config + beat schedule
│   └── agent_tasks.py     Task definitions
├── migrations/            Alembic DB migrations
├── scripts/
│   ├── setup.sh           One-command setup
│   └── run_example.py     Full product launch demo
├── docker-compose.yml     Full stack orchestration
├── Dockerfile.api         API server image
├── Dockerfile.worker      Celery worker image
└── requirements.txt       Python dependencies
```

---

*Built with Python 3.11, FastAPI, SQLAlchemy, Celery, Redis, PostgreSQL, ChromaDB, and OpenAI GPT-4o.*
